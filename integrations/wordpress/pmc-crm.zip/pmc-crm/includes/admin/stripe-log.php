<?php
defined('ABSPATH') || exit;

function pmc_page_stripe_log(): void {
    if (!current_user_can('manage_options')) return;

    global $wpdb;
    $table = $wpdb->prefix . 'pmc_webhook_log';

    // ── Webhook replay ────────────────────────────────────────────────────────
    $replay_result = null;
    if (isset($_POST['pmc_replay_nonce'], $_POST['replay_event_id'])) {
        if (wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pmc_replay_nonce'])), 'pmc_stripe_replay')) {
            $log_id = (int) $_POST['replay_event_id'];
            $log_row = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table}` WHERE id=%d LIMIT 1", $log_id));
            $whsec   = pmc_stripe_hook();

            if ($log_row && $whsec) {
                $t = (string) time();
                $payload = wp_json_encode([
                    'id'   => 'evt_replay_' . wp_generate_password(12, false),
                    'type' => $log_row->event_type,
                    'data' => [
                        'object' => [
                            'id'             => 'cs_replay_' . wp_generate_password(12, false),
                            'object'         => 'checkout.session',
                            'customer_email' => $log_row->email,
                            'amount_total'   => (int) $log_row->amount_cents,
                            'currency'       => 'usd',
                            'payment_status' => 'paid',
                            'subscription'   => 'sub_replay_' . wp_generate_password(12, false),
                            'customer'       => 'cus_replay_' . wp_generate_password(12, false),
                        ],
                    ],
                ]);
                $sig  = 'v1=' . hash_hmac('sha256', $t . '.' . $payload, $whsec);
                $resp = wp_remote_post(get_site_url() . '/wp-json/pmc/v1/stripe', [
                    'timeout' => 15,
                    'body'    => $payload,
                    'headers' => ['Content-Type' => 'application/json', 'Stripe-Signature' => 't=' . $t . ',' . $sig],
                ]);
                if (is_wp_error($resp)) {
                    $replay_result = ['ok' => false, 'code' => 0, 'body' => $resp->get_error_message()];
                } else {
                    $code = wp_remote_retrieve_response_code($resp);
                    $replay_result = ['ok' => ($code >= 200 && $code < 300), 'code' => $code, 'body' => wp_remote_retrieve_body($resp)];
                }
            } else {
                $replay_result = ['ok' => false, 'code' => 0, 'body' => $log_row ? 'No webhook secret configured.' : 'Log row not found.'];
            }
        }
    }

    $date_from   = sanitize_text_field($_GET['date_from']   ?? date('Y-m-d', strtotime('-30 days')));
    $date_to     = sanitize_text_field($_GET['date_to']     ?? date('Y-m-d'));
    $event_type  = sanitize_text_field($_GET['event_type']  ?? '');
    $result_f    = sanitize_text_field($_GET['result_f']    ?? '');
    $email_s     = sanitize_text_field($_GET['email']       ?? '');
    $page_num    = max(1, (int) ($_GET['paged'] ?? 1));
    $per_page    = 50;

    $where = ['created_at BETWEEN %s AND %s'];
    $vals  = [$date_from . ' 00:00:00', $date_to . ' 23:59:59'];
    if ($event_type) { $where[] = 'event_type = %s'; $vals[] = $event_type; }
    if ($result_f)   { $where[] = 'result = %s';     $vals[] = $result_f; }
    if ($email_s)    { $where[] = 'email LIKE %s';   $vals[] = '%' . $wpdb->esc_like($email_s) . '%'; }

    $where_sql = implode(' AND ', $where);
    $total     = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `{$table}` WHERE {$where_sql}", ...$vals));
    $rows      = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM `{$table}` WHERE {$where_sql} ORDER BY created_at DESC LIMIT %d OFFSET %d",
        ...array_merge($vals, [$per_page, ($page_num - 1) * $per_page])
    )) ?: [];
    $pages     = max(1, (int) ceil($total / $per_page));

    $processed = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `{$table}` WHERE {$where_sql} AND result='processed'", ...$vals));
    $skipped   = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `{$table}` WHERE {$where_sql} AND result='skipped'",   ...$vals));
    $errors    = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `{$table}` WHERE {$where_sql} AND result='error'",     ...$vals));

    $event_types = ['checkout.session.completed','invoice.payment_succeeded','customer.subscription.deleted','unknown'];
    $base_url    = admin_url('admin.php?page=pmc-crm-stripe');
    $stripe_is_test = strpos(pmc_stripe_hook(), '_test_') !== false;
    $stripe_dash = $stripe_is_test ? 'https://dashboard.stripe.com/test' : 'https://dashboard.stripe.com';
    ?>
    <div class="wrap">
        <h1>Stripe Webhook Log</h1>

        <?php if ($replay_result !== null): ?>
        <div class="notice notice-<?php echo $replay_result['ok'] ? 'success' : 'error'; ?> is-dismissible">
            <p><strong>Replay HTTP <?php echo esc_html($replay_result['code']); ?>:</strong> <?php echo esc_html($replay_result['body']); ?></p>
        </div>
        <?php endif; ?>

        <!-- Filter form -->
        <form method="get" style="margin:12px 0;display:flex;flex-wrap:wrap;gap:8px;align-items:flex-end">
            <input type="hidden" name="page" value="pmc-crm-stripe">
            <div><label>From<br><input type="date" name="date_from" value="<?php echo esc_attr($date_from); ?>"></label></div>
            <div><label>To<br><input type="date" name="date_to" value="<?php echo esc_attr($date_to); ?>"></label></div>
            <div><label>Event Type<br>
                <select name="event_type">
                    <option value="">All Events</option>
                    <?php foreach ($event_types as $et): ?>
                        <option value="<?php echo esc_attr($et); ?>" <?php selected($event_type, $et); ?>><?php echo esc_html($et); ?></option>
                    <?php endforeach; ?>
                </select></label></div>
            <div><label>Result<br>
                <select name="result_f">
                    <option value="">All</option>
                    <option value="processed" <?php selected($result_f, 'processed'); ?>>Processed</option>
                    <option value="skipped"   <?php selected($result_f, 'skipped'); ?>>Skipped</option>
                    <option value="error"     <?php selected($result_f, 'error'); ?>>Error</option>
                </select></label></div>
            <div><label>Email<br><input type="text" name="email" value="<?php echo esc_attr($email_s); ?>" placeholder="Search..."></label></div>
            <?php submit_button('Filter', 'secondary', '', false); ?>
        </form>

        <!-- Summary -->
        <p style="color:#444">
            <strong><?php echo esc_html(number_format($total)); ?></strong> total &mdash;
            <span style="color:#0a6b0a"><strong><?php echo esc_html($processed); ?></strong> processed</span> &mdash;
            <strong><?php echo esc_html($skipped); ?></strong> skipped &mdash;
            <span style="color:<?php echo $errors > 0 ? '#b32d2e' : 'inherit'; ?>"><strong><?php echo esc_html($errors); ?></strong> errors</span>
        </p>

        <?php if (empty($rows)): ?>
        <div style="text-align:center;padding:40px;background:#f9f9f9;border:1px solid #ddd;border-radius:6px;color:#666">
            <p style="font-size:15px;margin-bottom:8px">No webhook events found for the selected filters.</p>
            <p style="font-size:13px">Events appear here as Stripe sends them. Make sure your webhook endpoint is registered in Stripe Dashboard.<br>
            Endpoint URL: <code><?php echo esc_html(get_site_url() . '/wp-json/pmc/v1/stripe'); ?></code></p>
        </div>
        <?php else: ?>

        <style>
        .pmc-wh-detail { display:none; background:#fafafa; border-top:1px solid #eee; }
        .pmc-wh-detail.open { display:table-row; }
        </style>

        <table class="widefat striped" style="font-size:12px">
            <thead>
                <tr>
                    <th style="width:20px"></th>
                    <th>Date</th><th>Event Type</th><th>Event ID</th><th>Email</th>
                    <th>Amount</th><th>Result</th><th>Error</th><th style="width:80px"></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $row):
                $res_color = $row->result === 'processed' ? '#0a6b0a' : ($row->result === 'error' ? '#b32d2e' : '#666');
                $amount    = $row->amount_cents > 0 ? '$' . number_format($row->amount_cents / 100, 2) : '—';
                $row_detail_id = 'pmc-wh-' . (int) $row->id;
                $evt_link  = $row->event_id ? $stripe_dash . '/events/' . $row->event_id : '';
                $user_url  = $row->email ? admin_url('admin.php?page=pmc-crm-users&s=' . urlencode($row->email)) : '';
            ?>
                <tr style="cursor:pointer" onclick="pmcToggleWh('<?php echo esc_js($row_detail_id); ?>')" title="Click to expand payload">
                    <td style="color:#999;font-size:10px" id="<?php echo esc_attr($row_detail_id . '-arrow'); ?>">▶</td>
                    <td><?php echo esc_html($row->created_at); ?></td>
                    <td><?php echo esc_html($row->event_type ?: '—'); ?></td>
                    <td style="font-family:monospace;font-size:11px">
                        <?php if ($evt_link): ?>
                            <a href="<?php echo esc_url($evt_link); ?>" target="_blank" rel="noopener noreferrer"
                               onclick="event.stopPropagation()"
                               title="Open in Stripe Dashboard"><?php echo esc_html(substr($row->event_id, 0, 22) . (strlen($row->event_id) > 22 ? '…' : '')); ?> &#8599;</a>
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($user_url && $row->email): ?>
                            <a href="<?php echo esc_url($user_url); ?>" onclick="event.stopPropagation()"><?php echo esc_html($row->email); ?></a>
                        <?php else: ?>
                            <?php echo esc_html($row->email ?: '—'); ?>
                        <?php endif; ?>
                    </td>
                    <td><?php echo esc_html($amount); ?></td>
                    <td style="color:<?php echo esc_attr($res_color); ?>;font-weight:bold"><?php echo esc_html($row->result); ?></td>
                    <td style="color:#b32d2e;max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?php echo esc_attr($row->error_message ?? ''); ?>"><?php echo esc_html(mb_substr($row->error_message ?? '', 0, 40)); ?></td>
                    <td onclick="event.stopPropagation()">
                        <?php if ($row->event_type && $row->email): ?>
                        <form method="post" style="display:inline">
                            <?php wp_nonce_field('pmc_stripe_replay', 'pmc_replay_nonce'); ?>
                            <input type="hidden" name="replay_event_id" value="<?php echo esc_attr($row->id); ?>">
                            <button type="submit" class="button button-small" title="Re-send a signed test event for this row">Replay</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr id="<?php echo esc_attr($row_detail_id); ?>" class="pmc-wh-detail">
                    <td colspan="9" style="padding:10px 14px">
                        <strong style="font-size:11px">Stored Payload Excerpt:</strong>
                        <pre style="margin-top:6px;font-size:10px;overflow:auto;max-height:220px;background:#f0f0f0;border:1px solid #ddd;padding:8px;border-radius:4px;white-space:pre-wrap;word-break:break-all"><?php echo esc_html($row->payload_excerpt ?? '(none stored)'); ?></pre>
                        <?php if ($row->error_message): ?>
                        <strong style="font-size:11px;color:#b32d2e">Error:</strong>
                        <pre style="margin-top:4px;font-size:10px;color:#b32d2e;white-space:pre-wrap"><?php echo esc_html($row->error_message); ?></pre>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <?php endif; ?>

        <!-- Pagination -->
        <?php if ($pages > 1): ?>
        <div style="margin-top:12px">
            <?php
            $stripe_filter_params = array_filter(['date_from' => $date_from, 'date_to' => $date_to, 'event_type' => $event_type, 'result_f' => $result_f, 'email' => $email_s]);
            echo pmc_build_pagination($page_num, $pages, $stripe_filter_params, $base_url);
            ?>
        </div>
        <?php endif; ?>
    </div>

    <script>
    function pmcToggleWh(id) {
        var row   = document.getElementById(id);
        var arrow = document.getElementById(id + '-arrow');
        if (!row) return;
        var open = row.classList.contains('open');
        row.classList.toggle('open', !open);
        if (arrow) arrow.textContent = open ? '▶' : '▼';
    }
    </script>
    <?php
}
