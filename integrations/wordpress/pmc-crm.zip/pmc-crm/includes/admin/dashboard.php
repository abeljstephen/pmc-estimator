<?php
defined('ABSPATH') || exit;

function pmc_page_dashboard(): void {
    if (!current_user_can('manage_options')) return;

    // Handle quick actions (extend / grant / email-all / extend-all)
    if (isset($_POST['pmc_quick_uid'], $_POST['pmc_quick_nonce'], $_POST['pmc_quick_action'])) {
        $uid    = (int) $_POST['pmc_quick_uid'];
        $action = sanitize_text_field($_POST['pmc_quick_action']);
        if (wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pmc_quick_nonce'])), 'pmc_quick_action_' . $uid)) {
            $user = pmc_get_user_by_id($uid);
            if ($user) {
                if ($action === 'extend10') {
                    $new_exp = date('Y-m-d', strtotime(($user->key_expires ?: 'now') . ' +10 days'));
                    pmc_update_user($uid, ['key_expires' => $new_exp, 'key_status' => 'active']);
                    pmc_log_activity(['user_id' => $uid, 'email' => $user->email,
                        'action' => 'manual_grant', 'result' => 'success',
                        'notes' => 'Dashboard quick-extend +10 days. New expiry: ' . $new_exp]);
                } elseif ($action === 'grant20') {
                    $new_total = (int) $user->credits_total + 20;
                    pmc_update_user($uid, ['credits_total' => $new_total]);
                    pmc_log_activity(['user_id' => $uid, 'email' => $user->email,
                        'action' => 'manual_grant', 'result' => 'success',
                        'credits_cost' => -20, 'credits_before' => (int)$user->credits_total, 'credits_after' => $new_total,
                        'notes' => 'Dashboard quick-grant +20 credits']);
                }
            }
        }
    }

    // Bulk queue actions (extend-all / email-all)
    $queue_notice = '';
    if (isset($_POST['pmc_queue_nonce'], $_POST['pmc_queue_action'])) {
        if (wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pmc_queue_nonce'])), 'pmc_queue_bulk')) {
            $qa = sanitize_text_field($_POST['pmc_queue_action']);
            if ($qa === 'extend_all_expiring') {
                $users_exp = pmc_get_all_pmc_users(['expiring_days' => 7]);
                $cnt = 0;
                foreach ($users_exp as $u) {
                    $new_exp = date('Y-m-d', strtotime(($u->key_expires ?: 'now') . ' +10 days'));
                    pmc_update_user((int)$u->id, ['key_expires' => $new_exp, 'key_status' => 'active']);
                    $cnt++;
                }
                $queue_notice = 'Extended ' . $cnt . ' expiring user(s) by +10 days.';
            } elseif ($qa === 'email_all_expiring') {
                $users_exp = pmc_get_all_pmc_users(['expiring_days' => 7]);
                $cnt = 0;
                foreach ($users_exp as $u) {
                    pmc_send_email($u->email, 'expired', ['email' => $u->email, 'plan' => $u->plan,
                        'expiry' => $u->key_expires, 'key' => $u->api_key,
                        'upgrade_url' => pmc_stripe_link(), 'site_name' => get_bloginfo('name')]);
                    $cnt++;
                }
                $queue_notice = 'Sent expiry notice to ' . $cnt . ' user(s).';
            } elseif ($qa === 'grant_all_low') {
                $users_low = pmc_get_all_pmc_users(['low_credits_pct' => 10]);
                $cnt = 0;
                foreach ($users_low as $u) {
                    $new_total = (int)$u->credits_total + 20;
                    pmc_update_user((int)$u->id, ['credits_total' => $new_total]);
                    $cnt++;
                }
                $queue_notice = 'Granted +20 credits to ' . $cnt . ' low-credit user(s).';
            } elseif ($qa === 'email_all_low') {
                $users_low = pmc_get_all_pmc_users(['low_credits_pct' => 10]);
                $cnt = 0;
                foreach ($users_low as $u) {
                    $rem = max(0, (int)$u->credits_total - (int)$u->credits_used);
                    pmc_send_email($u->email, 'low_credits_10', ['email' => $u->email, 'plan' => $u->plan,
                        'credits_remaining' => $rem, 'credits_total' => $u->credits_total,
                        'upgrade_url' => pmc_stripe_link(), 'site_name' => get_bloginfo('name')]);
                    $cnt++;
                }
                $queue_notice = 'Sent low-credits notice to ' . $cnt . ' user(s).';
            }
        }
    }

    $today       = date('Y-m-d');
    $today_stats = pmc_get_calls_in_window($today, $today);
    $total_users  = pmc_get_user_count();
    $active_users = pmc_get_user_count('active');
    $expired      = pmc_get_user_count('expired') + pmc_get_user_count('cancelled');

    global $wpdb;
    $trials_active = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM `{$wpdb->prefix}pmc_users` WHERE plan='trial' AND key_status='active'"
    );

    $expiring_soon = pmc_get_all_pmc_users(['expiring_days' => 7]);
    $low_credit    = pmc_get_all_pmc_users(['low_credits_pct' => 10]);
    $recent_activity = pmc_get_activity([], 20);

    $failed_today = $today_stats['failed_calls'];
    $calls_today  = $today_stats['total_calls'];
    $avg_dur      = $today_stats['total_calls'] > 0
        ? round($today_stats['total_duration_ms'] / $today_stats['total_calls'])
        : 0;

    $credits_today = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(credits_cost),0) FROM `{$wpdb->prefix}pmc_activity`
         WHERE action='deduct' AND DATE(created_at)=%s",
        $today
    ));

    $rev_today = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(amount_cents),0) FROM `{$wpdb->prefix}pmc_payments` WHERE DATE(created_at)=%s AND status='succeeded'",
        $today
    ));
    $rev_month = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(amount_cents),0) FROM `{$wpdb->prefix}pmc_payments` WHERE DATE_FORMAT(created_at,'%%Y-%%m')=%s AND status='succeeded'",
        date('Y-m')
    ));
    $rev_total = (int) $wpdb->get_var(
        "SELECT COALESCE(SUM(amount_cents),0) FROM `{$wpdb->prefix}pmc_payments` WHERE status='succeeded'"
    );

    // ── 30-day trend data for charts ──────────────────────────────────────────
    $trend_days  = 30;
    $trend_start = date('Y-m-d', strtotime('-' . ($trend_days - 1) . ' days'));

    $daily_raw = $wpdb->get_results($wpdb->prepare(
        "SELECT DATE(created_at) AS day,
                COUNT(*) AS calls,
                SUM(CASE WHEN result IN ('fail','error') THEN 1 ELSE 0 END) AS failed,
                COALESCE(SUM(CASE WHEN action='deduct' THEN credits_cost ELSE 0 END),0) AS credits
         FROM `{$wpdb->prefix}pmc_activity`
         WHERE created_at >= %s
         GROUP BY DATE(created_at)
         ORDER BY day ASC",
        $trend_start . ' 00:00:00'
    )) ?: [];

    $rev_raw = $wpdb->get_results($wpdb->prepare(
        "SELECT DATE(created_at) AS day, COALESCE(SUM(amount_cents),0) AS cents
         FROM `{$wpdb->prefix}pmc_payments`
         WHERE created_at >= %s AND status='succeeded'
         GROUP BY DATE(created_at)
         ORDER BY day ASC",
        $trend_start . ' 00:00:00'
    )) ?: [];

    // Build full 30-day arrays (fill zeros for missing days)
    $labels = $calls_data = $failed_data = $credits_data = $rev_data = [];
    $daily_map  = array_column($daily_raw, null, 'day');
    $rev_map    = array_column($rev_raw,   null, 'day');
    for ($i = $trend_days - 1; $i >= 0; $i--) {
        $d = date('Y-m-d', strtotime('-' . $i . ' days'));
        $labels[]       = date('M j', strtotime($d));
        $calls_data[]   = isset($daily_map[$d]) ? (int) $daily_map[$d]->calls   : 0;
        $failed_data[]  = isset($daily_map[$d]) ? (int) $daily_map[$d]->failed  : 0;
        $credits_data[] = isset($daily_map[$d]) ? (int) $daily_map[$d]->credits : 0;
        $rev_data[]     = isset($rev_map[$d])   ? round($rev_map[$d]->cents / 100, 2) : 0;
    }

    // ── GAS health: last successful GAS call ─────────────────────────────────
    $last_gas = $wpdb->get_row(
        "SELECT created_at, result FROM `{$wpdb->prefix}pmc_activity`
         WHERE action = 'deduct'
         ORDER BY created_at DESC LIMIT 1"
    );
    ?>
    <div class="wrap">
        <h1>PMC CRM — Dashboard</h1>
        <?php if (isset($_GET['updated'])): ?>
            <div class="notice notice-success is-dismissible"><p>Saved.</p></div>
        <?php endif; ?>
        <?php if ($queue_notice): ?>
            <div class="notice notice-success is-dismissible"><p><?php echo esc_html($queue_notice); ?></p></div>
        <?php endif; ?>

        <?php
        if ($total_users === 0 && pmc_fluentcrm_available()) {
            $fc_count = (int) $wpdb->get_var(
                "SELECT COUNT(DISTINCT subscriber_id) FROM `{$wpdb->prefix}fc_subscriber_meta` WHERE `key`='pmc_api_key'"
            );
            if ($fc_count > 0): ?>
                <div class="notice notice-warning">
                    <p><strong>FluentCRM data detected.</strong>
                    <?php echo esc_html($fc_count); ?> user(s) found in FluentCRM but not yet imported.
                    <a href="<?php echo esc_url(admin_url('admin.php?page=pmc-crm-tools')); ?>">Run migration under Tools</a> to import your users.</p>
                </div>
            <?php endif;
        }
        ?>

        <style>
        .pmc-kpi-grid { display:flex; flex-wrap:wrap; gap:16px; margin:16px 0; }
        .pmc-kpi { background:#fff; border:1px solid #ddd; border-radius:6px; padding:16px 20px; min-width:160px; flex:1; }
        .pmc-kpi h3 { margin:0 0 4px; font-size:13px; color:#666; font-weight:normal; }
        .pmc-kpi .pmc-kpi-val { font-size:28px; font-weight:bold; color:#2271b1; }
        .pmc-section { background:#fff; border:1px solid #ddd; border-radius:6px; padding:16px; margin-bottom:20px; }
        .pmc-section h2 { margin-top:0; font-size:16px; border-bottom:1px solid #eee; padding-bottom:8px; display:flex; justify-content:space-between; align-items:center; }
        .pmc-result-success { color:#0a6b0a; }
        .pmc-result-fail, .pmc-result-error { color:#b32d2e; }
        .pmc-chart-wrap { position:relative; height:200px; margin-top:12px; }
        </style>

        <div class="pmc-kpi-grid">
            <div class="pmc-kpi"><h3>Total Users</h3><div class="pmc-kpi-val"><?php echo esc_html($total_users); ?></div></div>
            <div class="pmc-kpi"><h3>Active Keys</h3><div class="pmc-kpi-val"><?php echo esc_html($active_users); ?></div></div>
            <div class="pmc-kpi"><h3>Trials Active</h3><div class="pmc-kpi-val"><?php echo esc_html($trials_active); ?></div></div>
            <div class="pmc-kpi"><h3>Expired / Cancelled</h3><div class="pmc-kpi-val"><?php echo esc_html($expired); ?></div></div>
        </div>
        <div class="pmc-kpi-grid">
            <div class="pmc-kpi"><h3>Credits Consumed Today</h3><div class="pmc-kpi-val"><?php echo esc_html($credits_today); ?></div></div>
            <div class="pmc-kpi"><h3>Calls Today</h3><div class="pmc-kpi-val"><?php echo esc_html($calls_today); ?></div></div>
            <div class="pmc-kpi"><h3>Avg Duration Today</h3><div class="pmc-kpi-val"><?php echo esc_html($avg_dur); ?>ms</div></div>
            <div class="pmc-kpi"><h3>Failed Calls Today</h3><div class="pmc-kpi-val" style="color:<?php echo $failed_today > 0 ? '#b32d2e' : '#0a6b0a'; ?>"><?php echo esc_html($failed_today); ?></div></div>
        </div>
        <div class="pmc-kpi-grid">
            <div class="pmc-kpi"><h3>Revenue Today</h3><div class="pmc-kpi-val">$<?php echo esc_html(number_format($rev_today / 100, 2)); ?></div></div>
            <div class="pmc-kpi"><h3>Revenue This Month</h3><div class="pmc-kpi-val">$<?php echo esc_html(number_format($rev_month / 100, 2)); ?></div></div>
            <div class="pmc-kpi"><h3>Revenue All-Time</h3><div class="pmc-kpi-val">$<?php echo esc_html(number_format($rev_total / 100, 2)); ?></div></div>
            <div class="pmc-kpi" style="border-color:<?php echo $last_gas ? '#4caf50' : '#ddd'; ?>">
                <h3>GAS Last Call
                    <a href="<?php echo esc_url(admin_url('admin.php?page=pmc-crm-gas')); ?>" style="font-size:11px;font-weight:normal;margin-left:6px">Details &rarr;</a>
                </h3>
                <?php if ($last_gas): ?>
                    <div class="pmc-kpi-val" style="font-size:15px;color:<?php echo $last_gas->result === 'success' ? '#0a6b0a' : '#b32d2e'; ?>">
                        <?php echo esc_html(pmc_relative_time($last_gas->created_at)); ?>
                    </div>
                    <div style="font-size:11px;color:#666;margin-top:2px"><?php echo esc_html($last_gas->result); ?></div>
                <?php else: ?>
                    <div class="pmc-kpi-val" style="font-size:15px;color:#999">No calls yet</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- 30-Day Trend Charts -->
        <div class="pmc-section">
            <h2>30-Day Trends</h2>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:20px">
                <div>
                    <h3 style="font-size:13px;color:#444;margin-bottom:0">API Calls per Day</h3>
                    <div class="pmc-chart-wrap"><canvas id="pmc-chart-calls"></canvas></div>
                </div>
                <div>
                    <h3 style="font-size:13px;color:#444;margin-bottom:0">Credits Consumed per Day</h3>
                    <div class="pmc-chart-wrap"><canvas id="pmc-chart-credits"></canvas></div>
                </div>
                <div>
                    <h3 style="font-size:13px;color:#444;margin-bottom:0">Revenue per Day ($)</h3>
                    <div class="pmc-chart-wrap"><canvas id="pmc-chart-rev"></canvas></div>
                </div>
            </div>
        </div>

        <!-- Action Queue -->
        <div class="pmc-section">
            <h2>
                <span>Action Queue — Needs Attention</span>
            </h2>

            <h3 style="font-size:14px;display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                <span>Expiring Within 7 Days (<?php echo count($expiring_soon); ?>)</span>
                <?php if (!empty($expiring_soon)): ?>
                <span style="display:flex;gap:6px">
                    <form method="post" style="display:inline">
                        <?php wp_nonce_field('pmc_queue_bulk', 'pmc_queue_nonce'); ?>
                        <input type="hidden" name="pmc_queue_action" value="extend_all_expiring">
                        <button type="submit" class="button button-small">Extend All +10 Days</button>
                    </form>
                    <form method="post" style="display:inline">
                        <?php wp_nonce_field('pmc_queue_bulk', 'pmc_queue_nonce'); ?>
                        <input type="hidden" name="pmc_queue_action" value="email_all_expiring">
                        <button type="submit" class="button button-small">Email All</button>
                    </form>
                </span>
                <?php endif; ?>
            </h3>
            <?php if (empty($expiring_soon)): ?>
                <p style="color:#0a6b0a;font-size:13px;padding:10px;background:#f0fdf4;border-radius:4px">No keys expiring within 7 days.</p>
            <?php else: ?>
                <table class="widefat striped" style="max-width:700px">
                    <thead><tr><th>Email</th><th>Plan</th><th>Expires</th><th>Days Left</th><th>Action</th></tr></thead>
                    <tbody>
                    <?php foreach ($expiring_soon as $u):
                        $days_left = max(0, (int) ceil((strtotime($u->key_expires) - time()) / DAY_IN_SECONDS));
                        $detail_url = admin_url('admin.php?page=pmc-crm-users&user_id=' . $u->id);
                    ?>
                        <tr>
                            <td><a href="<?php echo esc_url($detail_url); ?>" style="text-decoration:none"><?php echo esc_html($u->email); ?></a></td>
                            <td><?php echo pmc_plan_badge($u->plan); ?></td>
                            <td><?php echo esc_html($u->key_expires); ?></td>
                            <td style="color:<?php echo $days_left <= 2 ? '#b32d2e' : '#c05600'; ?>;font-weight:bold"><?php echo esc_html($days_left); ?></td>
                            <td>
                                <form method="post" style="display:inline">
                                    <?php wp_nonce_field('pmc_quick_action_' . $u->id, 'pmc_quick_nonce'); ?>
                                    <input type="hidden" name="pmc_quick_uid"    value="<?php echo esc_attr($u->id); ?>">
                                    <input type="hidden" name="pmc_quick_action" value="extend10">
                                    <button type="submit" class="button button-small">+10 Days</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <h3 style="font-size:14px;display:flex;align-items:center;justify-content:space-between;margin-top:20px;margin-bottom:6px">
                <span>Below 10% Credits (<?php echo count($low_credit); ?>)</span>
                <?php if (!empty($low_credit)): ?>
                <span style="display:flex;gap:6px">
                    <form method="post" style="display:inline">
                        <?php wp_nonce_field('pmc_queue_bulk', 'pmc_queue_nonce'); ?>
                        <input type="hidden" name="pmc_queue_action" value="grant_all_low">
                        <button type="submit" class="button button-small">Grant All +20 Credits</button>
                    </form>
                    <form method="post" style="display:inline">
                        <?php wp_nonce_field('pmc_queue_bulk', 'pmc_queue_nonce'); ?>
                        <input type="hidden" name="pmc_queue_action" value="email_all_low">
                        <button type="submit" class="button button-small">Email All</button>
                    </form>
                </span>
                <?php endif; ?>
            </h3>
            <?php if (empty($low_credit)): ?>
                <p style="color:#0a6b0a;font-size:13px;padding:10px;background:#f0fdf4;border-radius:4px">No users below 10% credits.</p>
            <?php else: ?>
                <table class="widefat striped" style="max-width:700px">
                    <thead><tr><th>Email</th><th>Plan</th><th>Remaining</th><th>Total</th><th>Action</th></tr></thead>
                    <tbody>
                    <?php foreach ($low_credit as $u):
                        $detail_url = admin_url('admin.php?page=pmc-crm-users&user_id=' . $u->id);
                    ?>
                        <tr>
                            <td><a href="<?php echo esc_url($detail_url); ?>" style="text-decoration:none"><?php echo esc_html($u->email); ?></a></td>
                            <td><?php echo pmc_plan_badge($u->plan); ?></td>
                            <td style="color:#b32d2e;font-weight:bold"><?php echo esc_html($u->credits_remaining); ?></td>
                            <td><?php echo esc_html($u->credits_total); ?></td>
                            <td>
                                <form method="post" style="display:inline">
                                    <?php wp_nonce_field('pmc_quick_action_' . $u->id, 'pmc_quick_nonce'); ?>
                                    <input type="hidden" name="pmc_quick_uid"    value="<?php echo esc_attr($u->id); ?>">
                                    <input type="hidden" name="pmc_quick_action" value="grant20">
                                    <button type="submit" class="button button-small">+20 Credits</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Recent Activity Feed -->
        <div class="pmc-section">
            <h2><span>Recent Activity</span> <a href="<?php echo esc_url(admin_url('admin.php?page=pmc-crm-activity')); ?>" style="font-size:12px;font-weight:normal">View All &rarr;</a></h2>
            <?php if (empty($recent_activity)): ?>
                <p style="color:#666;padding:20px;text-align:center;background:#f9f9f9;border-radius:4px">No activity recorded yet. Activity appears here once users start making API calls.</p>
            <?php else: ?>
                <table class="widefat striped">
                    <thead><tr><th>Date</th><th>Email</th><th>Action</th><th>Credits</th><th>Result</th></tr></thead>
                    <tbody>
                    <?php foreach ($recent_activity as $row):
                        $user_url = $row->user_id
                            ? admin_url('admin.php?page=pmc-crm-users&user_id=' . (int)$row->user_id)
                            : ($row->email ? admin_url('admin.php?page=pmc-crm-users&s=' . urlencode($row->email)) : '');
                    ?>
                        <tr>
                            <td style="font-size:12px"><?php echo esc_html(pmc_relative_time($row->created_at)); ?></td>
                            <td><?php if ($user_url): ?><a href="<?php echo esc_url($user_url); ?>" style="font-size:12px"><?php echo esc_html($row->email ?: '—'); ?></a><?php else: ?><span style="font-size:12px"><?php echo esc_html($row->email ?: '—'); ?></span><?php endif; ?></td>
                            <td style="font-size:12px"><?php echo esc_html($row->action); ?></td>
                            <td style="font-size:12px"><?php echo $row->credits_cost ? esc_html($row->credits_cost) : '—'; ?></td>
                            <td class="pmc-result-<?php echo esc_attr($row->result); ?>" style="font-size:12px;font-weight:bold"><?php echo esc_html($row->result); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script>
    (function() {
        var labels   = <?php echo wp_json_encode($labels); ?>;
        var calls    = <?php echo wp_json_encode($calls_data); ?>;
        var failed   = <?php echo wp_json_encode($failed_data); ?>;
        var credits  = <?php echo wp_json_encode($credits_data); ?>;
        var revenue  = <?php echo wp_json_encode($rev_data); ?>;

        var chartOpts = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { labels: { font: { size: 11 } } } },
            scales: {
                x: { ticks: { font: { size: 10 }, maxTicksLimit: 10 } },
                y: { beginAtZero: true, ticks: { font: { size: 10 } } }
            }
        };

        // API Calls chart
        var c1 = document.getElementById('pmc-chart-calls');
        if (c1) new Chart(c1, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    { label: 'Total Calls', data: calls, borderColor: '#2271b1', backgroundColor: 'rgba(34,113,177,.08)', tension: .3, fill: true, pointRadius: 2 },
                    { label: 'Failed', data: failed, borderColor: '#b32d2e', backgroundColor: 'rgba(179,45,46,.06)', tension: .3, fill: true, pointRadius: 2 }
                ]
            },
            options: chartOpts
        });

        // Credits chart
        var c2 = document.getElementById('pmc-chart-credits');
        if (c2) new Chart(c2, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{ label: 'Credits Used', data: credits, backgroundColor: 'rgba(79,70,229,.7)', borderRadius: 3 }]
            },
            options: chartOpts
        });

        // Revenue chart
        var c3 = document.getElementById('pmc-chart-rev');
        if (c3) new Chart(c3, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{ label: 'Revenue ($)', data: revenue, backgroundColor: 'rgba(5,150,105,.7)', borderRadius: 3 }]
            },
            options: chartOpts
        });
    })();
    </script>
    <?php
}
