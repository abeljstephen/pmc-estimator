<?php
defined('ABSPATH') || exit;

function pmc_page_tools(): void {
    if (!current_user_can('manage_options')) return;

    $notice = '';

    // Export all users
    if (isset($_GET['export_users']) && $_GET['export_users'] === '1') {
        $users = pmc_get_all_pmc_users();
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="pmc-users-full-' . date('Ymd') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['id','email','api_key','plan','credits_total','credits_used','credits_remaining','key_status','key_expires','stripe_customer_id','stripe_subscription_id','last_estimation','ip_address','source','created_at']);
        foreach ($users as $u) {
            fputcsv($out, [(int)$u->id,$u->email,$u->api_key,$u->plan,(int)$u->credits_total,(int)$u->credits_used,(int)$u->credits_remaining,$u->key_status,$u->key_expires,$u->stripe_customer_id,$u->stripe_subscription_id,$u->last_estimation,$u->ip_address,$u->source,$u->created_at]);
        }
        fclose($out);
        exit;
    }

    // Export activity
    if (isset($_GET['export_activity']) && $_GET['export_activity'] === '1') {
        $date_from = sanitize_text_field($_GET['act_from'] ?? date('Y-m-d', strtotime('-30 days')));
        $date_to   = sanitize_text_field($_GET['act_to']   ?? date('Y-m-d'));
        $rows = pmc_get_activity(['date_from' => $date_from, 'date_to' => $date_to], 100000, 0);
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="pmc-activity-' . date('Ymd') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['id','created_at','email','action','operation_type','credits_cost','credits_before','credits_after','duration_ms','gas_exec_count','ip_address','result','notes']);
        foreach ($rows as $r) {
            fputcsv($out, [(int)$r->id,$r->created_at,$r->email,$r->action,$r->operation_type,(int)$r->credits_cost,(int)$r->credits_before,(int)$r->credits_after,(int)$r->duration_ms,(int)$r->gas_exec_count,$r->ip_address,$r->result,$r->notes]);
        }
        fclose($out);
        exit;
    }

    // Export payments
    if (isset($_GET['export_payments']) && $_GET['export_payments'] === '1') {
        global $wpdb;
        $date_from = sanitize_text_field($_GET['pay_from'] ?? date('Y-m-d', strtotime('-12 months')));
        $date_to   = sanitize_text_field($_GET['pay_to']   ?? date('Y-m-d'));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM `{$wpdb->prefix}pmc_payments` WHERE DATE(created_at) BETWEEN %s AND %s ORDER BY created_at DESC LIMIT 100000",
            $date_from, $date_to
        )) ?: [];
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="pmc-payments-' . date('Ymd') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['id','created_at','email','type','plan','amount_cents','amount_usd','currency','stripe_payment_intent','stripe_invoice_id','stripe_subscription_id','stripe_customer_id','stripe_price_id','stripe_product_id','stripe_charge_id','billing_reason','period_start','period_end','status','coupon_code']);
        foreach ($rows as $r) {
            fputcsv($out, [(int)$r->id,$r->created_at,$r->email,$r->type,$r->plan,(int)$r->amount_cents,number_format($r->amount_cents/100,2),$r->currency,$r->stripe_payment_intent,$r->stripe_invoice_id,$r->stripe_subscription_id,$r->stripe_customer_id,$r->stripe_price_id,$r->stripe_product_id,$r->stripe_charge_id,$r->billing_reason,$r->period_start,$r->period_end,$r->status,$r->coupon_code]);
        }
        fclose($out);
        exit;
    }

    // Migrate from FluentCRM
    $migration_report = null;
    if (isset($_POST['pmc_migrate_nonce'])) {
        if (wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pmc_migrate_nonce'])), 'pmc_migrate_fluentcrm')) {
            if (pmc_fluentcrm_available()) {
                global $wpdb;
                $fc_meta = $wpdb->prefix . 'fc_subscriber_meta';
                $fc_subs = $wpdb->prefix . 'fc_subscribers';

                $rows = $wpdb->get_results(
                    "SELECT s.email, m.value AS api_key,
                        MAX(CASE WHEN m2.`key`='pmc_plan' THEN m2.value END) AS plan,
                        MAX(CASE WHEN m2.`key`='pmc_credits_total' THEN m2.value END) AS credits_total,
                        MAX(CASE WHEN m2.`key`='pmc_credits_used' THEN m2.value END) AS credits_used,
                        MAX(CASE WHEN m2.`key`='pmc_key_expires' THEN m2.value END) AS key_expires,
                        MAX(CASE WHEN m2.`key`='pmc_key_status' THEN m2.value END) AS key_status
                     FROM `{$fc_subs}` s
                     INNER JOIN `{$fc_meta}` m  ON m.subscriber_id  = s.id AND m.`key`  = 'pmc_api_key'
                     INNER JOIN `{$fc_meta}` m2 ON m2.subscriber_id = s.id
                     GROUP BY s.email, m.value"
                ) ?: [];

                $imported = $skipped = $errors = 0;
                foreach ($rows as $row) {
                    $email = strtolower(sanitize_email($row->email));
                    if (!is_email($email)) { $errors++; continue; }
                    $existing = pmc_get_user_by_email($email);
                    if ($existing) { $skipped++; continue; }
                    $res = pmc_create_user([
                        'email'         => $email,
                        'api_key'       => (string) ($row->api_key ?? ''),
                        'plan'          => (string) ($row->plan ?? 'trial'),
                        'credits_total' => (int)    ($row->credits_total ?? 0),
                        'credits_used'  => (int)    ($row->credits_used  ?? 0),
                        'key_expires'   => (string) ($row->key_expires   ?? ''),
                        'key_status'    => (string) ($row->key_status    ?? 'active'),
                        'source'        => 'import',
                    ]);
                    if ($res) $imported++; else $errors++;
                }
                $migration_report = compact('imported', 'skipped', 'errors');
                $notice = "Migration complete: {$imported} imported, {$skipped} skipped, {$errors} errors.";
            } else {
                $notice = 'FluentCRM is not available.';
            }
        }
    }

    // Prune activity
    $prune_notice = '';
    if (isset($_POST['pmc_prune_nonce'], $_POST['prune_confirmed']) && (int)$_POST['prune_confirmed'] === 1) {
        if (wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pmc_prune_nonce'])), 'pmc_prune_activity')) {
            $months = max(1, (int) ($_POST['prune_months'] ?? 13));
            $deleted = pmc_prune_activity($months * 30);
            $prune_notice = 'Pruned ' . $deleted . ' activity rows older than ' . $months . ' month(s).';
        }
    }

    // Test email
    $email_notice = '';
    if (isset($_POST['pmc_test_email_nonce'])) {
        if (wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pmc_test_email_nonce'])), 'pmc_test_email')) {
            $to_addr = sanitize_email($_POST['test_email_addr'] ?? '');
            $tpl_slug = sanitize_text_field($_POST['test_tpl'] ?? 'trial_issued');
            if (is_email($to_addr)) {
                $dummy = ['email' => $to_addr, 'key' => 'test-key-abc123', 'plan' => 'Professional',
                    'credits' => '55', 'expiry' => date('Y-m-d', strtotime('+35 days')),
                    'upgrade_url' => pmc_stripe_link(), 'credits_remaining' => '42', 'credits_total' => '55',
                    'site_name' => get_bloginfo('name')];
                $sent = pmc_send_email($to_addr, $tpl_slug, $dummy);
                $email_notice = $sent ? 'Test email sent to ' . $to_addr : 'Failed to send test email.';
            } else {
                $email_notice = 'Invalid email address.';
            }
        }
    }

    // Ping
    $ping_result = null;
    if (isset($_POST['pmc_tool_ping_nonce'])) {
        if (wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pmc_tool_ping_nonce'])), 'pmc_tool_ping')) {
            $ping_result = pmc_gas_ping();
        }
    }

    // Stripe webhook tester
    $stripe_test_result = null;
    if (isset($_POST['pmc_stripe_test_nonce'])) {
        if (wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pmc_stripe_test_nonce'])), 'pmc_stripe_test')) {
            $event_type = sanitize_text_field($_POST['stripe_event_type'] ?? 'checkout.session.completed');
            $test_email = sanitize_email($_POST['stripe_test_email'] ?? get_option('admin_email'));
            $amount     = max(0, (int) ($_POST['stripe_amount_cents'] ?? 4900));
            $whsec      = pmc_stripe_hook();

            if (empty($whsec)) {
                $stripe_test_result = ['ok' => false, 'code' => 0, 'body' => 'No Stripe Webhook Secret configured in Settings.'];
            } else {
                $t = (string) time();
                $payload = wp_json_encode([
                    'id'   => 'evt_test_' . wp_generate_password(16, false),
                    'type' => $event_type,
                    'data' => [
                        'object' => [
                            'id'                => 'cs_test_' . wp_generate_password(16, false),
                            'object'            => 'checkout.session',
                            'customer_email'    => $test_email,
                            'amount_total'      => $amount,
                            'currency'          => 'usd',
                            'payment_status'    => 'paid',
                            'subscription'      => 'sub_test_' . wp_generate_password(16, false),
                            'customer'          => 'cus_test_' . wp_generate_password(16, false),
                            'metadata'          => ['plan' => sanitize_text_field($_POST['stripe_plan'] ?? 'professional')],
                        ],
                    ],
                ]);
                $sig_body = $t . '.' . $payload;
                $sig = 'v1=' . hash_hmac('sha256', $sig_body, $whsec);

                $endpoint_url = get_site_url() . '/wp-json/pmc/v1/stripe';
                $response = wp_remote_post($endpoint_url, [
                    'timeout' => 15,
                    'body'    => $payload,
                    'headers' => [
                        'Content-Type'      => 'application/json',
                        'Stripe-Signature'  => 't=' . $t . ',' . $sig,
                    ],
                ]);

                if (is_wp_error($response)) {
                    $stripe_test_result = ['ok' => false, 'code' => 0, 'body' => $response->get_error_message()];
                } else {
                    $code = wp_remote_retrieve_response_code($response);
                    $body = wp_remote_retrieve_body($response);
                    $stripe_test_result = ['ok' => ($code >= 200 && $code < 300), 'code' => $code, 'body' => $body];
                }
            }
        }
    }

    // Table row counts
    global $wpdb;
    $table_counts = [];
    foreach (['pmc_users','pmc_activity','pmc_payments','pmc_plans','pmc_promo_codes','pmc_email_templates','pmc_webhook_log'] as $t) {
        $table_counts[$t] = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$wpdb->prefix}{$t}`");
    }

    $templates = $wpdb->get_results("SELECT slug, label FROM `{$wpdb->prefix}pmc_email_templates` ORDER BY slug") ?: [];
    ?>
    <div class="wrap">
        <h1>PMC CRM Tools</h1>
        <?php if ($notice): ?>
            <div class="notice notice-success is-dismissible"><p><?php echo esc_html($notice); ?></p></div>
        <?php endif; ?>
        <?php if ($prune_notice): ?>
            <div class="notice notice-info is-dismissible"><p><?php echo esc_html($prune_notice); ?></p></div>
        <?php endif; ?>
        <?php if ($email_notice): ?>
            <div class="notice notice-info is-dismissible"><p><?php echo esc_html($email_notice); ?></p></div>
        <?php endif; ?>

        <style>.pmc-tool { background:#fff;border:1px solid #ddd;border-radius:6px;padding:16px;margin-bottom:20px; }
        .pmc-tool h2 { margin-top:0;font-size:15px;border-bottom:1px solid #eee;padding-bottom:8px; }</style>

        <!-- FluentCRM Migration -->
        <div class="pmc-tool">
            <h2>Migrate from FluentCRM</h2>
            <?php if (!pmc_fluentcrm_available()): ?>
                <p style="color:#666">FluentCRM is not active. Migration is unavailable.</p>
            <?php else: ?>
                <p>Scans <code>fc_subscriber_meta</code> for <code>pmc_api_key</code> entries and imports matching users into <code>wp_pmc_users</code>. Existing emails are skipped.</p>
                <form method="post">
                    <?php wp_nonce_field('pmc_migrate_fluentcrm', 'pmc_migrate_nonce'); ?>
                    <?php submit_button('Run Migration', 'primary', '', false); ?>
                </form>
                <?php if ($migration_report !== null): ?>
                    <p style="margin-top:12px"><strong>Result:</strong>
                    <?php echo esc_html($migration_report['imported']); ?> imported,
                    <?php echo esc_html($migration_report['skipped']); ?> skipped (already exist),
                    <?php echo esc_html($migration_report['errors']); ?> errors.</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <!-- Prune Activity Log -->
        <div class="pmc-tool" style="border-color:#b32d2e">
            <h2 style="color:#b32d2e">⚠ Danger Zone — Prune Activity Log</h2>
            <p style="color:#666;font-size:13px">This permanently deletes activity log rows. This action cannot be undone.</p>
            <form method="post">
                <?php wp_nonce_field('pmc_prune_activity', 'pmc_prune_nonce'); ?>
                <p><label>Delete activity events older than
                    <input type="number" name="prune_months" value="13" min="1" style="width:60px"> months
                </label></p>
                <p><label>
                    <input type="checkbox" name="prune_confirmed" value="1" required>
                    I confirm I want to permanently delete these rows
                </label></p>
                <?php submit_button('Prune Activity Log', 'delete', '', false); ?>
            </form>
        </div>

        <!-- Test Email -->
        <div class="pmc-tool">
            <h2>Test Email</h2>
            <form method="post">
                <?php wp_nonce_field('pmc_test_email', 'pmc_test_email_nonce'); ?>
                <p>
                    <label>Send to: <input type="email" name="test_email_addr" value="<?php echo esc_attr(get_option('admin_email')); ?>" class="regular-text"></label>
                </p>
                <p>
                    <label>Template:
                        <select name="test_tpl">
                            <?php foreach ($templates as $t): ?>
                                <option value="<?php echo esc_attr($t->slug); ?>"><?php echo esc_html($t->label . ' (' . $t->slug . ')'); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                </p>
                <?php submit_button('Send Test Email', 'secondary', '', false); ?>
            </form>
        </div>

        <!-- Ping GAS -->
        <div class="pmc-tool">
            <h2>Ping GAS</h2>
            <form method="post">
                <?php wp_nonce_field('pmc_tool_ping', 'pmc_tool_ping_nonce'); ?>
                <?php submit_button('Ping GAS Endpoint', 'secondary', '', false); ?>
            </form>
            <?php if ($ping_result !== null): ?>
                <div style="margin-top:12px;padding:10px;background:#f0f8ff;border:1px solid #cce">
                    <strong>Status:</strong> <?php echo $ping_result['ok'] ? '<span style="color:#0a6b0a">OK</span>' : '<span style="color:#b32d2e">FAIL</span>'; ?><br>
                    <strong>Latency:</strong> <?php echo esc_html($ping_result['latency_ms']); ?>ms<br>
                    <?php if ($ping_result['error']): ?><strong>Error:</strong> <?php echo esc_html($ping_result['error']); ?><br><?php endif; ?>
                    <?php if ($ping_result['response']): ?><pre style="font-size:11px;overflow:auto;max-height:200px"><?php echo esc_html(wp_json_encode($ping_result['response'], JSON_PRETTY_PRINT)); ?></pre><?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Export users -->
        <div class="pmc-tool">
            <h2>Export All Users CSV</h2>
            <p>Downloads a CSV of the full <code>wp_pmc_users</code> table including API keys.</p>
            <p style="background:#fff8e1;border:1px solid #f0c040;border-radius:4px;padding:8px 12px;font-size:13px;color:#7a4f00">
                <strong>Note:</strong> This CSV contains plaintext API keys. Store it securely and do not share or commit it.
            </p>
            <a href="<?php echo esc_url(add_query_arg(['export_users' => '1'], admin_url('admin.php?page=pmc-crm-tools'))); ?>" class="button">Download Users CSV</a>
        </div>

        <!-- Export activity -->
        <div class="pmc-tool">
            <h2>Export Activity Log CSV</h2>
            <form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>">
                <input type="hidden" name="page" value="pmc-crm-tools">
                <input type="hidden" name="export_activity" value="1">
                <p>
                    <label>From: <input type="date" name="act_from" value="<?php echo esc_attr(date('Y-m-d', strtotime('-30 days'))); ?>"></label>
                    <label style="margin-left:12px">To: <input type="date" name="act_to" value="<?php echo esc_attr(date('Y-m-d')); ?>"></label>
                </p>
                <button type="submit" class="button">Download Activity CSV</button>
            </form>
        </div>

        <!-- Export payments -->
        <div class="pmc-tool">
            <h2>Export Payments CSV</h2>
            <p>Downloads all Stripe payment records with full IDs (payment intent, invoice, subscription, price, product, charge).</p>
            <form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>">
                <input type="hidden" name="page" value="pmc-crm-tools">
                <input type="hidden" name="export_payments" value="1">
                <p>
                    <label>From: <input type="date" name="pay_from" value="<?php echo esc_attr(date('Y-m-d', strtotime('-12 months'))); ?>"></label>
                    <label style="margin-left:12px">To: <input type="date" name="pay_to" value="<?php echo esc_attr(date('Y-m-d')); ?>"></label>
                </p>
                <button type="submit" class="button">Download Payments CSV</button>
            </form>
        </div>

        <!-- Stripe Webhook Tester -->
        <div class="pmc-tool">
            <h2>Stripe Webhook Tester</h2>
            <?php
            $whsec = pmc_stripe_hook();
            $is_live = !empty($whsec) && strpos($whsec, '_test_') === false;
            if (empty($whsec)): ?>
                <p style="background:#fff8e1;border:1px solid #f0c040;border-radius:4px;padding:8px 12px;font-size:13px;color:#7a4f00">
                    <strong>No webhook secret configured.</strong> Add your Stripe Webhook Secret in Settings first.
                </p>
            <?php elseif ($is_live): ?>
                <p style="background:#fce8e8;border:1px solid #b32d2e;border-radius:4px;padding:8px 12px;font-size:13px;color:#6e0000">
                    <strong>Live mode detected.</strong> Your webhook secret does not contain <code>_test_</code> — this will fire against your production endpoint. Real users may be created or modified. Proceed with caution.
                </p>
            <?php else: ?>
                <p style="background:#eaf5ea;border:1px solid #4caf50;border-radius:4px;padding:8px 12px;font-size:13px;color:#1b5e20">
                    <strong>Test mode.</strong> Sends a signed fake event to your own webhook endpoint using the stored whsec. No real Stripe API calls are made.
                </p>
            <?php endif; ?>
            <form method="post" style="margin-top:12px">
                <?php wp_nonce_field('pmc_stripe_test', 'pmc_stripe_test_nonce'); ?>
                <table class="form-table" style="max-width:520px">
                    <tr>
                        <th style="width:160px">Event type</th>
                        <td>
                            <select name="stripe_event_type">
                                <option value="checkout.session.completed">checkout.session.completed</option>
                                <option value="invoice.payment_succeeded">invoice.payment_succeeded</option>
                                <option value="customer.subscription.deleted">customer.subscription.deleted</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Test email</th>
                        <td><input type="email" name="stripe_test_email" value="<?php echo esc_attr(get_option('admin_email')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>Amount (cents)</th>
                        <td><input type="number" name="stripe_amount_cents" value="4900" min="0" style="width:100px"> <span style="color:#666;font-size:12px">e.g. 4900 = $49.00</span></td>
                    </tr>
                    <tr>
                        <th>Plan slug</th>
                        <td><input type="text" name="stripe_plan" value="professional" class="regular-text" placeholder="professional"></td>
                    </tr>
                </table>
                <?php submit_button('Send Test Webhook', 'secondary', '', false); ?>
            </form>
            <?php if ($stripe_test_result !== null): ?>
                <div style="margin-top:14px;padding:12px;border-radius:4px;border:1px solid <?php echo $stripe_test_result['ok'] ? '#4caf50' : '#b32d2e'; ?>;background:<?php echo $stripe_test_result['ok'] ? '#eaf5ea' : '#fce8e8'; ?>">
                    <strong>HTTP <?php echo esc_html($stripe_test_result['code']); ?></strong>
                    — <span style="color:<?php echo $stripe_test_result['ok'] ? '#1b5e20' : '#6e0000'; ?>"><?php echo $stripe_test_result['ok'] ? 'Success' : 'Error'; ?></span><br>
                    <pre style="margin-top:8px;font-size:11px;overflow:auto;max-height:180px;background:#f9f9f9;border:1px solid #ddd;padding:8px"><?php echo esc_html($stripe_test_result['body']); ?></pre>
                    <p style="margin-top:8px;font-size:12px">
                        <a href="<?php echo esc_url(admin_url('admin.php?page=pmc-crm-stripe-log')); ?>">View Stripe Webhook Log &rarr;</a>
                    </p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Database status -->
        <div class="pmc-tool">
            <h2>Database Status</h2>
            <p>Plugin version: <strong><?php echo esc_html(PMC_CRM_VERSION); ?></strong></p>
            <table class="widefat" style="max-width:400px">
                <thead><tr><th>Table</th><th>Rows</th></tr></thead>
                <tbody>
                <?php foreach ($table_counts as $tname => $cnt): ?>
                    <tr><td><code><?php echo esc_html($wpdb->prefix . $tname); ?></code></td><td><?php echo esc_html(number_format($cnt)); ?></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}
