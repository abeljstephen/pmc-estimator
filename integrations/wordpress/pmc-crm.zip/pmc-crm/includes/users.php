<?php
defined('ABSPATH') || exit;

function pmc_get_user_by_email(string $email): ?object {
    global $wpdb;
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM `{$wpdb->prefix}pmc_users` WHERE email = %s LIMIT 1",
        strtolower($email)
    ));
    return $row ?: null;
}

function pmc_get_user_by_key(string $key): ?object {
    if (empty($key)) return null;
    global $wpdb;
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM `{$wpdb->prefix}pmc_users` WHERE api_key = %s LIMIT 1",
        $key
    ));
    return $row ?: null;
}

function pmc_get_user_by_id(int $id): ?object {
    global $wpdb;
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM `{$wpdb->prefix}pmc_users` WHERE id = %d LIMIT 1",
        $id
    ));
    return $row ?: null;
}

/**
 * Insert a new PMC user. $data keys match table columns.
 * Returns new row ID on success, false on failure.
 */
function pmc_create_user(array $data): int|false {
    global $wpdb;
    $data['created_at'] = current_time('mysql');
    $data['updated_at'] = current_time('mysql');
    $result = $wpdb->insert($wpdb->prefix . 'pmc_users', $data);
    if ($result === false) return false;
    return (int) $wpdb->insert_id;
}

/**
 * Update specified columns for a user by ID.
 * Always sets updated_at to now.
 */
function pmc_update_user(int $id, array $data): bool {
    global $wpdb;
    $data['updated_at'] = current_time('mysql');
    $result = $wpdb->update(
        $wpdb->prefix . 'pmc_users',
        $data,
        ['id' => $id]
    );
    return $result !== false;
}

/**
 * Fetch all PMC users with optional filters and sorting.
 *
 * Supported filters:
 *   plan            (string)  — exact plan slug
 *   key_status      (string)  — exact status
 *   search          (string)  — email LIKE %search%
 *   expiring_days   (int)     — key_expires within N days from now
 *   low_credits_pct (int)     — users whose remaining% < threshold
 *   created_from    (string)  — DATE(created_at) >= value
 *   created_to      (string)  — DATE(created_at) <= value
 *   active_from     (string)  — last_estimation >= value
 *   active_to       (string)  — last_estimation <= value
 *   orderby         (string)  — email|plan|key_status|key_expires|last_estimation|created_at|credits_remaining
 *   order           (string)  — ASC|DESC
 *
 * Returns each row plus SQL-computed 'credits_remaining'.
 */
function pmc_get_all_pmc_users(array $filters = []): array {
    global $wpdb;
    $table = $wpdb->prefix . 'pmc_users';
    $where = ['1=1'];
    $vals  = [];

    if (!empty($filters['plan'])) {
        $where[] = 'plan = %s';
        $vals[]  = $filters['plan'];
    }
    if (!empty($filters['key_status'])) {
        $where[] = 'key_status = %s';
        $vals[]  = $filters['key_status'];
    }
    if (!empty($filters['search'])) {
        $where[] = 'email LIKE %s';
        $vals[]  = '%' . $wpdb->esc_like($filters['search']) . '%';
    }
    if (isset($filters['expiring_days']) && $filters['expiring_days'] > 0) {
        $where[] = 'key_expires IS NOT NULL AND key_expires >= CURDATE() AND key_expires <= DATE_ADD(CURDATE(), INTERVAL %d DAY)';
        $vals[]  = (int) $filters['expiring_days'];
    }
    if (!empty($filters['created_from'])) {
        $where[] = 'DATE(created_at) >= %s';
        $vals[]  = $filters['created_from'];
    }
    if (!empty($filters['created_to'])) {
        $where[] = 'DATE(created_at) <= %s';
        $vals[]  = $filters['created_to'];
    }
    if (!empty($filters['active_from'])) {
        $where[] = 'last_estimation >= %s';
        $vals[]  = $filters['active_from'] . ' 00:00:00';
    }
    if (!empty($filters['active_to'])) {
        $where[] = 'last_estimation <= %s';
        $vals[]  = $filters['active_to'] . ' 23:59:59';
    }

    // Sorting — whitelist only
    $allowed = [
        'email'             => 'email',
        'plan'              => 'plan',
        'key_status'        => 'key_status',
        'key_expires'       => 'key_expires',
        'last_estimation'   => 'last_estimation',
        'created_at'        => 'created_at',
        'credits_remaining' => 'GREATEST(0, credits_total - credits_used)',
    ];
    $ob_key = $filters['orderby'] ?? 'created_at';
    $ob_col = $allowed[$ob_key] ?? 'created_at';
    $od     = strtoupper($filters['order'] ?? 'DESC') === 'ASC' ? 'ASC' : 'DESC';

    // NULLs last for nullable date columns
    $null_last = '';
    if ($ob_key === 'last_estimation') $null_last = '(last_estimation IS NULL) ASC, ';
    elseif ($ob_key === 'key_expires')  $null_last = '(key_expires IS NULL) ASC, ';

    $where_sql = implode(' AND ', $where);
    $sql       = "SELECT *, GREATEST(0, credits_total - credits_used) AS credits_remaining
                  FROM `{$table}` WHERE {$where_sql}
                  ORDER BY {$null_last}{$ob_col} {$od}";

    $rows = (!empty($vals)
        ? $wpdb->get_results($wpdb->prepare($sql, ...$vals))
        : $wpdb->get_results($sql)) ?: [];

    // Post-filter computed field
    if (isset($filters['low_credits_pct']) && $filters['low_credits_pct'] > 0) {
        $threshold = (int) $filters['low_credits_pct'];
        $rows = array_filter($rows, function ($u) use ($threshold) {
            $total = (int) $u->credits_total;
            if ($total <= 0) return false;
            return ((int) $u->credits_remaining / $total * 100) < $threshold;
        });
    }

    return array_values($rows);
}

/**
 * Count users by key_status, or all users if $status is empty.
 */
function pmc_get_user_count(string $status = ''): int {
    global $wpdb;
    $table = $wpdb->prefix . 'pmc_users';
    if ($status !== '') {
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM `{$table}` WHERE key_status = %s",
            $status
        ));
    }
    return (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$table}`");
}

/**
 * Return overall user KPIs (not affected by list filters).
 */
function pmc_get_user_kpis(): array {
    global $wpdb;
    $t = $wpdb->prefix . 'pmc_users';
    return [
        'total'      => (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t}`"),
        'active'     => (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t}` WHERE key_status='active' AND (key_expires IS NULL OR key_expires >= CURDATE())"),
        'expiring_7' => (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t}` WHERE key_status='active' AND key_expires IS NOT NULL AND key_expires BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)"),
        'exhausted'  => (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t}` WHERE credits_total > 0 AND credits_used >= credits_total"),
    ];
}

/**
 * Remaining credits for a user object.
 */
function pmc_credits_remaining(object $user): int {
    return max(0, (int) $user->credits_total - (int) $user->credits_used);
}

// ── API KEY HISTORY ────────────────────────────────────────────────────────────

/**
 * Insert a new key row into pmc_api_keys.
 * Call whenever a key is issued or regenerated.
 * status: 'active'
 */
function pmc_create_api_key(int $user_id, string $email, string $api_key, string $notes = ''): void {
    global $wpdb;
    $wpdb->insert($wpdb->prefix . 'pmc_api_keys', [
        'user_id'    => $user_id,
        'email'      => strtolower($email),
        'api_key'    => $api_key,
        'status'     => 'active',
        'created_at' => current_time('mysql'),
        'notes'      => $notes ?: null,
    ]);
}

/**
 * Mark all active/superseded keys for a user as the given status.
 * Used on suspend (revoked) or when a new key supersedes old ones.
 *
 * $status: 'superseded' | 'revoked'
 */
function pmc_revoke_user_keys(int $user_id, string $status = 'superseded', string $notes = ''): void {
    global $wpdb;
    $table = $wpdb->prefix . 'pmc_api_keys';
    $wpdb->query($wpdb->prepare(
        "UPDATE `{$table}` SET status=%s, revoked_at=%s, notes=COALESCE(NULLIF(%s,''), notes)
         WHERE user_id=%d AND status='active'",
        $status, current_time('mysql'), $notes, $user_id
    ));
}

/**
 * Return all key rows for a user, newest first.
 */
function pmc_get_user_keys(int $user_id): array {
    global $wpdb;
    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM `{$wpdb->prefix}pmc_api_keys` WHERE user_id=%d ORDER BY created_at DESC",
        $user_id
    )) ?: [];
}

/**
 * Backfill: if a user's current api_key has no row in pmc_api_keys, insert one.
 * Idempotent — IGNORE handles the UNIQUE constraint.
 */
function pmc_backfill_api_key(int $user_id, string $email, string $api_key): void {
    if (empty($api_key)) return;
    global $wpdb;
    $wpdb->query($wpdb->prepare(
        "INSERT IGNORE INTO `{$wpdb->prefix}pmc_api_keys`
         (user_id, email, api_key, status, created_at, notes)
         VALUES (%d, %s, %s, 'active', %s, 'backfilled')",
        $user_id, strtolower($email), $api_key, current_time('mysql')
    ));
}
