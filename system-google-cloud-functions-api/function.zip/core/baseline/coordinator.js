'use strict';

const path = require('path');
const CORE_DIR = path.resolve(__dirname, '..');

const { generateTrianglePoints } = require('./triangle-points');
const { generatePertPoints } = require('./pert-points');
const { generateBetaPoints, computeBetaMoments } = require('./beta-points');
const { generateMonteCarloRawPoints } = require('./monte-carlo-raw');
const { generateMonteCarloSmoothedPoints } = require('./monte-carlo-smoothed');

const { createErrorResponse, isValidPdfArray, isValidCdfArray } =
  require(path.join(CORE_DIR, 'helpers/validation'));

const { calculateMetrics } = require(path.join(CORE_DIR, 'helpers/metrics'));
const { computeKLDivergence } = require(path.join(CORE_DIR, 'optimization', 'kl-divergence'));

console.log('coordinator.js: Starting module initialization');

/**
 * Generates baseline distributions and metrics.
 *
 * Policy:
 *  - ALWAYS generate Triangle (needed for KL), regardless of `suppressOtherDistros`.
 *  - Monte Carlo *smoothed* (active baseline) is always generated.
 *  - If `suppressOtherDistros` is true: skip PERT/Beta/MC-raw (size/perf win).
 *  - Otherwise, generate them as before.
 */
async function generateBaseline(params) {
  console.log('generateBaseline: Starting', { params });
  try {
    const {
      optimistic, mostLikely, pessimistic,
      numSamples = 200,
      suppressOtherDistros = false
    } = params;

    // ---- validation --------------------------------------------------------
    if (![optimistic, mostLikely, pessimistic].every(Number.isFinite)) {
      throw new Error('Invalid estimates: must be finite numbers');
    }
    if (optimistic > mostLikely || mostLikely > pessimistic) {
      throw new Error('Estimates must satisfy optimistic <= mostLikely <= pessimistic');
    }
    const range = pessimistic - optimistic;
    if (range <= 0) throw new Error('Degenerate case: single point distribution');
    if (!Number.isFinite(numSamples) || numSamples < 100) {
      throw new Error('Invalid numSamples: must be a number >= 100');
    }

    // ---- beta params (shared) ---------------------------------------------
    // Keep for consistency with MC paths; safe even if we suppress others.
    const { alpha, beta } = await computeBetaMoments({ optimistic, mostLikely, pessimistic });
    if (!Number.isFinite(alpha) || !Number.isFinite(beta) || alpha <= 0 || beta <= 0) {
      throw new Error('Invalid beta parameters');
    }

    // ---- ALWAYS build Triangle (so KL is available) -----------------------
    const trianglePoints = await generateTrianglePoints({
      optimistic, mostLikely, pessimistic, numSamples
    });
    if (trianglePoints.error ||
        !isValidPdfArray(trianglePoints.pdfPoints) ||
        !isValidCdfArray(trianglePoints.cdfPoints)) {
      throw new Error('Invalid triangle points');
    }

    // ---- Optionally build the rest ----------------------------------------
    let pertPoints, betaPoints, monteCarloRawPoints;
    if (!suppressOtherDistros) {
      pertPoints = await generatePertPoints({ optimistic, mostLikely, pessimistic, numSamples });
      if (pertPoints.error ||
          !isValidPdfArray(pertPoints.pdfPoints) ||
          !isValidCdfArray(pertPoints.cdfPoints)) {
        throw new Error('Invalid PERT points');
      }

      betaPoints = await generateBetaPoints({ optimistic, mostLikely, pessimistic, numSamples, alpha, beta });
      if (betaPoints.error ||
          !isValidPdfArray(betaPoints.pdfPoints) ||
          !isValidCdfArray(betaPoints.cdfPoints)) {
        throw new Error('Invalid beta points');
      }

      monteCarloRawPoints = await generateMonteCarloRawPoints({ optimistic, mostLikely, pessimistic, numSamples, alpha, beta });
      if (monteCarloRawPoints.error ||
          !isValidPdfArray(monteCarloRawPoints.pdfPoints) ||
          !isValidCdfArray(monteCarloRawPoints.cdfPoints)) {
        throw new Error('Invalid Monte Carlo raw points');
      }
    } else {
      console.log('generateBaseline: suppressOtherDistros=true (PERT/Beta/MC-raw skipped; Triangle kept)');
    }

    // ---- Monte Carlo smoothed (active baseline) ---------------------------
    // Prefer reusing raw samples when available; otherwise fall back to O/M/P beta sampling.
    const smoothedParams = { optimistic, mostLikely, pessimistic, numSamples };
    if (monteCarloRawPoints?.samples?.length) smoothedParams.samples = monteCarloRawPoints.samples;

    const monteCarloSmoothedPoints = await generateMonteCarloSmoothedPoints(smoothedParams);
    if (monteCarloSmoothedPoints.error ||
        !isValidPdfArray(monteCarloSmoothedPoints.pdfPoints) ||
        !isValidCdfArray(monteCarloSmoothedPoints.cdfPoints)) {
      throw new Error('Invalid Monte Carlo smoothed points');
    }

    // ---- Metrics (CI + KL) ------------------------------------------------
    const metrics = calculateMetrics({
      triangle: { ...trianglePoints, optimistic, mostLikely, pessimistic },
      monteCarloSmoothed: {
        pdfPoints: monteCarloSmoothedPoints.pdfPoints,
        cdfPoints: monteCarloSmoothedPoints.cdfPoints
      }
    });

    const ciLower = metrics?.monteCarloSmoothed?.ci?.lower;
    const ciUpper = metrics?.monteCarloSmoothed?.ci?.upper;

    // KL(Triangle || MC-smoothed) — triangle is guaranteed present here
    let kld;
    const klObj = computeKLDivergence({
      distributions: {
        triangle: trianglePoints,
        monteCarloSmoothed: monteCarloSmoothedPoints
      },
      task: 'baseline'
    });
    kld = klObj && klObj['triangle-monteCarloSmoothed'];

    console.log('generateBaseline: Completed', {
      ciLower, ciUpper, kld,
      mcPdf: monteCarloSmoothedPoints.pdfPoints.length,
      mcCdf: monteCarloSmoothedPoints.cdfPoints.length
    });

    // ---- Envelope (preserve legacy fields) --------------------------------
    return {
      trianglePoints,                 // ALWAYS present
      pertPoints,                     // present unless suppressed
      betaPoints,                     // present unless suppressed
      monteCarloRawPoints,           // present unless suppressed
      monteCarloSmoothedPoints,      // active baseline series

      metrics: {
        monteCarloSmoothed: { ci: { lower: ciLower, upper: ciUpper } },
        klDivergenceToTriangle: kld
      },

      // Back-compat mirrors:
      ci: { monteCarloSmoothed: { lower: ciLower, upper: ciUpper } },
      confidenceInterval: { lower: ciLower, upper: ciUpper },
      pert: { mean: (optimistic + 4 * mostLikely + pessimistic) / 6 },
      monteCarloSmoothed: { // some callers read from this key
        pdfPoints: monteCarloSmoothedPoints.pdfPoints,
        cdfPoints: monteCarloSmoothedPoints.cdfPoints
      },

      alpha, beta,
      error: null
    };
  } catch (error) {
    console.error('generateBaseline: Error', { message: error.message, stack: error.stack });
    return { error: `Failed to generate baseline: ${error.message || 'Unknown error'}` };
  }
}

module.exports = { generateBaseline };

