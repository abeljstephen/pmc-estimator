'use strict';

const path = require('path');
const CORE_DIR = path.resolve(__dirname, '..');

// Import pure JS betaPdf from beta-points
const { betaPdf } = require('./beta-points');
const { computeBetaMoments } = require('./beta-points');

/**
 * Generate PERT (Beta-parameterized via O/M/P) PDF & CDF on [O, P].
 * Returns { pdfPoints, cdfPoints } or { pdfPoints:[], cdfPoints:[], error } on failure.
 */
async function generatePertPoints(params) {
  console.log('generatePertPoints: Starting', { params });
  try {
    const { optimistic, mostLikely, pessimistic, numSamples = 200 } = params;

    if (![optimistic, mostLikely, pessimistic].every(Number.isFinite)) {
      throw new Error('Invalid estimates: must be finite numbers');
    }
    if (optimistic > mostLikely || mostLikely > pessimistic) {
      throw new Error('Estimates must satisfy optimistic <= mostLikely <= pessimistic');
    }
    if (pessimistic - optimistic <= 0) {
      throw new Error('Degenerate case: single point distribution');
    }
    if (!Number.isFinite(numSamples) || numSamples < 2) {
      throw new Error('Invalid numSamples: must be a number >= 2');
    }

    const { alpha, beta, error: abErr } = await computeBetaMoments({ optimistic, mostLikely, pessimistic });
    if (abErr) {
      throw new Error(`computeBetaMoments error: ${abErr}`);
    }
    if (![alpha, beta].every(v => Number.isFinite(v) && v > 0)) {
      throw new Error('Invalid alpha or beta values');
    }

    const range = pessimistic - optimistic;
    const step = range / (numSamples - 1);

    // PDF on regular grid over [O, P]
    const pdf = [];
    for (let i = 0; i < numSamples; i++) {
      const x = optimistic + i * step;
      const u = (x - optimistic) / range; // map to [0,1]
      const y = (u >= 0 && u <= 1) ? betaPdf(u, alpha, beta) / range : 0; // Pure JS PDF
      if (!Number.isFinite(y)) {
        throw new Error(`Invalid PDF value at x=${x}, u=${u}, y=${y}`);
      }
      pdf.push({ x, y });
    }

    // Normalize PDF (trapezoidal)
    let area = 0;
    for (let i = 1; i < pdf.length; i++) {
      const dx = pdf[i].x - pdf[i - 1].x;
      if (!Number.isFinite(dx) || dx <= 0) {
        throw new Error(`Invalid dx in normalization at i=${i}: dx=${dx}`);
      }
      area += 0.5 * (pdf[i].y + pdf[i - 1].y) * dx;
    }
    if (!Number.isFinite(area) || area <= 0) {
      throw new Error('Invalid PDF sum before normalization');
    }
    const nPdf = pdf.map(p => ({ x: p.x, y: p.y / area }));

    // CDF (same-length, cumulative trapezoid)
    const cdf = [];
    let cum = 0;
    for (let i = 0; i < nPdf.length; i++) {
      if (i === 0) {
        cdf.push({ x: nPdf[i].x, y: 0 });
      } else {
        const dx = nPdf[i].x - nPdf[i - 1].x;
        if (!Number.isFinite(dx) || dx <= 0) {
          throw new Error(`Invalid dx in CDF computation at i=${i}: dx=${dx}`);
        }
        cum += 0.5 * (nPdf[i].y + nPdf[i - 1].y) * dx;
        cdf.push({ x: nPdf[i].x, y: Math.max(0, Math.min(1, cum)) });
      }
    }

    console.log('generatePertPoints: Completed', {
      pdfPointsLength: nPdf.length,
      cdfPointsLength: cdf.length
    });

    return { pdfPoints: nPdf, cdfPoints: cdf };
  } catch (error) {
    console.error('generatePertPoints: Error', { message: error.message, stack: error.stack });
    return { pdfPoints: [], cdfPoints: [], error: error.message };
  }
}

module.exports = { generatePertPoints };
