'use strict';

const path = require('path');
const CORE_DIR = path.resolve(__dirname, '..');
const { betaSample } = require('./beta-points'); // Pure JS sample
const { computeBetaMoments } = require('./beta-points');
// FIX: Import validation functions for PDF/CDF checks (resolves ReferenceError)
const { isValidPdfArray, isValidCdfArray } = require(path.join(CORE_DIR, 'helpers', 'validation'));

/**
 * Smooth RAW Monte Carlo samples via Gaussian KDE on a regular grid.
 * If `samples` are provided, uses them directly (preferred).
 * If not provided (fallback), re-samples from Beta(α,β) derived from O/M/P.
 */
async function generateMonteCarloSmoothedPoints(params) {
  console.log('generateMonteCarloSmoothedPoints: Starting', { params: { ...params, samples: Array.isArray(params?.samples) ? `(n=${params.samples.length})` : undefined } });
  console.time('generateMonteCarloSmoothedPoints');
  try {
    const { optimistic, mostLikely, pessimistic, numSamples = 2000, samples: rawSamples } = params;

    if (![optimistic, mostLikely, pessimistic].every(Number.isFinite)) {
      throw new Error('Invalid estimates: must be finite numbers');
    }
    if (optimistic > mostLikely || mostLikely > pessimistic) {
      throw new Error('Estimates must satisfy optimistic <= mostLikely <= pessimistic');
    }
    const range = pessimistic - optimistic;
    if (range <= 0) throw new Error('Degenerate case: single point distribution');
    if (!Number.isFinite(numSamples) || numSamples < 100) {
      throw new Error('Invalid numSamples: must be a number >= 100');
    }

    // Preferred path: reuse provided RAW samples from Beta MC
    let samples = Array.isArray(rawSamples) ? rawSamples.slice() : null;

    // Fallback path
    if (!samples || samples.length === 0) {
      const { alpha, beta } = await computeBetaMoments({ optimistic, mostLikely, pessimistic });
      if (![alpha, beta].every(v => Number.isFinite(v) && v > 0)) {
        throw new Error('Invalid beta parameters: must be finite and positive');
      }
      samples = Array(numSamples).fill().map(() => {
        const u = betaSample(alpha, beta); // Pure JS sample
        const s = optimistic + u * range;
        if (!Number.isFinite(s)) throw new Error('Invalid beta sample (fallback)');
        return s;
      });
    }

    // Clamp any stray values
    samples = samples.map(s => Math.max(optimistic, Math.min(pessimistic, s)));

    // KDE on a grid of 200 points
    const nPoints = 200; // Updated to match MAX_POINTS
    const xMin = optimistic, xMax = pessimistic;
    const dx = (xMax - xMin) / (nPoints - 1);
    const pdf = Array(nPoints).fill().map((_, i) => ({ x: xMin + i * dx, y: 0 }));

    // Bandwidth: h = (P-O)/63.3 for guaranteed non-zero coverage
    const h = range / 63.3;
    const invH = 1 / h;
    const invSqrt2pi = 1 / Math.sqrt(2 * Math.PI);

    for (let i = 0; i < nPoints; i++) {
      const x = pdf[i].x;
      let sum = 0;
      for (const s of samples) {
        const z = (x - s) * invH;
        sum += Math.exp(-0.5 * z * z) * invH * invSqrt2pi;
      }
      const y = sum / samples.length;
      if (!Number.isFinite(y) || y < 0) throw new Error('Invalid KDE value');
      pdf[i].y = y;
    }

    // Normalize PDF
    let integral = 0;
    for (let i = 1; i < nPoints; i++) {
      const ddx = pdf[i].x - pdf[i - 1].x;
      if (!Number.isFinite(ddx) || ddx <= 0) throw new Error('Invalid dx in normalization');
      const y0 = pdf[i - 1].y, y1 = pdf[i].y;
      if (!Number.isFinite(y0) || !Number.isFinite(y1) || y0 < 0 || y1 < 0) {
        throw new Error('Invalid y values in normalization');
      }
      integral += (y0 + y1) / 2 * ddx;
    }
    if (!Number.isFinite(integral) || integral <= 0) throw new Error('Invalid PDF integral');
    const nPdf = pdf.map(p => ({ x: p.x, y: p.y / integral }));

    // CDF (same length as PDF)
    const cdf = [];
    let cum = 0;
    for (let i = 0; i < nPdf.length; i++) {
      if (i === 0) cdf.push({ x: nPdf[i].x, y: 0 });
      else {
        const ddx = nPdf[i].x - nPdf[i - 1].x;
        if (!Number.isFinite(ddx) || ddx <= 0) throw new Error('Invalid dx in CDF computation', { ddx, i });
        cum += (nPdf[i].y + nPdf[i - 1].y) / 2 * ddx;
        cdf.push({ x: nPdf[i].x, y: Math.min(Math.max(cum, 0), 1) });
      }
    }

    if (!isValidPdfArray(nPdf) || !isValidCdfArray(cdf)) {
      throw new Error('Invalid PDF/CDF points generated');
    }

    console.log('generateMonteCarloSmoothedPoints: Completed', {
      pdfPointsLength: nPdf.length, cdfPointsLength: cdf.length
    });
    console.timeEnd('generateMonteCarloSmoothedPoints');
    return { pdfPoints: nPdf, cdfPoints: cdf };
  } catch (error) {
    console.error('generateMonteCarloSmoothedPoints: Error', { message: error.message, stack: error.stack });
    return { pdfPoints: [], cdfPoints: [], error: error.message };
  }
}

module.exports = { generateMonteCarloSmoothedPoints };
