'use strict';

const path = require('path');
const CORE_DIR = path.resolve(__dirname, '..');

// Pure JS log-gamma (Stirling + reflection for accuracy/stability; no jstat)
function logGamma(z) {
  if (z < 0.5) return Math.log(Math.PI) / Math.sin(Math.PI * z) - logGamma(1 - z);
  let sum = 0;
  for (let k = 0; k < 10; k++) sum += 1 / (k + 1) - Math.log(k + z);
  return Math.log(2 * Math.PI) / 2 + (z - 0.5) * Math.log(z) - z + 0.5 * Math.log(2 * Math.PI) + sum;
}

// Pure JS beta PDF: x^{a-1} (1-x)^{b-1} / B(a,b); B=logGamma(a)+logGamma(b)-logGamma(a+b)
function betaPdf(u, alpha, beta) {
  if (u <= 0 || u >= 1 || alpha <= 0 || beta <= 0) return 0;
  const a = alpha - 1;
  const b = beta - 1;
  const num = Math.pow(u, a) * Math.pow(1 - u, b);
  const logB = logGamma(alpha) + logGamma(beta) - logGamma(alpha + beta);
  return num / Math.exp(logB);
}

// Pure JS beta sample (simple rejection sampler; efficient for a,b>1)
function betaSample(alpha, beta) {
  while (true) {
    const u = Math.random();
    const v = Math.random();
    const x = Math.pow(u, 1 / alpha);
    const y = 1 - Math.pow(v, 1 / beta);
    if (x + y <= 1) return x / (x + y);
  }
}

/**
 * Canonical (O, M, P) → (alpha, beta) for Beta-family models (PERT, Beta, MC paths).
 * Returns { alpha, beta } on success, or { alpha: null, beta: null, error } on failure.
 * Consumers should validate finiteness/positivity of alpha/beta.
 */
async function computeBetaMoments(params) {
  console.log('computeBetaMoments: Starting', { params });
  try {
    const { optimistic, mostLikely, pessimistic } = params || {};
    if (![optimistic, mostLikely, pessimistic].every(Number.isFinite)) {
      throw new Error('Invalid estimates: must be finite numbers');
    }
    if (optimistic > mostLikely || mostLikely > pessimistic) {
      throw new Error('Estimates must satisfy optimistic <= mostLikely <= pessimistic');
    }
    const range = pessimistic - optimistic;
    if (range <= 0) {
      throw new Error('Degenerate case: single point distribution');
    }

    // Standard PERT → Beta method-of-moments
    const mean = (optimistic + 4 * mostLikely + pessimistic) / 6;
    const variance = (range / 6) ** 2;
    const scaledMean = (mean - optimistic) / range;
    const scaledVariance = variance / (range ** 2);

    const denom = scaledMean * (1 - scaledMean) / Math.max(scaledVariance, 1e-12) - 1; // Guard denom=0
    const alpha = scaledMean * denom;
    const beta  = (1 - scaledMean) * denom;

    if (!Number.isFinite(alpha) || !Number.isFinite(beta) || alpha <= 0 || beta <= 0) {
      throw new Error('Invalid alpha or beta values');
    }

    console.log('computeBetaMoments: Completed', { alpha, beta });
    return { alpha, beta };
  } catch (error) {
    console.error('computeBetaMoments: Error', { message: error.message, stack: error.stack });
    return { alpha: null, beta: null, error: error.message };
  }
}

/**
 * Generate Beta PDF & CDF from O/M/P via (alpha, beta) on a regular grid.
 * Returns { pdfPoints, cdfPoints } or { pdfPoints:[], cdfPoints:[], error } on failure.
 */
async function generateBetaPoints(params) {
  console.log('generateBetaPoints: Starting', { params });
  try {
    const { optimistic, mostLikely, pessimistic, numSamples = 200, alpha, beta } = params || {};

    if (![optimistic, mostLikely, pessimistic].every(Number.isFinite)) {
      throw new Error('Invalid estimates: must be finite numbers');
    }
    if (optimistic > mostLikely || mostLikely > pessimistic) {
      throw new Error('Estimates must satisfy optimistic <= mostLikely <= pessimistic');
    }
    const range = pessimistic - optimistic;
    if (range <= 0) {
      throw new Error('Degenerate case: single point distribution');
    }
    if (!Number.isFinite(numSamples) || numSamples < 2) {
      throw new Error('Invalid numSamples: must be a number >= 2');
    }
    if (!Number.isFinite(alpha) || !Number.isFinite(beta) || alpha <= 0 || beta <= 0) {
      throw new Error('Invalid alpha or beta values');
    }

    const step = range / (numSamples - 1);
    const pdfPoints = [];
    for (let i = 0; i < numSamples; i++) {
      const x = optimistic + i * step;
      const u = (x - optimistic) / range; // map to [0,1]
      const y = (u >= 0 && u <= 1) ? betaPdf(u, alpha, beta) / range : 0; // Pure JS PDF
      if (!Number.isFinite(y) || y < 0) {
        throw new Error(`Invalid PDF value at x=${x}, u=${u}, y=${y}`);
      }
      pdfPoints.push({ x, y });
    }

    // Normalize PDF
    let sum = 0;
    for (let i = 1; i < pdfPoints.length; i++) {
      const dx = pdfPoints[i].x - pdfPoints[i - 1].x;
      if (!Number.isFinite(dx) || dx <= 0) {
        throw new Error(`Invalid dx in normalization at i=${i}: dx=${dx}`);
      }
      sum += 0.5 * (pdfPoints[i].y + pdfPoints[i - 1].y) * dx;
    }
    if (!Number.isFinite(sum) || sum <= 0) {
      throw new Error('Invalid PDF sum before normalization');
    }
    const normalizedPdfPoints = pdfPoints.map(p => ({ x: p.x, y: p.y / sum }));

    // CDF (same length as PDF)
    const cdfPoints = [];
    let cumulative = 0;
    for (let i = 0; i < normalizedPdfPoints.length; i++) {
      if (i === 0) {
        cdfPoints.push({ x: normalizedPdfPoints[i].x, y: 0 });
      } else {
        const dx = normalizedPdfPoints[i].x - normalizedPdfPoints[i - 1].x;
        if (!Number.isFinite(dx) || dx <= 0) {
          throw new Error(`Invalid dx in CDF computation at i=${i}: dx=${dx}`);
        }
        cumulative += 0.5 * (normalizedPdfPoints[i].y + normalizedPdfPoints[i - 1].y) * dx;
        cdfPoints.push({ x: normalizedPdfPoints[i].x, y: Math.max(0, Math.min(1, cumulative)) });
      }
    }

    console.log('generateBetaPoints: Completed', {
      pdfPointsLength: normalizedPdfPoints.length,
      cdfPointsLength: cdfPoints.length
    });
    return { pdfPoints: normalizedPdfPoints, cdfPoints };
  } catch (error) {
    console.error('generateBetaPoints: Error', { message: error.message, stack: error.stack });
    return { pdfPoints: [], cdfPoints: [], error: error.message };
  }
}

module.exports = { computeBetaMoments, generateBetaPoints, betaPdf, betaSample }; // Export pure JS funcs
