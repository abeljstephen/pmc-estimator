'use strict';

const path = require('path');
const CORE_DIR = path.resolve(__dirname, '..');

// Import pure JS betaSample from beta-points
const { betaSample } = require('./beta-points');
const { computeBetaMoments } = require('./beta-points');

/**
 * Generate RAW Monte Carlo points by sampling Beta(α,β) mapped to [O,P].
 * Returns histogram-based PDF/CDF *and* the underlying samples array.
 */
async function generateMonteCarloRawPoints(params) {
  console.log('generateMonteCarloRawPoints: Starting', { params });
  try {
    const { optimistic, mostLikely, pessimistic, numSamples = 1000 } = params;

    if (![optimistic, mostLikely, pessimistic].every(Number.isFinite)) {
      throw new Error('Invalid estimates: must be finite numbers');
    }
    if (optimistic > mostLikely || mostLikely > pessimistic) {
      throw new Error('Estimates must satisfy optimistic <= mostLikely <= pessimistic');
    }
    const range = pessimistic - optimistic;
    if (range <= 0) throw new Error('Degenerate case: single point distribution');
    if (!Number.isFinite(numSamples) || numSamples < 2) throw new Error('Invalid numSamples: must be a number >= 2');

    // Always compute alpha/beta from O/M/P here (progression requirement)
    const { alpha, beta } = await computeBetaMoments({ optimistic, mostLikely, pessimistic });
    if (!Number.isFinite(alpha) || !Number.isFinite(beta) || alpha <= 0 || beta <= 0) {
      throw new Error('Invalid alpha or beta values');
    }

    // Draw samples from Beta(α,β) on [0,1] and map to [O,P] using pure JS sampler
    const samples = [];
    for (let i = 0; i < numSamples; i++) {
      const u = betaSample(alpha, beta); // Pure JS sample
      const s = optimistic + u * range;
      if (!Number.isFinite(u) || !Number.isFinite(s)) throw new Error('Invalid Monte Carlo sample');
      samples.push(s);
    }

    // PATCH: Adaptive bins: Coarsen if sparse (range < 500 → fewer bins)
    const effectiveSamples = Math.max(50, Math.min(numSamples, Math.ceil(range / 10))); // step~10 min
    const step = range / (effectiveSamples - 1);
    const hist = new Array(effectiveSamples).fill(0);

    // Bin samples for PDF (histogram density)
    for (const s of samples) {
      const idx = Math.min(effectiveSamples - 1, Math.max(0, Math.floor((s - optimistic) / step)));
      hist[idx]++;
    }

    // PDF points: Mid-bin x, normalized density y = count / (n * width)
    const pdfPoints = hist.map((count, i) => {
      const x = optimistic + (i + 0.5) * step;
      const y = count / (numSamples * step);
      return { x, y };
    });

    // CDF points: Empirical from sorted samples (x=sample, y=rank/n)
    const sortedSamples = samples.slice().sort((a, b) => a - b);
    const cdfPoints = sortedSamples.map((s, i) => ({ x: s, y: i / numSamples }));

    console.log('generateMonteCarloRawPoints: Completed', {
      pdfPointsLength: pdfPoints.length, cdfPointsLength: cdfPoints.length, samplesLength: samples.length
    });

    return { pdfPoints, cdfPoints, samples: sortedSamples };
  } catch (error) {
    console.error('generateMonteCarloRawPoints: Error', { message: error.message, stack: error.stack });
    return { pdfPoints: [], cdfPoints: [], samples: [], error: error.message };
  }
}

module.exports = { generateMonteCarloRawPoints };
