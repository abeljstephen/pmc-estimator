// core/optimization/matrix-utils.js
/*
 * Small helpers for distribution validation & alignment.
 *
 * Change (2025-09-18):
 * - Made alignPoints() robust to zero/invalid step sizes by falling back to a
 *   derived step from the total span and max array length. This prevents rare
 *   grid explosions when the first two x's are identical in either input.
 */

'use strict';

const path = require('path');
const CORE_DIR = path.resolve(__dirname, '..');
const { isValidPdfArray, isValidCdfArray, createErrorResponse } =
  require(path.join(CORE_DIR, 'helpers/validation'));

function generateUniquePairs(distNames) {
  if (!Array.isArray(distNames) || distNames.length < 2) {
    throw createErrorResponse('distNames must have at least 2 elements');
  }
  const pairs = [];
  for (let i = 0; i < distNames.length; i++) {
    for (let j = i + 1; j < distNames.length; j++) {
      pairs.push(`${distNames[i]}-${distNames[j]}`);
    }
  }
  return pairs;
}

function validateDistributionInputs(distributions, isCdf = false) {
  if (!distributions || Object.keys(distributions).length === 0) {
    throw createErrorResponse('Invalid distributions');
  }
  for (const [, points] of Object.entries(distributions)) {
    const ok = isCdf ? isValidCdfArray(points) : isValidPdfArray(points);
    if (!ok) throw createErrorResponse('Invalid points for distribution');
  }
  return true;
}

function alignPoints(p, q) {
  if (!isValidPdfArray(p) || !isValidPdfArray(q)) {
    throw createErrorResponse('Invalid point arrays');
  }

  const xMin = Math.min(p[0].x, q[0].x);
  const xMax = Math.max(p[p.length - 1].x, q[q.length - 1].x);

  // Try to infer a sane step; guard against zero/NaN
  const dp = p.length > 1 ? (p[1].x - p[0].x) : NaN;
  const dq = q.length > 1 ? (q[1].x - q[0].x) : NaN;
  const candidates = [dp, dq].filter(v => Number.isFinite(v) && v > 0);
  let step = candidates.length ? Math.min(...candidates) / 2 : NaN;
  if (!Number.isFinite(step) || step <= 0) {
    const maxLen = Math.max(p.length, q.length, 50);
    const span = Math.max(1e-9, xMax - xMin);
    step = span / (maxLen * 2);
  }

  const n = Math.max(2, Math.ceil((xMax - xMin) / step) + 1);
  const newX = Array.from({ length: n }, (_, i) => xMin + i * step);

  const lerp = (A, x) => {
    if (x <= A[0].x) return A[0].y;
    if (x >= A[A.length - 1].x) return A[A.length - 1].y;
    for (let i = 0; i < A.length - 1; i++) {
      if (A[i].x <= x && x <= A[i + 1].x) {
        const t = (x - A[i].x) / (A[i + 1].x - A[i].x || 1);
        return A[i].y + t * (A[i + 1].y - A[i].y);
      }
    }
    return 0;
  };

  const alignedP = newX.map(x => ({ x, y: lerp(p, x) }));
  const alignedQ = newX.map(x => ({ x, y: lerp(q, x) }));
  return [alignedP, alignedQ];
}

module.exports = { generateUniquePairs, validateDistributionInputs, alignPoints };

