'use strict';

const path = require('path');
const CORE_DIR = path.resolve(__dirname, '..');

const { generateBaseline } = require(path.join(CORE_DIR, 'baseline', 'coordinator'));
const { computeSliderProbability, reshapeDistribution } = require(path.join(CORE_DIR, 'reshaping', 'slider-adjustments'));
const { optimizeSliders, pickOptimizedSliders, toReportEntry } = require(path.join(CORE_DIR, 'optimization', 'optimizer'));
const { validateEstimates, validateSliders, isValidPdfArray, isValidCdfArray } = require(path.join(CORE_DIR, 'helpers', 'validation'));
const { interpolateCdf, calculateMetrics } = require(path.join(CORE_DIR, 'helpers', 'metrics'));
const { computeKLDivergence } = require(path.join(CORE_DIR, 'optimization', 'kl-divergence'));

// CSV + summaries builder (also returns an optional reports[] now)
const { buildReports } = require(path.join(CORE_DIR, 'report', 'reshaping_report'));

/**
 * NOTE: Preflight in deploy_pmc_api.js expects this exact string:
 *   SCHEMA_VERSION = '2025-10-16.api-envelope.v1'
 * Do not change unless you also update the deploy script.
 */
const SCHEMA_VERSION = '2025-10-16.api-envelope.v1';
const MAX_POINTS = 200;

const BUILD_INFO = {
  name: 'core-main-2025-10-16.api-envelope.v1',
  tag: 'saco-v1.9.8',  // PATCH: Match mock/deploy for verification
  commit: process.env.GIT_COMMIT || null,
  builtAt: new Date().toISOString(),
  randomSeed: process.env.PMC_RANDOM_SEED || null
};

/* ------------------------------------------------------------------ *
 *                              Utilities
 * ------------------------------------------------------------------ */
function raise(message, details = {}) {
  /**
   * Raise a structured error.
   * @param {string} message - Error message.
   * @param {Object} details - Extra details.
   * FAILSAFE: Ensures consistent error shape for response.
   */
  const err = new Error(message || 'Unknown error');
  err.details = details;
  throw err;
}

function extractError(e) {
  /**
   * Extract message/details from error.
   * @param {Error|any} e - Input error.
   * @returns {Object} {message, details, stack}.
   * FAILSAFE: Handles non-Error objects.
   */
  const message = (e && (e.message || e.error)) || (typeof e === 'string' ? e : 'Unknown error');
  const details = (e && (e.details || e)) || {};
  const stack = e && e.stack ? e.stack : undefined;
  return { message, details, stack };
}

function clipPoints(arr) {
  /**
   * Clip array to max length.
   * @param {Array} arr - Input array.
   * @returns {Array} Sliced [0, MAX_POINTS].
   * FAILSAFE: Returns [] on invalid input.
   */
  if (!Array.isArray(arr)) return [];
  return arr.slice(0, MAX_POINTS);
}

function coercePercent01(x) {
  /**
   * Coerce to [0,1].
   * @param {*} x - Input.
   * @returns {number} Clamped [0,1].
   * FAILSAFE: NaN → 0.
   */
  return Math.max(0, Math.min(1, Number(x)));
}

function asPointsArray(maybe) {
  /**
   * Extract array from value or {value: array}.
   * @param {*} maybe - Input (array or {value: array}).
   * @returns {Array} Extracted array, or [] if invalid.
   * FAILSAFE: Handles legacy wrappers or nulls gracefully.
   */
  if (Array.isArray(maybe)) return maybe;
  if (maybe && Array.isArray(maybe.value)) return maybe.value;
  return [];
}

/* ------------------------------------------------------------------ *
 *                           Task processing
 * ------------------------------------------------------------------ */
async function processTask(task) {
  /**
   * Process single task: baseline + adjusted + optional optimize.
   * @param {Object} task - Task params.
   * @returns {Object} Response envelope.
   * FAILSAFES: Validates inputs early; pass-through on all-zero; no synthetic fallbacks; clear error states.
   */
  try {
    // Define state for task processing (e.g., for sims/metrics; adjust if context differs)
    const state = {
      sims: [],  // Monte Carlo simulations array
      metrics: {},  // CI, probs, etc.
      taskEcho: task?.task || 'Unnamed',
      pertMean: (task.optimistic + 4 * task.mostLikely + task.pessimistic) / 6,  // PERT calc
    };

    // Define SLIDER_KEYS for SACO sliders (v1.9.7: 7 standard keys; used in fixed/adaptive flows)
    const SLIDER_KEYS = [
      'budgetFlexibility',
      'scheduleFlexibility',
      'scopeCertainty',
      'scopeReductionAllowance',
      'reworkPercentage',
      'riskTolerance',
      'userConfidence'
    ];

    const {
      task: taskName,
      optimistic, mostLikely, pessimistic,
      targetValue,
      confidenceLevel = 0.95,
      optimize = true,
      optimizeFor = 'target',
      sliderValues: inputSliders = {},
      suppressOtherDistros = false,
      mode = (optimize ? 'opt' : 'view'),
      randomSeed = BUILD_INFO.randomSeed || Date.now().toString(),
      adaptive = true,  // Dual-mode support
      probeLevel = 5    // Default probe=5 (1-7 range)
    } = task || {};

    const hasTarget = Number.isFinite(targetValue);

    // ----- Input validation -----
    const estVal = validateEstimates(optimistic, mostLikely, pessimistic);
    if (!estVal.valid) raise(estVal.message || 'Invalid estimates', { optimistic, mostLikely, pessimistic });
    if (!(confidenceLevel > 0 && confidenceLevel < 1)) raise('Invalid confidenceLevel', { confidenceLevel });
    if (!['target', 'mean', 'risk'].includes(optimizeFor)) raise('Invalid optimizeFor', { optimizeFor });
    if (adaptive && (probeLevel < 1 || probeLevel > 7)) raise('probeLevel must be 1-7 for adaptive', { probeLevel });

    // ----- Sliders (normalized) -----
    const slidersInit = {
      budgetFlexibility: Number(inputSliders.budgetFlexibility) || 0,
      scheduleFlexibility: Number(inputSliders.scheduleFlexibility) || 0,
      scopeCertainty: Number(inputSliders.scopeCertainty) || 0,
      scopeReductionAllowance: Number(inputSliders.scopeReductionAllowance) || 0,
      reworkPercentage: Number(inputSliders.reworkPercentage) || 0,
      riskTolerance: Number(inputSliders.riskTolerance) || 0,
      userConfidence: Number.isFinite(inputSliders.userConfidence) ? inputSliders.userConfidence : 100, // neutral confidence default
    };
    const sliderVal = validateSliders(slidersInit);
    if (!sliderVal.valid) raise(sliderVal.message || 'Invalid sliders', { slidersInit });

    // ----- Baseline -----
    const baselineRaw = await generateBaseline({
      optimistic, mostLikely, pessimistic, numSamples: MAX_POINTS, suppressOtherDistros, randomSeed
    });
    if (baselineRaw?.error) raise(`generateBaseline failed: ${baselineRaw.error}`, baselineRaw.details || {});

    // Flexible mapping for producer drift, but still real data only
    const mcBlock =
      baselineRaw?.monteCarloSmoothedPoints ||
      baselineRaw?.monteCarloSmoothed ||
      baselineRaw?.monteCarlo ||
      baselineRaw?.distributions?.monteCarloSmoothed ||
      null;

    const pdf = asPointsArray(mcBlock?.pdfPoints) || asPointsArray(mcBlock?.pdf);
    const cdf = asPointsArray(mcBlock?.cdfPoints) || asPointsArray(mcBlock?.cdf);

    if (!isValidPdfArray(pdf) || !isValidCdfArray(cdf)) {
      raise('Invalid MC-smoothed points', {
        havePdf: Array.isArray(pdf) ? pdf.length : 0,
        haveCdf: Array.isArray(cdf) ? cdf.length : 0,
        availableKeys: Object.keys(baselineRaw || {})
      });
    }

    // Other distributions (optional, clipped safely)
    const triangleBlock = baselineRaw.trianglePoints || baselineRaw.triangle || baselineRaw?.distributions?.triangle;
    const betaPertBlock = baselineRaw.pertPoints || baselineRaw.betaPert || baselineRaw?.distributions?.betaPert;

    const trianglePdfPoints = asPointsArray(triangleBlock?.pdfPoints) || asPointsArray(triangleBlock?.pdf);
    const triangleCdfPoints = asPointsArray(triangleBlock?.cdfPoints) || asPointsArray(triangleBlock?.cdf);
    const betaPertPdfPoints  = asPointsArray(betaPertBlock?.pdfPoints) || asPointsArray(betaPertBlock?.pdf);
    const betaPertCdfPoints  = asPointsArray(betaPertBlock?.cdfPoints) || asPointsArray(betaPertBlock?.cdf);

    // Metrics (PERT & CI)
    const metrics = calculateMetrics({
      optimistic, mostLikely, pessimistic,
      triangle: trianglePdfPoints.length ? { pdfPoints: trianglePdfPoints, cdfPoints: triangleCdfPoints } : undefined,
      monteCarloSmoothed: { pdfPoints: pdf, cdfPoints: cdf },
      confidenceLevel,
      robustStd: adaptive ? (state?.robustStd || 0) : 0
    });
    if (metrics?.error) raise(`calculateMetrics failed: ${metrics.error}`, metrics.details || {});
    const pertMean = Number(metrics?.pert?.mean);
    const ciLower  = Number(metrics?.monteCarloSmoothed?.ci?.lower);
    const ciUpper  = Number(metrics?.monteCarloSmoothed?.ci?.upper);

    // Baseline probabilities
    const baseProb = hasTarget ? coercePercent01(interpolateCdf(cdf, targetValue).value) : null;
    const baselineProbAtPert = Number.isFinite(pertMean) ? coercePercent01(interpolateCdf(cdf, pertMean).value) : undefined;

    // KL divergence (best-effort)
    let klToTriangle;
    try {
      if (trianglePdfPoints.length && pdf.length) {
        const klObj = computeKLDivergence({
          distributions: { triangle: { pdfPoints: trianglePdfPoints }, monteCarloSmoothed: { pdfPoints: pdf } },
          task: taskName || ''
        });
        if (klObj && typeof klObj === 'object') {
          klToTriangle = Number(klObj['triangle-monteCarloSmoothed'] ?? klObj.value ?? klObj.kl ?? klObj.klDivergence);
        }
      }
    } catch (_) {}

    // ----- Adjusted (manual sliders) -----
    // IMPORTANT: we NEVER mutate baseline arrays. We always use computeSliderProbability,
    // which guarantees pass-through when sliders are all zero.
    const adjRes = await computeSliderProbability({
      points: { pdfPoints: pdf, cdfPoints: cdf },
      optimistic, mostLikely, pessimistic, targetValue,
      sliderValues: slidersInit,
      probeLevel: 0  // Explicit probe=0 for manual
    }).catch(err => ({ error: err.message, explain: { narrative: `Manual adjustment error: ${err.message}. Falling back to baseline.` } }));

    const adjustedBlock = (!adjRes || adjRes.error)
      ? { status: 'error', reasonCode: 'adjusted_error', message: adjRes?.error || 'Unknown adjusted error', explain: null }
      : {
          status: 'ok',
          probabilityAtTarget: { value: hasTarget ? coercePercent01(adjRes.probability?.value) : undefined },
          reshapedPoints: {
            pdfPoints: clipPoints(adjRes.reshapedPoints?.pdfPoints || pdf),
            cdfPoints: clipPoints(adjRes.reshapedPoints?.cdfPoints || cdf)
          },
          explain: adjRes.explain || null
        };

    const allZeroPassThrough =
      !!(adjustedBlock.explain && String(adjustedBlock.explain.allZeroSlidersPassThrough || '').toLowerCase() === 'yes');

    // ----- Optimization (optional) -----
    let optimizeBlock = { status: 'skipped', reasonCode: !optimize ? 'optimize_false' : 'not_requested' };

    // We may need to write these after response exists
    let __tp_adjustedOptimized;
    let __tp_adaptiveOptimized;
    let __manualOptimizeBlock;

    if (optimize) {
      const optRes = await optimizeSliders({
        points: { pdfPoints: pdf, cdfPoints: cdf },
        optimistic, mostLikely, pessimistic,
        targetValue: Number.isFinite(targetValue) ? targetValue : pertMean,
        optimizeFor,
        distributionType: 'monte-carlo-smoothed',
        randomSeed,
        adaptive,
        probeLevel
      });

      if (!optRes || optRes.error) {
        console.warn('OPT ERROR: Optimizer failed', optRes?.error);
        optimizeBlock = {
          status: 'error',
          reasonCode: 'optimize_failed',
          message: optRes?.error || 'Unknown optimizer error'
        };
      } else {
        const sliders = pickOptimizedSliders(optRes);
        const reshaped = optRes?.optimizedResult?.reshapedPoints || optRes?.reshapedPoints || null;

        let optPdf = asPointsArray(reshaped?.monteCarloSmoothed?.pdfPoints) || asPointsArray(reshaped?.pdfPoints);
        let optCdf = asPointsArray(reshaped?.monteCarloSmoothed?.cdfPoints) || asPointsArray(reshaped?.cdfPoints);
        let optProb = Number(optRes?.optimizedResult?.probability?.value);
        if (!Number.isFinite(optProb)) optProb = Number(optRes?.probability?.value);

        // Fallback reshape if points missing (real recalculation, no fabrication)
        if ((!Array.isArray(optPdf) || !optPdf.length || !Array.isArray(optCdf) || !optCdf.length) && sliders) {
          const mat = await reshapeDistribution({
            points: { pdfPoints: pdf, cdfPoints: cdf },
            optimistic, mostLikely, pessimistic,
            targetValue: Number.isFinite(targetValue) ? targetValue : pertMean,
            sliderValues: sliders
          });
          if (!mat?.error) {
            optPdf = asPointsArray(mat?.reshapedPoints?.pdfPoints);
            optCdf = asPointsArray(mat?.reshapedPoints?.cdfPoints);
            if (!Number.isFinite(optProb)) optProb = Number(mat?.probability?.value);
            if (mat?.explain && !optRes.explain) optRes.explain = mat.explain;
          } else {
            // If the fallback reshape fails, use baseline points (still real data)
            optPdf = pdf.slice();
            optCdf = cdf.slice();
          }
        }

        // Robust adjProb/sensChange calculation
        const tgt = Number.isFinite(targetValue) ? targetValue : pertMean;
        const baseAtSameTarget = Number.isFinite(tgt) ? coercePercent01(interpolateCdf(cdf, tgt).value) : 0.5;
        let adjProb = Number.isFinite(optProb) ? coercePercent01(optProb) : undefined;

        // Interpolate from optimized CDF if no explicit probability in optimizer result
        if (!Number.isFinite(adjProb)) {
          const optCdfRaw = asPointsArray(optRes?.optimizedResult?.reshapedPoints?.cdfPoints || optRes?.reshapedPoints?.cdfPoints);
          if (Array.isArray(optCdfRaw) && optCdfRaw.length >= 2) {
            const interpCdf = optCdfRaw.slice().sort((a, b) => a.x - b.x); // Ensure sorted (monotone)
            const interpRes = interpolateCdf(interpCdf, tgt);
            adjProb = Number.isFinite(interpRes.value) ? coercePercent01(interpRes.value) : undefined;
          }
        }

        // If still undefined, mark error state (no synthetic defaults)
        if (!Number.isFinite(adjProb)) {
          optimizeBlock = {
            status: 'error',
            reasonCode: 'probability_missing',
            message: 'Optimizer did not return a valid probability and interpolation failed.',
            reshapedPoints: { pdfPoints: clipPoints(optPdf || pdf), cdfPoints: clipPoints(optCdf || cdf) },
            sliders: sliders || {}
          };
        } else {
          const sensChange = adjProb - baseAtSameTarget;

          // Build explain (real numbers only)
          let explain = optRes.explain;
          if (explain) {
            if (!Number.isFinite(explain.baselineProb)) explain.baselineProb = baseAtSameTarget;
            if (!Number.isFinite(explain.finalProb))    explain.finalProb    = adjProb;
            if (!explain.mode) explain.mode = adaptive ? 'saco-adaptive' : 'saco-fixed';
            if (typeof explain.probeLevel === 'undefined') explain.probeLevel = probeLevel;
          } else {
            explain = {
              baselineProb: baseAtSameTarget,
              finalProb: adjProb,
              narrative: 'Optimization completed with computed probability.',
              mode: adaptive ? 'saco-adaptive' : 'saco-fixed',
              probeLevel,
              sliders: [],
              winningSliders: sliders || {}
            };
            optRes.explain = explain;
          }

          // Final optimize block (success)
          optimizeBlock = {
            status: optRes.status || 'ok',
            sliders: sliders || {},
            probabilityAtTarget: { value: adjProb },
            reshapedPoints: {
              pdfPoints: clipPoints(optPdf || pdf),
              cdfPoints: clipPoints(optCdf || cdf)
            },
            metrics: { sensitivityChange: sensChange },
            explain: explain,
            certificate: (typeof optRes.certificate === 'string'
              ? optRes.certificate
              : (optRes.certificate ? JSON.stringify(optRes.certificate) : undefined))
          };

          __tp_adjustedOptimized = adjProb;
          __tp_adaptiveOptimized = adaptive ? adjProb : undefined;
        }
      }
    }

    // Manual Specific (add after adjustedBlock, if probeLevel===0)
    if (probeLevel === 0) {
      const manualPdf = adjustedBlock.reshapedPoints?.pdfPoints || pdf;
      const manualCdf = adjustedBlock.reshapedPoints?.cdfPoints || cdf;
      const manualBlock = {
        status: 'manual',
        sliders: slidersInit,  // Use input or zeros
        scaledSliders: slidersInit,  // Mirror %
        normalizedSliders: slidersInit,
        reshapedPoints: { pdfPoints: clipPoints(manualPdf), cdfPoints: clipPoints(manualCdf) },
        explain: {
          narrative: 'Manual mode: User sliders applied (pass-through if zero).',
          probeLevel: 0
        }
      };
      __manualOptimizeBlock = manualBlock;
      if (baseProb !== undefined && baseProb !== null) {
        __tp_adjustedOptimized = baseProb;  // manual uses baseline prob at target unless adjusted prob exists
        __tp_adaptiveOptimized = adaptive ? baseProb : undefined;
      }
    }

    // ----- Response envelope (plus debug) -----
    const response = {
      schemaVersion: SCHEMA_VERSION,
      buildInfo: BUILD_INFO,
      taskEcho: { task: taskName, optimistic, mostLikely, pessimistic, targetValue, confidenceLevel, randomSeed, adaptive, probeLevel },  // Echo probeLevel

      flags: {
        allZeroPassThrough,
        hasTarget: hasTarget
      },

      baseline: {
        status: 'ok',
        pert: { value: Number.isFinite(pertMean) ? pertMean : undefined },
        probabilityAtTarget: { value: hasTarget ? baseProb : undefined },
        probabilityAtPert: { value: baselineProbAtPert },
        monteCarloSmoothed: { pdfPoints: clipPoints(pdf), cdfPoints: clipPoints(cdf) },
        metrics: {
          monteCarloSmoothed: { ci: { lower: ciLower, upper: ciUpper } },
          klDivergenceToTriangle: Number.isFinite(klToTriangle) ? klToTriangle : undefined
        }
      },

      trianglePdf: { value: clipPoints(trianglePdfPoints) },
      triangleCdf: { value: clipPoints(triangleCdfPoints) },
      betaPertPdf: { value: clipPoints(betaPertPdfPoints) },
      betaPertCdf: { value: clipPoints(betaPertCdfPoints) },

      adjusted: adjustedBlock,
      optimize: optimizeBlock,

      optimalSliderSettings: optimizeBlock.sliders ? { value: optimizeBlock.sliders } : { value: {} },

      // Debug presence flags (handy in harness)
      debugPresence: {
        baseline: {
          pdf: Array.isArray(pdf) && pdf.length > 0,
          cdf: Array.isArray(cdf) && cdf.length > 0
        },
        optimized: {
          sliders: !!optimizeBlock.sliders && Object.keys(optimizeBlock.sliders).length > 0,
          pdf: Array.isArray(optimizeBlock?.reshapedPoints?.pdfPoints) && optimizeBlock.reshapedPoints.pdfPoints.length > 0,
          cdf: Array.isArray(optimizeBlock?.reshapedPoints?.cdfPoints) && optimizeBlock.reshapedPoints.cdfPoints.length > 0
        }
      }
    };

    // ---------------- Back-compat aliases & convenience fields ----------------
    response.allDistributions = {
      value: {
        monteCarloSmoothed: response.baseline.monteCarloSmoothed,
        triangle: trianglePdfPoints.length
          ? { pdfPoints: clipPoints(trianglePdfPoints), cdfPoints: clipPoints(triangleCdfPoints) }
          : undefined,
        betaPert:  betaPertPdfPoints.length
          ? { pdfPoints: clipPoints(betaPertPdfPoints),  cdfPoints: clipPoints(betaPertCdfPoints)  }
          : undefined
      }
    };
    response.monteCarloSmoothed = response.baseline.monteCarloSmoothed;
    response.monteCarloSmoothedPoints = response.baseline.monteCarloSmoothed;

    response.pertMean = { value: response.baseline.pert.value };
    if (!response.targetProbability) response.targetProbability = { value: {} };
    if (baseProb !== undefined && baseProb !== null) response.targetProbability.value.original = baseProb;
    response.targetProbability.value.adjusted = hasTarget
      ? (response.adjusted?.probabilityAtTarget?.value ?? response.baseline.probabilityAtTarget.value)
      : undefined;

    // AFTER response exists: apply any deferred targetProbability writes
    if (__tp_adjustedOptimized != null) {
      response.targetProbability.value.adjustedOptimized = __tp_adjustedOptimized;
    } else if (hasTarget) {
      response.targetProbability.value.adjustedOptimized =
        response.optimize?.probabilityAtTarget?.value ?? response.baseline.probabilityAtTarget.value;
    }

    if (__tp_adaptiveOptimized != null) {
      response.targetProbability.value.adaptiveOptimized = __tp_adaptiveOptimized;
    } else if (adaptive && hasTarget) {
      response.targetProbability.value.adaptiveOptimized =
        response.optimize?.probabilityAtTarget?.value ?? response.baseline.probabilityAtTarget.value;
    }

    response.targetProbabilityOriginalPdf = { value: response.baseline.monteCarloSmoothed.pdfPoints };
    response.targetProbabilityOriginalCdf = { value: response.baseline.monteCarloSmoothed.cdfPoints };
    response.targetProbabilityAdjustedPdf = {
      value: response.adjusted?.reshapedPoints?.pdfPoints || response.baseline.monteCarloSmoothed.pdfPoints
    };
    response.targetProbabilityAdjustedCdf = {
      value: response.adjusted?.reshapedPoints?.cdfPoints || response.baseline.monteCarloSmoothed.cdfPoints
    };

    // Optimized mirrors for frontend convenience
    response.optimizedReshapedPoints = response.optimize?.reshapedPoints || null;

    // Explain mirrors (create after blocks exist)
    response.explain = { adjusted: response.adjusted?.explain || null, optimized: response.optimize?.explain || null };
    if (adaptive) {
      if (response.explain && response.explain.adaptive == null) {
        response.explain.adaptive = response.explain.optimized ?? null;
      }
    }

    // Populate dual-mode convenience fields safely
    if (optimize && optimizeBlock.status === 'ok') {
      if (adaptive) {
        response.adaptiveReshapedPoints = optimizeBlock.reshapedPoints;
        response.explain.adaptive = optimizeBlock.explain;
        response.adaptiveOptimalSliderSettings = { value: optimizeBlock.sliders || {} };
      } else {
        response.optimizedReshapedPoints = optimizeBlock.reshapedPoints; // keep classic name for fixed too
        response.explain.optimized = optimizeBlock.explain;
        response.optimalSliderSettings = { value: optimizeBlock.sliders || {} };
      }
      // Back-compat defaults
      response.optimizedReshapedPoints = response.optimizedReshapedPoints || response.adaptiveReshapedPoints || null;
      response.optimalSliderSettings   = response.optimalSliderSettings   || response.adaptiveOptimalSliderSettings || { value: {} };
    }

    // If manual block was deferred, attach it now without fabricating values
    if (__manualOptimizeBlock) {
      response.optimize = __manualOptimizeBlock;
    }

    // ---------------- CSV + summaries + reports[] ----------------
    const taskMeta = { task: taskName, optimistic, mostLikely, pessimistic, targetValue, confidenceLevel };
    const reportsBundle = buildReports({
      taskMeta,
      baseline: response.baseline,
      adjusted: response.adjusted,
      optimized: response.optimize,
      mode: mode === 'opt' ? 'opt' : 'view'
    });

    // classic bundle object (baselineCsv/decisionCsv/summaries/meta)
    response.decisionReportsBundle = {
      baselineCsv: reportsBundle.baselineCsv,
      decisionCsv: reportsBundle.decisionCsv,
      summaries: reportsBundle.summaries,
      meta: reportsBundle.meta
    };

    // ALSO expose decisionCsv & summaries at the top level (back-compat)
    response.decisionCsv = reportsBundle.decisionCsv;
    response.summaries = reportsBundle.summaries;

    // NEW: reports[] entries for the UI "Decision report" pane
    const reportsArray = [];
    if (response.adjusted?.explain) {
      reportsArray.push(toReportEntry(
        'Adjusted',
        Number.isFinite(targetValue) ? targetValue : mostLikely,
        response.adjusted.explain.baselineProb,
        response.adjusted.explain.finalProb,
        response.adjusted.explain,
        null
      ));
    }
    if (response.optimize?.explain) {
      reportsArray.push(toReportEntry(
        'Optimize',
        Number.isFinite(targetValue) ? targetValue : mostLikely,
        response.optimize.explain.baselineProb,
        response.optimize.explain.finalProb,
        response.optimize.explain,
        response.optimize.certificate
      ));
    }
    response.decisionReports = reportsArray.filter(Boolean); // this is the array your Plot.html expects

    return response;
  } catch (e) {
    const { message, details, stack } = extractError(e);
    return { schemaVersion: SCHEMA_VERSION, buildInfo: BUILD_INFO, error: message, details, stack };
  }
}

/* ------------------------------------------------------------------ *
 *                              API entry
 * ------------------------------------------------------------------ */
async function pmcEstimatorAPI(tasks) {
  /**
   * Main API handler: Process array of tasks in parallel-safe sequence.
   * @param {Array<Object>} tasks - Array of task objects.
   * @returns {Object} {results: Array, error: string|null, details: Object, feedbackMessages: Array}.
   * FAILSAFES: Processes each task independently; aggregates errors without halting; empty tasks → structured error.
   */
  try {
    if (!Array.isArray(tasks) || tasks.length === 0) raise('Tasks must be a non-empty array', { tasks });
    const results = [];
    const feedbackMessages = [];
    for (const t of tasks) {
      const r = await processTask(t);  // safely awaited
      results.push(r);
      if (r?.error) feedbackMessages.push(`Failed to process task ${t?.task}: ${r.error}`);
    }
    return { results, error: null, details: {}, feedbackMessages };
  } catch (e) {
    const { message, details } = extractError(e);
    return { results: [], error: message, details, feedbackMessages: [message] };
  }
}

module.exports = { pmcEstimatorAPI, processTask, SCHEMA_VERSION };

