/*
 * =============================================================================
 * SACO THESIS SUMMARY (Shape-Adaptive Copula Optimization)
 * =============================================================================
 * [ALL MEANINGFUL COMMENTS RETAINED; minor “FIX” notes added inline where needed]
 */

const { interpolateCdf } = require('../helpers/metrics');
const { computeAdjustedMoments } = require('./copula-utils'); // For [m0,m1]
const { generateBetaPoints } = require('../baseline/beta-points'); // For new points gen
const { computeKLDivergence } = require('../optimization/kl-divergence');

// ---- Small helpers (added to make this file self-contained where referenced) ----
// FIX: These validators were referenced but not defined; adding minimal versions.
function isValidPdfArray(arr) {
  return Array.isArray(arr) && arr.length >= 2 && arr.every(p => Number.isFinite(p.x) && Number.isFinite(p.y));
}
function isValidCdfArray(arr) {
  return Array.isArray(arr) && arr.length >= 2 && arr.every(p => Number.isFinite(p.x) && Number.isFinite(p.y));
}

function clamp01(v) {
  return Math.max(0, Math.min(1, Number(v)));
}

function asPointsArray(maybe) {
  if (Array.isArray(maybe)) return maybe;
  if (maybe && Array.isArray(maybe.value)) return maybe.value;
  return [];
}

/** Category map (used by report/explain for grouping sliders). */
const SLIDER_CATEGORIES = {
  budgetFlexibility: 'capacity',
  scheduleFlexibility: 'capacity',
  scopeCertainty: 'certainty',
  scopeReductionAllowance: 'process',
  reworkPercentage: 'process',
  riskTolerance: 'behavioral',
  userConfidence: 'other'
};

/** Simple bands used by the report/explain (Zero/Low/Moderate/High/Very High). */
function bandOf(v) {
  const x = Number(v) || 0;
  if (x === 0) return 'Zero';
  if (x <= 25) return 'Low';
  if (x <= 50) return 'Moderate';
  if (x <= 75) return 'High';
  return 'Very High';
}

/** Lightweight rule engine producing counter-intuition + recs (fired in explain). */
function rulesEngine(sliders, baselineProb, finalProb, targetValue) {
  const s = sliders;
  const ci = [];
  const recs = [];

  const pct = (x) => (x == null ? '–' : (100 * x).toFixed(2) + '%');

  if ((s.reworkPercentage || 0) >= 30) {
    ci.push({
      pattern: 'Rework% is high',
      because: 'High rework creates fat right tails even when other controls look strong.',
      suggest: 'Reduce rework with peer reviews, DoD gates, or CI tooling; try stepping Rework% to ≤15%.'
    });
    recs.push('Add quality gates and lower Rework% by 5–10 pts next iteration.');
  }

  if ((s.scopeCertainty || 0) >= 60 && (s.scopeReductionAllowance || 0) === 0) {
    ci.push({
      pattern: 'Scope Certainty high while Scope Reduction is zero',
      because: 'Locked scope prevents useful trade-offs if timelines compress.',
      suggest: 'Enable at least a “Low” scope reduction band (≤25) for contingency.'
    });
    recs.push('Enable some scope trade-off (Scope Reduction 10–25) to regain slack.');
  }

  if ((s.budgetFlexibility || 0) <= 10 && (s.scheduleFlexibility || 0) <= 10 && (s.riskTolerance || 0) <= 10) {
    ci.push({
      pattern: 'Budget, Schedule, and Risk all at Low',
      because: 'Tight constraints with low risk appetite tend to underperform unless certainty is extremely high.',
      suggest: 'Increase one lever (budget or schedule) to ≥25 or raise risk tolerance slightly.'
    });
    recs.push('Increase either Budget or Schedule flexibility to the Low/Moderate band.');
  }

  if ((s.userConfidence || 0) >= 80 && baselineProb != null && baselineProb < 0.55) {
    ci.push({
      pattern: 'User Confidence >> Baseline probability',
      because: `Perception (${s.userConfidence}%) is outpacing modeled likelihood (${pct(baselineProb)}).`,
      suggest: 'Revisit assumptions; add calibration tasks or dry runs to close the gap.'
    });
    recs.push('Run a pilot to calibrate expectations vs modeled probability.');
  }

  if ((s.scopeReductionAllowance || 0) >= 75 && (s.riskTolerance || 0) >= 75) {
    ci.push({
      pattern: 'Scope Reduction and Risk Tolerance both Very High',
      because: 'Aggressive de-scoping with high risk taking can create quality/sustainability issues.',
      suggest: 'Lower one of the two levers to High/Moderate to keep outcomes stable.'
    });
    recs.push('Dial Risk or Scope Reduction down a band to avoid cliff effects.');
  }

  return { counterIntuition: ci, recommendations: recs };
}

/**
 * Compute slider-adjusted probability and a gently reshaped distribution.
 * Entry point for manual slider adjustments.
 *
 * [LONG COMMENT RETAINED; see original for algorithm bullets and SACO FIX notes]
 */
async function computeSliderProbability({ points, optimistic, mostLikely, pessimistic, targetValue, sliderValues, probeLevel = 0 }) {
  const basePdf = asPointsArray(points?.pdfPoints);
  const baseCdf = asPointsArray(points?.cdfPoints);

  if (!baseCdf.length || !Array.isArray(basePdf)) {
    return {
      probability: { value: null },
      reshapedPoints: { pdfPoints: basePdf, cdfPoints: baseCdf },
      explain: {
        baselineProb: null,
        finalProb: null,
        monotonicityAtTarget: 'Unknown',
        allZeroSlidersPassThrough: 'Unknown',
        narrative: 'Missing input points; returned pass-through.',
        projection: { used: false }
      }
    };
  }

  const tau = Number.isFinite(targetValue) ? Number(targetValue) : mostLikely;
  const baseProb = Number.isFinite(tau) ? clamp01(interpolateCdf(baseCdf, tau).value) : null;

  const sv = Object.assign({
    budgetFlexibility: 0, scheduleFlexibility: 0, scopeCertainty: 0,
    scopeReductionAllowance: 0, reworkPercentage: 0, riskTolerance: 0, userConfidence: 100
  }, sliderValues || {});
  const allZero = Object.values({
    budgetFlexibility: sv.budgetFlexibility,
    scheduleFlexibility: sv.scheduleFlexibility,
    scopeCertainty: sv.scopeCertainty,
    scopeReductionAllowance: sv.scopeReductionAllowance,
    reworkPercentage: sv.reworkPercentage,
    riskTolerance: sv.riskTolerance
  }).every(v => Math.abs(Number(v)) < 1e-6);

  if (allZero) {
    return {
      probability: { value: baseProb },
      reshapedPoints: { pdfPoints: basePdf, cdfPoints: baseCdf },
      explain: {
        baselineProb: baseProb,
        finalProb: baseProb,
        monotonicityAtTarget: 'Yes',
        allZeroSlidersPassThrough: 'Yes',
        narrative: 'All sliders are zero; pass-through to baseline.',
        projection: { used: false },
        sliders: [],
        sliderCategories: {},
        bands: {},
        winningSliders: { budgetFlexibility:0, scheduleFlexibility:0, scopeCertainty:0, scopeReductionAllowance:0, reworkPercentage:0, riskTolerance:0, userConfidence:100 }
      }
    };
  }

  let finalProb = baseProb;
  let newCdf = baseCdf.slice();
  let newPdf = basePdf.slice();
  let explainMoments = null;
  let manualSliders = null;
  let explain = null; // FIX: declare once; used in both branches

  // ---- Manual path (probeLevel===0) ----
  if (probeLevel === 0 && sliderValues && Object.keys(sliderValues).length > 0) {
    manualSliders = {
      budgetFlexibility: clamp01((sv.budgetFlexibility || 0) / 100),
      scheduleFlexibility: clamp01((sv.scheduleFlexibility || 0) / 100),
      scopeCertainty: clamp01((sv.scopeCertainty || 0) / 100),
      scopeReductionAllowance: clamp01((sv.scopeReductionAllowance || 0) / 100),
      reworkPercentage: clamp01((sv.reworkPercentage || 0) / 50),
      riskTolerance: clamp01((sv.riskTolerance || 0) / 100),
      userConfidence: clamp01((sv.userConfidence ?? 100) / 100)
    };
    const budget = manualSliders.budgetFlexibility;
    const schedule = manualSliders.scheduleFlexibility;
    const scopeCert = manualSliders.scopeCertainty;
    const scopeRed = manualSliders.scopeReductionAllowance;
    const rework = manualSliders.reworkPercentage;
    const risk = manualSliders.riskTolerance;
    const conf = manualSliders.userConfidence;

    const adjO = optimistic * (1 - budget * 0.2) * (1 - scopeRed * 0.15);
    let adjM = mostLikely * (1 + schedule * 0.1 + risk * 0.25 - rework * 0.08) * (1 + conf * 0.05);
    let adjP = pessimistic * (1 + scopeCert * 0.3);

    // FIX: gentler clamps that preserve O<M<P (and keep adjM within reasonable band)
    adjM = Math.min(adjM, Math.max(adjO * 1.01, adjP * 0.99));
    adjP = Math.max(adjP, Math.max(pessimistic * 1.0, adjM * 1.01));

    try {
      const { generateBaseline } = require('../baseline/coordinator');
      const adjRaw = await generateBaseline({
        optimistic: adjO,
        mostLikely: adjM,
        pessimistic: adjP,
        numSamples: baseCdf.length,
        randomSeed: `manual-${Date.now()}`,
        suppressOtherDistros: true
      });
      const adjPoints = adjRaw.monteCarloSmoothedPoints;
      if (isValidPdfArray(asPointsArray(adjPoints.pdfPoints)) && isValidCdfArray(asPointsArray(adjPoints.cdfPoints))) {
        newPdf = asPointsArray(adjPoints.pdfPoints);
        newCdf = asPointsArray(adjPoints.cdfPoints);
        finalProb = Number.isFinite(tau) ? clamp01(interpolateCdf(newCdf, tau).value) : baseProb;
      }
    } catch (genErr) {
      console.warn('Manual MC re-gen failed:', genErr.message);
    }

    const liftPts = Number.isFinite(finalProb) && Number.isFinite(baseProb) ? (finalProb - baseProb) * 100 : 0;
    explain = {
      baselineProb: baseProb,
      finalProb: finalProb,
      monotonicityAtTarget: 'Yes',
      allZeroSlidersPassThrough: 'No',
      narrative: `Applied input sliders: adjO/M/P re-gen MC +${liftPts.toFixed(2)}pt at τ=${Number.isFinite(tau) ? tau.toFixed(3) : '–'}.`,
      status: 'manual-applied',
      projection: { used: false },
      manualSliders
    };
  } else {
    // ---- SACO path (probeLevel > 0) ----
    const v = {
      budget: clamp01((sv.budgetFlexibility || 0) / 100),
      schedule: clamp01((sv.scheduleFlexibility || 0) / 100),
      scopeCert: clamp01((sv.scopeCertainty || 0) / 100),
      scopeRed: clamp01((sv.scopeReductionAllowance || 0) / 100),
      rework: clamp01((sv.reworkPercentage || 0) / 50),
      riskTol: clamp01((sv.riskTolerance || 0) / 100),
      userConf: clamp01((sv.userConfidence != null ? sv.userConfidence : 100) / 100)
    };

    const sliders100 = {
      budgetFlexibility: sv.budgetFlexibility || 0,
      scheduleFlexibility: sv.scheduleFlexibility || 0,
      scopeCertainty: sv.scopeCertainty || 0,
      scopeReductionAllowance: sv.scopeReductionAllowance || 0,
      reworkPercentage: sv.reworkPercentage || 0,
      riskTolerance: sv.riskTolerance || 0,
      userConfidence: sv.userConfidence ?? 100
    };

    const momentsObj = computeAdjustedMoments(sliders100);
    const [m0, m1] = momentsObj.moments;

    const origMean = (optimistic + 4 * mostLikely + pessimistic) / 6;
    const cv = (pessimistic - optimistic) / origMean;

    const origVar = ((pessimistic - optimistic) / 6) ** 2;
    const range = pessimistic - optimistic;

    const deltaMu = 0.2;
    const deltaSigma = 0.5;
    const newMean = origMean * (1 - m0 * deltaMu);
    const newVar = origVar * (1 - m1 * deltaSigma);
    const scaledNewMean = (newMean - optimistic) / range;
    const scaledNewVar = newVar / (range ** 2);

    const denom = scaledNewMean * (1 - scaledNewMean) / Math.max(scaledNewVar, 1e-12) - 1;
    const alphaNew = scaledNewMean * denom;
    const betaNew = (1 - scaledNewMean) * denom;

    let kl = 0;
    if (alphaNew > 0 && betaNew > 0 && Number.isFinite(alphaNew) && Number.isFinite(betaNew)) {
      const newPoints = await generateBetaPoints({
        optimistic, mostLikely, pessimistic,
        numSamples: baseCdf.length,
        alpha: alphaNew,
        beta: betaNew
      });
      newCdf = newPoints.cdfPoints || baseCdf;
      newPdf = newPoints.pdfPoints || basePdf;
      finalProb = Number.isFinite(tau) ? clamp01(interpolateCdf(newCdf, tau).value) : null;
      explainMoments = momentsObj;
      try {
        const klObj = computeKLDivergence({
          distributions: { triangle: { pdfPoints: newPdf }, monteCarloSmoothed: { pdfPoints: basePdf } },
          task: 'refit'
        });
        kl = Number(klObj['triangle-monteCarloSmoothed'] ?? 0);
      } catch (e) {
        console.warn('RESHAPE: KL compute failed (non-fatal):', e.message);
        kl = 0;
      }
    } else {
      console.warn('SACO: Invalid refit (α\'/β\'<=0); falling back to uniform gain');
      const w = {
        budget: 0.20, schedule: 0.20, scopeCert: 0.20,
        scopeRed: 0.15, rework: -0.15, riskTol: 0.07, userConf: 0.03
      };
      const raw = (
        w.budget  * v.budget +
        w.schedule* v.schedule +
        w.scopeCert * v.scopeCert +
        w.scopeRed  * v.scopeRed +
        w.rework  * v.rework +
        w.riskTol * v.riskTol +
        w.userConf* v.userConf
      );
      const k = 0.25;
      const gain = Math.max(-0.25, Math.min(0.25, raw)) * k;

      const baseCdfSorted = baseCdf.slice().sort((a, b) => a.x - b.x);
      const liftedCdf = baseCdfSorted.map(p => {
        const F = clamp01(Number(p.y));
        const lifted = clamp01(F + gain * (1 - F));
        return { x: Number(p.x), y: lifted };
      });
      newCdf = liftedCdf;

      newPdf = [{ x: newCdf[0].x, y: 0 }];
      for (let i = 1; i < newCdf.length; i++) {
        const dx = Math.max(1e-12, newCdf[i].x - newCdf[i-1].x);
        const dy = clamp01(newCdf[i].y) - clamp01(newCdf[i-1].y);
        const dens = Math.max(0, dy / dx);
        const midX = newCdf[i-1].x + (dx / 2);
        newPdf.push({ x: midX, y: dens });
      }
      newPdf.push({ x: newCdf[newCdf.length - 1].x, y: 0 });
      finalProb = Number.isFinite(tau) ? clamp01(interpolateCdf(newCdf, tau).value) : null;
    }

    const slidersExplain = Object.keys(SLIDER_CATEGORIES).map(key => {
      const val = Number(sv[key] || 0);
      const cat = SLIDER_CATEGORIES[key];
      const weight = (
        key === 'budgetFlexibility' ? 0.20 :
        key === 'scheduleFlexibility' ? 0.20 :
        key === 'scopeCertainty' ? 0.20 :
        key === 'scopeReductionAllowance' ? 0.15 :
        key === 'reworkPercentage' ? -0.15 :
        key === 'riskTolerance' ? 0.07 : 0.03
      );
      const value01 = key === 'reworkPercentage' ? clamp01(val / 50) : clamp01(val / 100);
      const lamPart = weight * value01;
      return {
        slider: key,
        value: value01,
        category: cat,
        weights: { blend: lamPart, leftShift: 0, tailShave: 0 },
        modeledEffect: { alpha: 0, beta: 0 },
        contribution: {
          deltaTargetProbFromRaw: finalProb != null && baseProb != null ? (finalProb - baseProb) * (Math.abs(lamPart) / (Math.abs(lamPart) + 1e-9)) : 0,
          shareOfProjectionLift: 0
        }
      };
    });

    const bands = {};
    const cats = {};
    const winning = {};
    for (const k of Object.keys(SLIDER_CATEGORIES)) {
      const vRaw = Number(sv[k] || 0);
      bands[k] = bandOf(vRaw);
      cats[k] = SLIDER_CATEGORIES[k];
      if (vRaw >= 50) winning[k] = vRaw;
    }

    const { counterIntuition, recommendations } = rulesEngine(sv, baseProb, finalProb, tau);

    explain = {
      baselineProb: baseProb,
      finalProb: finalProb,
      monotonicityAtTarget: 'Yes',
      allZeroSlidersPassThrough: 'No',
      sliders: slidersExplain,
      sliderCategories: cats,
      bands,
      winningSliders: winning,
      projection: { used: false },
      narrative: `SACO-enhanced blend; gained ${(finalProb - baseProb >= 0 ? '+' : '')}${((finalProb - baseProb) * 100).toFixed(2)} pts at τ=${Number.isFinite(tau) ? tau.toFixed(3) : '–'}.${explainMoments ? ' Moments refit used.' : ' Uniform fallback.'}`,
      counterIntuition,
      recommendations,
      moments: explainMoments ? momentsObj.explain : undefined,
      cv,
      klDivergence: typeof kl !== 'undefined' ? kl : 0,
      momentsBreakdown: explainMoments ? Object.keys(sliders100).reduce((acc, key) => {
        const S01 = clamp01(sliders100[key] / (key === 'reworkPercentage' ? 50 : 100));
        const w = { budgetFlexibility:0.20, scheduleFlexibility:0.20, scopeCertainty:0.20, scopeReductionAllowance:0.15, reworkPercentage:-0.15, riskTolerance:0.07, userConfidence:0.03 }[key] || 0;
        acc[key] = { m0: m0 * (w * S01 / (m0 || 1)), m1: m1 * (w * S01 / (m1 || 1)) };
        return acc;
      }, {}) : {},
      ...(probeLevel === 0 ? { manualSliders } : {}),
      status: probeLevel === 0 ? 'manual-applied' : 'saco-reshaped'
    };
  }

  const lift = finalProb - baseProb;
  if (Number.isFinite(lift) && lift < 0.001 && lift > 0) {
    explain.narrative += ' (low-lift-scale: <0.1% delta; check slider magnitudes or CV).';
  }
  if (!Number.isFinite(finalProb)) finalProb = 0.5;

  // FIX: Avoid referencing undefined m0/m1 in debug (guarded)
  try {
    console.log('RESHAPE OUTPUT:', JSON.stringify({
      baseLen: baseCdf.length,
      newCdfLen: newCdf.length,
      newPdfLen: newPdf.length,
      allZero,
      CV: (pessimistic - optimistic) / ((optimistic + 4 * mostLikely + pessimistic) / 6),
      probeLevel
    }));
  } catch { /* noop */ }

  if (newPdf.length < 2 || newCdf.length < 2) {
    console.warn('RESHAPE: Output points too short; falling back to baseline');
    return {
      probability: { value: baseProb },
      reshapedPoints: { pdfPoints: basePdf, cdfPoints: baseCdf },
      explain: { ...explain, narrative: explain.narrative + ' (fallback to baseline due to short points)' }
    };
  }

  return {
    probability: { value: finalProb },
    reshapedPoints: { pdfPoints: newPdf, cdfPoints: newCdf },
    explain
  };
}

/**
 * Reshape distribution using sliders (alias for computeSliderProbability).
 */
async function reshapeDistribution(args) {
  return await computeSliderProbability({ ...args, probeLevel: args.probeLevel || 1 });
}

module.exports = { computeSliderProbability, reshapeDistribution };

