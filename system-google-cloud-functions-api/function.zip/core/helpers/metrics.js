'use strict';

/*
 * =============================================================================
 * SACO THESIS SUMMARY (Shape-Adaptive Copula Optimization) - Helpers Section
 * =============================================================================
 * (Embedded for completeness; see slider-adjustments.js for full.)
 * 
 * SACO Enhancement Here:
 * - Export computeKLDivergence for SACO KL penalty in opt/reshape.
 * - Dynamic CI: If robust std from bootstrap, adjust CI width (+/- 2*std).
 * =============================================================================
 */

/**
 * Linear interpolation on a CDF points array.
 * @param {Array<{x:number,y:number}>} cdfPoints - must be sorted by x, y in [0,1].
 * @param {number} xVal - target x.
 * @returns {{ value: number }}
 */
function interpolateCdf(cdfPoints, xVal) {
  const out = { value: NaN };
  if (!Array.isArray(cdfPoints) || cdfPoints.length === 0 || !Number.isFinite(xVal)) {
    out.value = NaN;
    return out;
  }
  const pts = cdfPoints.slice().sort((a,b)=>a.x-b.x);
  const n = pts.length;

  if (xVal <= pts[0].x) { out.value = Number(pts[0].y); return out; }
  if (xVal >= pts[n-1].x) { out.value = Number(pts[n-1].y); return out; }

  // binary search for segment
  let lo = 0, hi = n - 1;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if (pts[mid].x <= xVal) lo = mid; else hi = mid;
  }
  const a = pts[lo], b = pts[hi];
  const t = (xVal - a.x) / (b.x - a.x || 1);
  const y = a.y + t * (b.y - a.y);
  out.value = Math.max(0, Math.min(1, Number(y)));
  return out;
}

/**
 * Compute useful metrics for baseline distributions.
 * - PERT mean using (O + 4M + P) / 6 when O/M/P provided.
 * - 95% CI from the supplied Monte Carlo–smoothed CDF using quantiles [2.5%, 97.5%]
 *   (falls back to bounds if insufficient points).
 * SACO: If robustStd provided, widen CI: lower = quantile_lo - 2*std, etc.
 *
 * @param {Object} args
 * @param {number} args.optimistic
 * @param {number} args.mostLikely
 * @param {number} args.pessimistic
 * @param {Object} args.monteCarloSmoothed { pdfPoints, cdfPoints }
 * @param {Object} [args.triangle] optional
 * @param {number} [args.confidenceLevel=0.95]
 * @param {number} [args.robustStd=0] - SACO bootstrap std.
 * @returns {{
 *   pert: { mean: number },
 *   monteCarloSmoothed: { ci: { lower:number, upper:number } }
 * }}
 */
function calculateMetrics(args) {
  const {
    optimistic, mostLikely, pessimistic,
    monteCarloSmoothed,
    confidenceLevel = 0.95,
    robustStd = 0 // SACO
  } = args || {};

  const out = {
    pert: { mean: NaN },
    monteCarloSmoothed: { ci: { lower: NaN, upper: NaN } }
  };

  // PERT mean
  if ([optimistic, mostLikely, pessimistic].every(Number.isFinite)) {
    out.pert.mean = (optimistic + 4 * mostLikely + pessimistic) / 6;
  }

  // CI from CDF quantiles
  const cdf = Array.isArray(monteCarloSmoothed?.cdfPoints) ? monteCarloSmoothed.cdfPoints.slice().sort((a,b)=>a.x-b.x) : [];
  if (cdf.length >= 2) {
    const alpha = Math.max(0, Math.min(1, Number(confidenceLevel)));
    const loQ = (1 - alpha) / 2;        // e.g. 0.025 when 95% CI
    const hiQ = 1 - loQ;                // e.g. 0.975

    // Invert CDF by scanning once (efficient enough for up to a few hundred points)
    const xAtP = (p) => {
      if (p <= cdf[0].y) return cdf[0].x;
      if (p >= cdf[cdf.length-1].y) return cdf[cdf.length-1].x;
      // find adjacent pair where y crosses p
      for (let i = 1; i < cdf.length; i++) {
        const y0 = cdf[i-1].y, y1 = cdf[i].y;
        if ((p >= y0 && p <= y1) || (p >= y1 && p <= y0)) {
          const x0 = cdf[i-1].x, x1 = cdf[i].x;
          const t = (p - y0) / ((y1 - y0) || 1);
          return x0 + t * (x1 - x0);
        }
      }
      // fallback (shouldn't happen if monotone)
      return cdf[Math.floor(p * (cdf.length-1))].x;
    };

    let ciLower = xAtP(loQ);
    let ciUpper = xAtP(hiQ);
    // SACO: Widen if robustStd >0
    if (robustStd > 0) {
      ciLower = Math.max(optimistic, ciLower - 2 * robustStd);
      ciUpper = Math.min(pessimistic, ciUpper + 2 * robustStd);
    }
    out.monteCarloSmoothed.ci.lower = ciLower;
    out.monteCarloSmoothed.ci.upper = ciUpper;
  }

  return out;
}

// SACO: Export KL for use in opt/reshape
const { computeKLDivergence } = require('../optimization/kl-divergence');
module.exports = { interpolateCdf, calculateMetrics, computeKLDivergence };
