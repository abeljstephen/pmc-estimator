/* File: core/variable_map/adapter.js */
'use strict';

// ---------- helpers ----------
function asArray(x) {
  if (Array.isArray(x)) return x;
  if (x && Array.isArray(x.value)) return x.value;
  return [];
}
function asNum(x) {
  return (typeof x === 'number' && Number.isFinite(x)) ? x : undefined;
}
function coalesce(...vals) {
  for (const v of vals) {
    if (v !== undefined && v !== null) return v;
  }
  return undefined;
}

// Optional, best-effort imports for visuals (guarded)
let visuals = null;
try {
  visuals = {
    heatmap: require('../visuals/heatmap-data'),
    sankey: require('../visuals/sankey-flow'),
    annotations: require('../visuals/annotations')
  };
} catch (_) {
  // Skip if files missing
}

// Canonical slider keys & base correlations for fallbacks
let copula = null;
try {
  copula = require('../reshaping/copula-utils');
} catch (_) {
  // Skip if missing
}

// ---------- adapter ----------
function adaptResponse(core) {
  if (!core || core.error) return core || { error: 'Unknown error' };

  const baseline = core.baseline || {};
  const optimized = core.optimize || {};
  const adjusted = core.adjusted || {};
  const flags = core.flags || {};

  // Baseline arrays
  const basePdf = asArray(baseline.monteCarloSmoothed?.pdfPoints);
  const baseCdf = asArray(baseline.monteCarloSmoothed?.cdfPoints);

  // Adjusted arrays (pass-through if all-zero)
  const zeroPass = !!flags.allZeroPassThrough;
  const adjPdfRaw = asArray(adjusted.reshapedPoints?.pdfPoints);
  const adjCdfRaw = asArray(adjusted.reshapedPoints?.cdfPoints);
  const adjPdf = zeroPass ? basePdf : adjPdfRaw;
  const adjCdf = zeroPass ? baseCdf : adjCdfRaw;

  // Optimized arrays
  const optPdf = asArray(optimized.reshapedPoints?.pdfPoints);
  const optCdf = asArray(optimized.reshapedPoints?.cdfPoints);

  // Probabilities
  const tpOriginal = asNum(baseline.probabilityAtTarget?.value);
  const tpAdjustedManual = zeroPass ? tpOriginal : asNum(adjusted.probabilityAtTarget?.value);

  // Prefer explicit adaptive value if core exposed it; otherwise fall back to optimize.probabilityAtTarget
  const tpAdaptiveOptimized = coalesce(
    asNum(core.targetProbability?.value?.adaptiveOptimized),
    asNum(optimized.probabilityAtTarget?.value)
  );

  const tpAdjustedOptimized = coalesce(
    asNum(core.targetProbability?.value?.adjustedOptimized),
    asNum(optimized.probabilityAtTarget?.value)
  );

  // Sensitivity change convenience (for Phase-6 table)
  const mcSmoothedSensitivityChange = asNum(core.optimize?.metrics?.sensitivityChange);

  // Extract sliders for derivation (avoid undefined reference)
  const sliders = (optimized && typeof optimized.sliders === 'object') ? optimized.sliders : null;

  // Build output: keep original envelope first (advanced consumers),
  // then override with normalized/canonical shapes expected by UI.
  const out = {
    ...core,
    flags: { ...flags },

    // Canonical baseline
    baseline: {
      ...baseline,
      monteCarloSmoothed: { pdfPoints: basePdf, cdfPoints: baseCdf }
    },

    // Canonical adjusted with enforced pass-through aliasing
    adjusted: {
      ...adjusted,
      reshapedPoints: { pdfPoints: adjPdf, cdfPoints: adjCdf },
      probabilityAtTarget: { value: tpAdjustedManual }
    },

    // Canonical optimized
    optimize: {
      ...optimized,
      reshapedPoints: { pdfPoints: optPdf, cdfPoints: optCdf },
      sliders: sliders,  // normalized (UI default)
      scaledSliders: (optimized && typeof optimized.scaledSliders === 'object') 
        ? optimized.scaledSliders 
        : (sliders && typeof sliders === 'object' && Object.keys(sliders).length > 0
          ? Object.fromEntries(Object.entries(sliders).map(([k, v]) => [k, Number(v) * 100]))
          : null)  // %; derive from sliders if missing
    },

    // Target probability bundle (legacy consumers)
    targetProbability: {
      value: {
        original: tpOriginal,
        adjusted: (tpAdjustedManual ?? tpOriginal),
        // classic fixed optimization convenience
        adjustedOptimized: (tpAdjustedOptimized ?? tpAdjustedManual ?? tpOriginal),
        // expose adaptive (if present) without breaking consumers
        adaptiveOptimized: tpAdaptiveOptimized
      }
    },

    // Legacy aliases expected by Plot.html / Code.gs
    trianglePdf: { value: asArray(core.trianglePdf?.value) },
    triangleCdf: { value: asArray(core.triangleCdf?.value) },
    betaPertPdf: { value: asArray(core.betaPertPdf?.value) },
    betaPertCdf: { value: asArray(core.betaPertCdf?.value) },

    targetProbabilityOriginalPdf: { value: basePdf },
    targetProbabilityOriginalCdf: { value: baseCdf },
    targetProbabilityAdjustedPdf: { value: adjPdf },
    targetProbabilityAdjustedCdf: { value: adjCdf },

    optimizedReshapedPoints: {
      pdfPoints: optPdf,
      cdfPoints: optCdf
    },

       // Reports passthrough + back-compat mirrors
    // (core.decisionReports is an array; decisionCsv/summaries live top-level)
    decisionReports: Array.isArray(core.decisionReports) ? core.decisionReports : (core.decisionReports || null),
    decisionCsv: core.decisionCsv ?? null,
    summaries: core.summaries ?? null,

    // Phase-6 convenience so table doesn't show "N/A"
    mcSmoothedSensitivityChange
  };

  // -----------------------------
  // Additive: Visuals (heatmap, sankey, annotations). All guarded & optional.
  // -----------------------------
  try {
    // Labels & base correlation fallback
    const labels =
      (copula && Array.isArray(copula.SLIDER_KEYS) && copula.SLIDER_KEYS.slice()) ||
      ['budgetFlexibility','scheduleFlexibility','scopeCertainty','scopeReductionAllowance','reworkPercentage','riskTolerance','userConfidence'];

    const baseCorrelation =
      (copula && Array.isArray(copula.BASE_R) && copula.BASE_R) || null;

    // Sensitivity vector if present (flatten common shapes)
    const sensObj =
      core?.sensitivity?.monteCarloSmoothed?.change ||
      core?.optimize?.metrics?.sensitivity?.monteCarloSmoothed?.change ||
      null;

    // Build Heatmap data (correlation + interactions)
    if (visuals && visuals.heatmap && labels) {
      const heat = visuals.heatmap.buildHeatmapData({
        labels,
        baseCorrelation,
        sensitivityChange: sensObj
      });
      out.sensitivity = Object.assign({}, out.sensitivity || {}, {
        labels: heat.labels,
        correlationMatrix: heat.correlationMatrix,
        interactionsMatrix: heat.interactionsMatrix
      });
    }

    // Build Sankey flow (Baseline → Adjusted → Optimized)
    if (visuals && visuals.sankey) {
      const pBase =  asNum(out?.targetProbability?.value?.original);
      const pAdj  =  asNum(out?.targetProbability?.value?.adjusted);
      const pOpt  =  asNum(out?.targetProbability?.value?.adjustedOptimized) ?? asNum(tpAdaptiveOptimized);
      const flow = visuals.sankey.buildSankeyFlow({
        pBase, pAdjusted: pAdj, pOptimized: pOpt
      });
      out.progressionFlow = flow;
    }

    // Build Annotations (values at τ for all series we can see)
    if (visuals && visuals.annotations) {
      const tau =
        asNum(core?.tau) ??
        asNum(core?.targetValue) ??
        asNum(core?.mostLikely);

      const series = {
        triangle: { pdf: asArray(out?.trianglePdf?.value), cdf: asArray(out?.triangleCdf?.value) },
        betaPert: { pdf: asArray(out?.betaPertPdf?.value), cdf: asArray(out?.betaPertCdf?.value) },
        baseline: { pdf: basePdf, cdf: baseCdf },
        adjusted: { pdf: adjPdf, cdf: adjCdf },
        optimized: { pdf: optPdf, cdf: optCdf }
      };
      const ann = visuals.annotations.buildAnnotations({ tau, series });
      if (ann) out.annotations = ann;
    }
  } catch (e) {
    // Never fail the adapter if visuals building throws
    // eslint-disable-next-line no-console
    console.warn('adapter visuals build skipped:', e && e.message ? e.message : e);
  }

  return out;
}

module.exports = { adaptResponse };
