// File: index.js
//
// WHAT: Entry point for the Google Cloud Function, serving as the interface for pmcEstimatorAPI.
//       Normalizes the response with core/variable_map/adapter.js before returning.
//
// DEPENDENCIES:
//   - core/main/main.js (pmcEstimatorAPI, SCHEMA_VERSION) -> returns per-task envelopes with { schemaVersion, buildInfo, ... }
//   - core/variable_map/adapter.js (adaptResponse)
//   - @google-cloud/functions-framework
//
// OUTPUT SHAPE (to clients):
//   {
//     schemaVersion: <string>,              // <-- guaranteed (from SCHEMA_VERSION)
//     buildInfo: <object|null>,             // <-- taken from first task's buildInfo if not on the core envelope
//     feedbackMessages: <string[]>,
//     results: [ <ADAPTED_TASK_RESULT>, ... ]
//   }
//
// NOTES:
//   Plot.html & Code.gs rely on adapted keys like:
//     trianglePdf.value, triangleCdf.value,
//     betaPertPdf.value, betaPertCdf.value,
//     targetProbabilityOriginalPdf.value, targetProbabilityOriginalCdf.value,
//     targetProbabilityAdjustedPdf.value, targetProbabilityAdjustedCdf.value,
//     targetProbability.value.{original,adjusted,adjustedOptimized},
//     optimizedReshapedPoints.{pdfPoints,cdfPoints},
//     decisionReports, decisionCsv
//

'use strict';

// Global: Load only Functions Framework (minimal, to start server)
const functions = require('@google-cloud/functions-framework');

console.log('index.js: module init (framework loaded)');

// Lazy-load core in handler to avoid global scope crashes
let coreHandler = null;
let SCHEMA_VERSION = null;
let adaptResponse = null;
function lazyLoadCore() {
  if (coreHandler) return;  // Already loaded
  try {
    console.log('Lazy-loading core modules...');
    const core = require('./core/main/main');
    coreHandler = core.pmcEstimatorAPI;
    SCHEMA_VERSION = core.SCHEMA_VERSION;
    adaptResponse = require('./core/variable_map/adapter').adaptResponse;
    console.log('Core loaded successfully');
  } catch (error) {
    console.error('Failed to lazy-load core:', error.message || error);
    throw error;  // Re-throw for handler error handling
  }
}

/** Ensure we have an array of task objects from the request body. */
function extractTasksFromBody(body) {
  if (Array.isArray(body)) return body;
  if (body && Array.isArray(body.tasks)) return body.tasks;
  return null;
}

/** Ensure we have an array of per-task results from the core envelope. */
function resultsArrayFromEnvelope(envelope) {
  if (envelope && Array.isArray(envelope.results)) return envelope.results;
  // If core returned a single task result (strictly not expected, but keep a minimal guard):
  if (envelope && envelope.results && !Array.isArray(envelope.results)) return [envelope.results];
  return [];
}

/** Derive a buildInfo to expose at the top level (prefer envelope, else first task). */
function pickBuildInfo(coreEnvelope, rawResults) {
  if (coreEnvelope && coreEnvelope.buildInfo) return coreEnvelope.buildInfo;
  if (Array.isArray(rawResults) && rawResults.length > 0) {
    return rawResults[0]?.buildInfo ?? null;
  }
  return null;
}

/** Cloud Function entrypoint — direct export for GCF (gen1 fallback) */
async function pmcEstimatorAPI(req, res) {
  // Lazy load on first call
  lazyLoadCore();

  try {
    // Basic CORS (no auth changes)
    res.set('Access-Control-Allow-Origin', '*');
    res.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.set('Access-Control-Allow-Methods', 'POST, OPTIONS');
    if (req.method === 'OPTIONS') {
      return res.status(204).send('');
    }

    if (req.method !== 'POST') {
      res.status(405).json({ error: 'Method not allowed; use POST' });
      return;
    }
    if (!req.is('application/json')) {
      res.status(400).json({ error: 'Content-Type must be application/json' });
      return;
    }

    const tasks = extractTasksFromBody(req.body);
    if (!tasks || tasks.length === 0) {
      res.status(400).json({ error: 'Request body must be a non-empty array of tasks or { tasks: [...] }' });
      return;
    }

    // Call core once — no retries/fallbacks.
    const coreEnvelope = await coreHandler(tasks);  // FIXED: Call the real pmcEstimatorAPI with tasks

    // Pull raw task results *before* adapting so we can source buildInfo reliably.
    const rawResults = resultsArrayFromEnvelope(coreEnvelope);

    // Adapt each per-task result to UI schema.
    const adaptedResults = rawResults.map((taskResult, idx) => {
      try {
        return adaptResponse(taskResult);
      } catch (e) {
        console.error(`adapter failure @ results[${idx}]`, e?.stack || e);
        return { error: `Adapter failed for results[${idx}]: ${e?.message || String(e)}` };
      }
    });

    // Prepare final payload:
    // - schemaVersion: force from SCHEMA_VERSION so deploy preflight never sees null
    // - buildInfo: prefer envelope.buildInfo, else first task's buildInfo
    const payload = {
      schemaVersion: SCHEMA_VERSION,
      buildInfo: pickBuildInfo(coreEnvelope, rawResults),
      feedbackMessages: Array.isArray(coreEnvelope?.feedbackMessages) ? coreEnvelope.feedbackMessages : [],
      results: adaptedResults
    };

    res.set('Content-Type', 'application/json; charset=utf-8');
    res.status(200).send(JSON.stringify(payload));
  } catch (error) {
    console.error('pmcEstimatorAPI: unhandled error', {
      message: error?.message,
      stack: error?.stack
    });
    const status = (error?.message && /must be|not allowed|Content-Type/i.test(error.message)) ? 400 : 500;
    res
      .status(status)
      .json({
        schemaVersion: SCHEMA_VERSION || 'unknown', // Fallback if not loaded
        error: `Failed to process request: ${error?.message || String(error)}`,
        details: error?.details || {},
        feedbackMessages: [error?.message || 'Unhandled error'],
        results: []
      });
  }
}

// Register with framework (global, starts server on PORT=8080)
functions.http('pmcEstimatorAPI', pmcEstimatorAPI);

// Export for gen1 compatibility
exports.pmcEstimatorAPI = pmcEstimatorAPI;

// For local testing with functions-framework (optional)
if (require.main === module) {
  // Already registered above; just start if main
  console.log('Running locally on port 8080');
}

console.log('index.js: ready (server registered)');
