/**
 * optimizer.js — SACO Geometry Optimizer
 *
 * This file orchestrates the SACO Geometry components to optimize slider settings 
 * that maximize the probability of meeting a target given estimates (O, M, P).
 *
 * SACO Geometry consists of six core components:
 * 1. Monte-Carlo-Smoothed Beta Baseline: Generates the initial probabilistic forecast.
 * 2. 7-Dimensional Unit Hypercube: The bounded search space [0,1]^7 for sliders.
 * 3. Gaussian Copula: Encodes real-world project correlations among sliders.
 * 4. Moments Mapper: Maps a hypercube point to moments (m0: mean-shift, m1: variance-shrink).
 * 5. Beta Re-fitting Engine: Adjusts the Beta distribution based on moments.
 * 6. KL-Divergence Anchor: Penalizes distortions from the baseline.
 *
 * Together, these define a curved, bounded, correlation-aware manifold inside the 
 * unit hypercube, on which optimization discovers the most credible, highest-probability 
 * version of the original estimate.
 *
 * Workflow:
 * - Manual mode: Delegates to slider-adjustments.js for direct reshaping.
 * - Optimization modes (fixed/adaptive): Uses Latin Hypercube Sampling (LHS) 
 *   for scalable exploration of the hypercube, chained for refinement.
 */

'use strict';

/* ------------------------- Imports ------------------------- */

const path = require('path');
const CORE_DIR = path.resolve(__dirname, '..');
const seedrandom = require('seedrandom');

// SACO Geometry Components — Explicit references to the six pillars
const SACO_GEOMETRY = {
  // 1. Monte-Carlo-Smoothed Beta Baseline
  baseline: require(path.join(CORE_DIR, 'baseline', 'monte-carlo-smoothed')).generateMonteCarloSmoothedPoints,

  // 2. Hypercube sampling (Latin Hypercube — scalable exploration)
  lhsSample: function(n, dims, seed = Date.now()) {
    seedrandom(String(seed), { global: true });
    const samples = Array.from({ length: n }, () => Array(dims).fill(0));
    for (let j = 0; j < dims; j++) {
      const perm = Array.from({ length: n }, (_, i) => i);
      for (let i = perm.length - 1; i > 0; i--) {
        const r = Math.floor(Math.random() * (i + 1));
        [perm[i], perm[r]] = [perm[r], perm[i]];
      }
      for (let i = 0; i < n; i++) {
        const low = perm[i] / n;
        const high = (perm[i] + 1) / n;
        samples[i][j] = low + Math.random() * (high - low);
      }
    }
    return samples;
  },

  // 3+4. Copula + Moments Mapper
  computeMoments: require(path.join(CORE_DIR, 'reshaping', 'copula-utils')).computeAdjustedMoments,

  // 5. Beta Re-fitting Engine (defined below)
  betaRefit: null, // Assigned after definition

  // 6. KL-Divergence Anchor
  klDivergence: require(path.join(CORE_DIR, 'optimization', 'kl-divergence')).computeKLDivergence
};

const { generateBetaPoints } = require(path.join(CORE_DIR, 'baseline', 'beta-points'));
const { interpolateCdf } = require(path.join(CORE_DIR, 'helpers', 'metrics'));
const { SLIDER_KEYS, BASE_R } = require(path.join(CORE_DIR, 'reshaping', 'copula-utils'));
const { computeSliderProbability } = require(path.join(CORE_DIR, 'reshaping', 'slider-adjustments'));

/* ------------------------- Constants ------------------------- */

// Canonical sliders for backward compatibility
const CANON_SLIDERS = SLIDER_KEYS.slice();

// Per-polarity bounds for hypercube dimensions
const W_MEAN = [-0.2, 0.1, 0.3, -0.15, -0.08, 0.25, 0.05];
const PER_SLIDER_BOUNDS = W_MEAN.map(w => ({
  lo: (w < 0 ? 0.15 : 0),
  hi: (w > 0 ? 0.7 : 1.0)
}));

/* --------------------------- Small utilities --------------------------- */

function clamp01(v) { return Math.max(0, Math.min(1, v)); }
function safeNumber(x, dflt = 0) { return Number.isFinite(x) ? Number(x) : dflt; }
function pct(n) { return clamp01(safeNumber(n)); }
function lerp(a, b, t) { return (1 - t) * a + t * b; }

function mean(a) { if (!a.length) return 0; return a.reduce((s, v) => s + v, 0) / a.length; }

function stdDev(pdfOrSamples) {
  if (!Array.isArray(pdfOrSamples) || pdfOrSamples.length < 2) return 0;
  const a0 = pdfOrSamples[0];
  if (typeof a0 === 'number') {
    const mu = pdfOrSamples.reduce((s, v) => s + v, 0) / pdfOrSamples.length;
    const v = pdfOrSamples.reduce((s, x) => s + (x - mu) ** 2, 0) / pdfOrSamples.length;
    return Math.sqrt(Math.max(0, v));
  }
  const sumY = pdfOrSamples.reduce((s, p) => s + p.y, 0);
  if (sumY <= 0) return 0;
  const mu = pdfOrSamples.reduce((s, p) => s + p.x * p.y, 0) / sumY;
  const v = pdfOrSamples.reduce((s, p) => s + p.y * (p.x - mu) ** 2, 0) / sumY;
  return Math.sqrt(Math.max(0, v));
}

function erf(x) {
  const t = 1 / (1 + 0.5 * Math.abs(x));
  return x >= 0
    ? 1 - t * Math.exp(
        -x * x - 1.26551223 +
        1.00002368 * t +
        0.37409196 * t * t +
        0.09678418 * t * t * t -
        0.18628806 * t * t * t * t +
        0.27886807 * t * t * t * t * t -
        1.13520398 * t * t * t * t * t * t +
        1.48851587 * t * t * t * t * t * t * t -
        0.82215223 * t * t * t * t * t * t * t * t +
        0.17087277 * t * t * t * t * t * t * t * t * t
      )
    : -erf(-x);
}

function trapezoidArea(points) {
  let A = 0;
  for (let i = 1; i < points.length; i++) {
    A += 0.5 * (points[i - 1].y + points[i].y) * (points[i].x - points[i - 1].x);
  }
  return A;
}

function renormalizePdf(points) {
  const A = trapezoidArea(points);
  if (!Number.isFinite(A) || A <= 0) return false;
  for (const p of points) p.y /= A;
  return true;
}

/* --------------------------- Universal Rules Wrapper ------------------- */
/**
 * applyReshapeRules
 *
 * Post-refine rules applied to optimized sliders (fixed/adaptive):
 *   - Clamp to per-slider bounds (raw 0–1; rework cap 0.5).
 *   - Feasibility check via monotoneFeas with probabilistic slack.
 *   - Adaptive-only: anchor to seedBest with drift <5% and probe-aware dampening.
 *
 * Manual sliders do NOT pass through this wrapper here; they are handled in
 * reshaping/slider-adjustments.js (which may apply its own gentle constraints
 * inside computeSliderProbability).
 */
function applyReshapeRules(x, mode, probeLevel = 1, seedBest = null, state = {}) {
  // Universal clamp to raw 0-1 (all modes; rework hi=0.5 for var-shrink cap—math: prevents σ'^2<0 denom)
  x = x.map((v, i) => {
    const bounds = PER_SLIDER_BOUNDS[i];
    const hi = (i === 4) ? Math.min(0.5, bounds.hi) : bounds.hi;  // Cap m1 amp (CV-risk hedge)
    return Math.max(bounds.lo, Math.min(hi, v));
  });
  console.log('RULES CLAMP: x post-clamp', x.map(v => v.toFixed(3)));

  // Feas check + pert (all modes; probabilistic slack—math: erf(|skew|/√2)>0.01 for beta denom>0)
  const { o, m, p, tau, p0, cv, skew, sigma } = state;
  if (!monotoneFeas(x, o, m, p, tau, p0, cv, skew, sigma)) {
    console.log('RULES FEAS FAIL: Perturbing budget...');
    x[0] += 0.01 * Math.sign(W_MEAN[0]);  // Polarity nudge (mean-shift bias for low-p0)
    x = x.map((v, i) => {  // Re-clamp after pert (preserves bounds)
      const bounds = PER_SLIDER_BOUNDS[i];
      const hi = (i === 4) ? Math.min(0.5, bounds.hi) : bounds.hi;
      return Math.max(bounds.lo, Math.min(hi, v));
    });
  }

  if (mode === 'adaptive' && seedBest && probeLevel > 1) {
    // Anchor (drift <5%; PMBOK Ch.11: Gradual evolution—lerp=0.8 pullback if >5% ensures chaining invariant)
    let maxDiv = 0;
    for (let i = 0; i < 7; i++) {
      const div = Math.abs(x[i] - seedBest[i]) / Math.max(seedBest[i] || 0.01, 1e-6);  // Rel div (avoids scale bias)
      maxDiv = Math.max(maxDiv, div);
      if (div > 0.05) x[i] = lerp(x[i], seedBest[i], 0.8);  // 80% pullback (nuanced, not full reset)
    }
    console.log('RULES ANCHOR: maxDiv=' + maxDiv.toFixed(3));

    // PATCH v1.9.24: Skip dampen for seeded chaining (trust Fixed scout; avoid over-shrink—math: preserves m0~0.2 mean-lift for p'>>p0)
    // Standalone adaptive (no seedBest) uses probe-based dampen (milder cap).
    const dampenFactor = seedBest ? 1.0 : Math.max(1 / probeLevel, 0.5);  // Skip if seeded; else probe-scale (≥0.5 hedge)
    let xDamp = x.map(v => clamp01(v * dampenFactor));  // 1.0 = identity for chaining

    // Re-clamp post-dampen (always; prevents <lo dips)
    xDamp = xDamp.map((v, i) => {
      const bounds = PER_SLIDER_BOUNDS[i];
      const hi = (i === 4) ? Math.min(0.5, bounds.hi) : bounds.hi;
      return Math.max(bounds.lo, Math.min(hi, v));
    });
    x = xDamp;

    console.log(
      'RULES DAMPEN: factor=' + dampenFactor.toFixed(3) +
      ' (seeded=' + !!seedBest + '), budget post=' + (x[0] * 100).toFixed(1) + '%'
    );
  }

  return x;
}

/* ---------------------------- Error helpers ---------------------------- */

function stepLog(step, msg, extra) {
  try {
    const tail = extra ? ` ${JSON.stringify(extra).slice(0, 300)}` : '';
    console.log(`// ${step} ${msg}${tail}`);
  } catch (_) { /* noop */ }
}

function logStepThrow(stepName, err) {
  console.error(`Optimizer Error at step ${stepName}:`, err?.message || err);
  return { step: stepName, message: err?.message || String(err) };
}

/* --------------------------- KL alignment util -------------------------- */

function alignPoints(p, q) {
  if (!Array.isArray(p) || !Array.isArray(q) || p.length < 2 || q.length < 2) return [p || [], q || []];
  const xMin = Math.min(p[0].x, q[0].x);
  const xMax = Math.max(p[p.length - 1].x, q[q.length - 1].x);
  const dp = p[1].x - p[0].x;
  const dq = q[1].x - q[0].x;
  let step = Math.min(
    ...(
      [dp, dq].filter(v => Number.isFinite(v) && v > 0).length
        ? [dp, dq].filter(v => Number.isFinite(v) && v > 0)
        : [ (xMax - xMin) / Math.max(200, Math.max(p.length, q.length)) ]
    )
  );
  if (!Number.isFinite(step) || step <= 0) step = (xMax - xMin) / 400;
  const n = Math.max(2, Math.ceil((xMax - xMin) / step) + 1);
  const xs = Array.from({ length: n }, (_, i) => xMin + i * step);

  const lerpSeg = (A, x) => {
    if (x <= A[0].x) return A[0].y;
    if (x >= A[A.length - 1].x) return A[A.length - 1].y;
    for (let i = 0; i < A.length - 1; i++) {
      if (A[i].x <= x && x <= A[i + 1].x) {
        const d = A[i + 1].x - A[i].x || 1;
        const t = (x - A[i].x) / d;
        return A[i].y + t * (A[i + 1].y - A[i].y);
      }
    }
    return 0;
  };

  const P = xs.map(x => ({ x, y: lerpSeg(p, x) }));
  const Q = xs.map(x => ({ x, y: lerpSeg(q, x) }));
  renormalizePdf(P);
  renormalizePdf(Q);
  return [P, Q];
}

/* ------------------------ Moments → Beta refit ------------------------ */
// (Component 5: Beta Re-fitting Engine — already defined; assigned to SACO_GEOMETRY.betaRefit)

/* --------------------------- Monotone Feasibility ---------------------- */

function monotoneFeas(x01, o, m, p, tau, p0, cv, skew, sigma) {
  let adjO = o * (1 - x01[0] * 0.2) * (1 - x01[3] * 0.15);
  let adjM = m * (1 + x01[1] * 0.1 - x01[4] * 0.08) * (1 + x01[6] * 0.05);
  let adjP = p * (1 + x01[2] * 0.3) * (1 + x01[5] * 0.25);
  const erfTerm = erf(Math.abs(skew) / Math.sqrt(2));
  const slack = 1 + 0.05 * cv * (1 - p0 / 0.5) * erfTerm;
  let feasible = (adjO < adjM * slack && adjM < adjP * slack);
  let attempts = 0;
  while (!feasible && attempts < 3) {
    x01[0] += 0.01 * Math.sign(W_MEAN[0]);
    x01 = x01.map(clamp01);
    adjO = o * (1 - x01[0] * 0.2) * (1 - x01[3] * 0.15);
    feasible = (adjO < adjM * slack && adjM < adjP * slack);
    attempts++;
  }
  return feasible;
}

/* --------------------------- SACO Objective --------------------------- */
// Uses Components 3,4 (moments), 5 (refit), 6 (KL)
async function sacoObjective(sliders01, o, m, p, tau, basePdf, baseCdf, bBias, adaptive, range, p0, probeLevel, seedBest) {
  try {
    const sliders100 = {};
    for (let i = 0; i < CANON_SLIDERS.length; i++) {
      sliders100[CANON_SLIDERS[i]] = sliders01[i] * 100;
    }

    const cv = (p - o) / ((o + 4 * m + p) / 6);
    const momentsObj = SACO_GEOMETRY.computeMoments(sliders100, 1, cv);
    let [m0, m1] = momentsObj.moments || [0, 0];

    const mu = (o + 4 * m + p) / 6;
    let m1Before = m1;
    let bb = safeNumber(bBias, 0.05);
    let tameFactor = 1;

    if (adaptive) {
      tameFactor = 1 + 0.01 / (probeLevel + 1);
      if (tau > mu && p0 > 0.5) {
        m1 *= tameFactor;
        bb = 0;
      } else {
        m1 *= tameFactor;
        bb = 0.05 + 0.03 * mean(W_MEAN.map((w, i) => sliders01[i] * Math.sign(w)));
      }
    }
    console.log('TAMING DEBUG:', { m1Before, m1After: m1, bBias: bb, p0, tauVsMu: tau > mu, probeLevel, tameFactor: tameFactor || 1 });

    const sigma = stdDev(basePdf);
    const skew = sigma > 0 ? (mu - tau) / sigma : 0;
    const cvLocal = sigma / mu;

    const feasible = monotoneFeas(sliders01, o, m, p, tau, p0, cvLocal, skew, sigma);

    let leashPenalty = 0;
    if (adaptive && Array.isArray(seedBest) && seedBest.length === 7) {
      const lambda = 0.05 * (1 - p0);
      const sigmaLeash = 0.1;
      for (let i = 0; i < 7; i++) {
        const dev = Math.abs(sliders01[i] - seedBest[i]) / Math.max(seedBest[i] || 0.01, 1e-6);
        leashPenalty += lambda * Math.exp(dev / sigmaLeash);
      }
      leashPenalty = Math.max(0, leashPenalty - 1);
    }

    const refit = SACO_GEOMETRY.betaRefit(o, m, p, [m0, m1]);
    if (!refit) return { score: 0, pNew: 0.5, x: sliders01, feasible };

    const numSamples = basePdf.length || 200;
    const newPts = await generateBetaPoints({ optimistic: o, mostLikely: m, pessimistic: p, numSamples, alpha: refit.alpha, beta: refit.beta });

    const pNew = pct(interpolateCdf(newPts.cdfPoints, tau).value);

    const basePdfN = basePdf.map(pt => ({ x: (pt.x - o) / range, y: pt.y * range }));
    const newPdfN = newPts.pdfPoints.map(pt => ({ x: (pt.x - o) / range, y: pt.y * range }));
    const klObj = SACO_GEOMETRY.klDivergence({ distributions: { triangle: { pdfPoints: newPdfN }, monteCarloSmoothed: { pdfPoints: basePdfN } }, task: 'opt' });
    const kl = safeNumber(klObj['triangle-monteCarloSmoothed'] ?? klObj.value ?? klObj.kl, 0);

    const score = feasible ? (Math.pow(pNew, 1 + bb) * Math.exp(-kl)) * Math.exp(-leashPenalty) : -1e12;
    return { score, pNew, kl, refit, x: sliders01, leashPenalty, feasible };
  } catch (e) {
    console.log('SACO Obj Error:', e.message);
    return { score: 0, pNew: 0.5, x: sliders01, feasible: false };
  }
}

/* -------------------------- COBYLA-lite refine ------------------------- */
// Local trust-region search in the hypercube (Component 2)
async function cobyla(objective, initial, o, m, p, tau, basePdf, baseCdf, opts = {}, adaptive, probeLevel, seedBest, p0) {
  const cfg = {
    maxIter: opts.maxIter ?? 80,
    rhoInit: opts.rhoInit ?? 0.5,
    rhoFinal: opts.rhoFinal ?? 1e-5
  };
  let x = initial.slice();
  let rho = cfg.rhoInit;
  let iter = 0;

  const mu = (o + 4 * m + p) / 6;
  const sigma = stdDev(basePdf);
  const skew = sigma > 0 ? (mu - tau) / sigma : 0;
  const cv = sigma / mu;

  function box(s) {
    const out = s.slice();
    for (let i = 0; i < out.length; i++) {
      const bounds = PER_SLIDER_BOUNDS[i];
      const hi = (i === 4) ? Math.min(0.5, bounds.hi) : bounds.hi;
      out[i] = Math.max(bounds.lo, Math.min(hi, out[i]));
    }
    return out;
  }

  let best = { x: x.slice(), f: -Infinity };

  while (iter++ < cfg.maxIter && rho > cfg.rhoFinal) {
    const cand = [];
    for (let k = 0; k < x.length; k++) {
      const wAbs = Math.abs(W_MEAN[k] || 0.1);
      const polAmp = 1 + 0.1 * Math.sign(W_MEAN[k]) * skew;
      const delta = (rho / (wAbs + 0.05)) * polAmp;

      const xp = x.slice();
      xp[k] += delta;
      cand.push(box(xp));
      const xm = x.slice();
      xm[k] -= delta;
      cand.push(box(xm));
    }
    cand.push(box(x.map(v => v + rho)));
    cand.push(box(x.map(v => v - rho)));

    for (const c of cand) {
      if (!monotoneFeas(c, o, m, p, tau, p0, cv, skew, sigma)) continue;
      const val = await objective(c, o, m, p, tau, basePdf, baseCdf, 0, adaptive, null, null, probeLevel, seedBest);
      const f = safeNumber(val?.score, -1e9);
      if (f > best.f) best = { x: c.slice(), f };
    }

    if (best.f <= -1e8) {
      rho *= 0.5;
    } else {
      x = best.x.slice();
      const shrink = (adaptive && probeLevel > 2) ? 0.7 : 0.6;
      rho *= shrink;
      for (let k = 0; k < x.length; k++) {
        if (W_MEAN[k] < 0) {
          const div = Math.abs(x[k] - (seedBest ? seedBest[k] : 0.5));
          if (div > 0.03) x[k] = lerp(x[k], PER_SLIDER_BOUNDS[k].lo, 0.5);
        }
      }
    }

    if (adaptive && iter % 10 === 0 && Array.isArray(seedBest)) {
      let maxDiv = 0;
      for (let i = 0; i < 7; i++) {
        const div = Math.abs(x[i] - seedBest[i]) / Math.max(seedBest[i] || 0.01, 1e-6);
        maxDiv = Math.max(maxDiv, div);
      }
      if (maxDiv > 0.1) {
        for (let i = 0; i < 7; i++) x[i] = lerp(x[i], seedBest[i], 0.8);
        x = box(x);
        stepLog('COBYLA CHECKPOINT', `Projected at iter ${iter} (maxDiv=${maxDiv.toFixed(3)})`);
      }
    }

    if (adaptive && iter % 5 === 0) {
      const polMean = mean(W_MEAN.map((w, i) => x[i] * Math.sign(w)));
      for (let k = 0; k < x.length; k++) {
        x[k] = lerp(x[k], polMean * Math.sign(W_MEAN[k]), 0.2);
      }
      x = box(x);
    }
  }

  return { x: best.x, f: best.f, iter: iter, success: Number.isFinite(best.f) && best.f > -1e8 };
}

/* ---------------------------- Step helpers ----------------------------- */

function safeProbeLevel(v) {
  const n = Math.floor(Number(v));
  return Number.isFinite(n) ? Math.max(1, Math.min(7, n)) : 5;
}

function pickOptimizedSliders(optRes) {
  const cands = [
    optRes?.sliders,
    optRes?.optimizedResult?.sliders,
    optRes?.best?.sliders,
    optRes?.solution?.sliders
  ];
  for (const c of cands) {
    if (c && typeof c === 'object') {
      const out = {};
      for (const k of CANON_SLIDERS) {
        if (Number.isFinite(c[k])) out[k] = Number(c[k]);
      }
      if (Object.keys(out).length) return out;
    }
  }
  return {};
}

function toReportEntry(modeLabel, targetValue, baselineProbability, finalProbability, explain, certificateRaw) {
  const safe = (x) => (Number.isFinite(x) ? Number(x) : null);
  const lift = safe(finalProbability - baselineProbability);
  return {
    mode: modeLabel,
    narrative: explain?.narrative || '',
    target: safe(targetValue),
    baselineProbability: safe(baselineProbability),
    finalProbability: safe(finalProbability),
    liftPoints: lift,
    lambda: explain?.projection && Number.isFinite(explain.projection.lambda) ? explain.projection.lambda : null,
    certificate: typeof certificateRaw === 'string' ? certificateRaw : (certificateRaw ? JSON.stringify(certificateRaw) : '—'),
    diagnostics: {
      monotonicityAtTarget: explain?.monotonicityAtTarget || 'N/A',
      allZeroSlidersPassThrough: explain?.allZeroSlidersPassThrough || 'N/A',
      winnerHasSliders: !!(explain?.winningSliders && Object.keys(explain.winningSliders).length)
    },
    counterIntuition: Array.isArray(explain?.counterIntuition) ? explain.counterIntuition : [],
    recommendations: Array.isArray(explain?.recommendations) ? explain.recommendations : [],
    bands: explain?.bands || {},
    winningSliders: explain?.winningSliders || {},
    sliderCategories: explain?.sliderCategories || {}
  };
}

/* ------------------------------ Steps 1–7 ------------------------------ */

/** Step 1 — Baseline (Component 1) */
async function step1_baseline(state) {
  const { optimistic: o, mostLikely: m, pessimistic: p, targetValue: tau, randomSeed } = state;
  const baselineRaw = await SACO_GEOMETRY.baseline({
    optimistic: o, mostLikely: m, pessimistic: p,
    numSamples: state.numSamples || 200,
    samples: null  // Use Beta sampling
  });

  const base = baselineRaw.pdfPoints && baselineRaw.cdfPoints ? baselineRaw : null;
  if (!base) throw new Error('Baseline generation returned invalid points');

  const p0 = pct(interpolateCdf(base.cdfPoints, tau).value);
  const mu = (o + 4 * m + p) / 6;
  const cv = (p - o) / Math.max(1e-9, mu);
  const sigma = stdDev(base.pdfPoints);
  const skew = sigma > 0 ? (mu - tau) / sigma : 0;
  const range = Math.max(1e-9, p - o);

  const next = { ...state, baseline: base, p0, cv, sigma, skew, range, currentProb: p0, o, m, p, tau };
  stepLog('Step 1 Complete', `p0=${p0.toFixed(3)}`, { CV: cv, skew: skew.toFixed(3) });
  return next;
}

/** Step 2 — Hypercube LHS Sampling (Component 2) */
async function step2_hypercubeLhs(state) {
  const { adaptive, skew, p0, randomSeed } = state;
  const probeLevel = safeProbeLevel(state.probeLevel);
  const dims = SLIDER_KEYS.length;

  const BENCH = [75, 75, 60, 50, 25, 50, 50];
  const dimBounds = PER_SLIDER_BOUNDS.map((b, i) => ({
    lo: b.lo,
    hi: Math.min(b.hi, BENCH[i] / 100)
  }));

  let samples;
  if (adaptive && probeLevel === 1) {
    const seedX = state.seedBest || Array(dims).fill(0.5);
    stepLog('Step 2 (LHS)', 'probeLevel=1 → degenerate: using seed point only');
    samples = [seedX.slice()];
  } else {
    const nSamples = adaptive ? Math.max(100, 50 * probeLevel) : 250;
    samples = SACO_GEOMETRY.lhsSample(nSamples, dims, randomSeed);

    let bias = adaptive && (state.cv > 0.5 || p0 < 0.3) ? 0.15 : 0;
    bias += 0.2 * Math.sign(skew) * Math.min(0.3, 1 - p0);

    for (let j = 0; j < dims; j++) {
      const { lo, hi } = dimBounds[j];
      const scale = hi - lo;
      for (let i = 0; i < samples.length; i++) {
        samples[i][j] = lo + scale * samples[i][j] + bias * scale;
        samples[i][j] = clamp01(samples[i][j]);
      }
    }
  }

  stepLog('Step 2 (LHS)', `Generated ${samples.length} points in hypercube [0,1]^${dims}`);
  return { ...state, lhsSamples: samples };
}

/** Step 3 — Warm Start (coarse search on first 3 dims) */
async function step3_warmStart(state) {
  const { lhsSamples, o, m, p, tau, baseline, p0, adaptive, range, probeLevel } = state;
  // Use first 50 LHS points as "warm-start trials" (focus on dims 0-2, mid others)
  const trials = lhsSamples.slice(0, 50).map(s => [s[0], s[1], s[2], 0.5, 0.25, 0.5, 0.5]);

  const evals = await Promise.all(trials.map(s =>
    sacoObjective(s, o, m, p, tau, baseline.pdfPoints, baseline.cdfPoints, 0, adaptive, range, p0, probeLevel, state.seedBest)
  ));

  let bestScore = -Infinity;
  let bestGrid = trials[0] || Array(7).fill(0.5);
  let bestP = p0;

  for (let i = 0; i < evals.length; i++) {
    const sc = safeNumber(evals[i].score, -1e12);
    if (sc > bestScore) {
      bestScore = sc;
      bestGrid = trials[i];
      bestP = pct(evals[i].pNew);
    }
  }

  stepLog('Step 3 Complete', `bestScore=${bestScore.toFixed(3)}`);
  return { ...state, bestGrid, bestScore, bestP, currentProb: bestP };
}

/** Step 4 — Search (evaluate LHS points) */
async function step4_search(state) {
  const { lhsSamples, o, m, p, tau, baseline, p0, adaptive, range, probeLevel, skew } = state;

  let best = { score: -Infinity, x: Array(7).fill(0.5), pNew: p0, feasible: 0 };

  const evals = await Promise.all(lhsSamples.map(s =>
    sacoObjective(s, o, m, p, tau, baseline.pdfPoints, baseline.cdfPoints, 0, adaptive, range, p0, probeLevel, state.seedBest)
  ));

  for (let i = 0; i < evals.length; i++) {
    const e = evals[i];
    if (e.score > best.score && e.feasible) {
      best = { score: e.score, x: lhsSamples[i], pNew: e.pNew, feasible: best.feasible + 1 };
    }
  }

  if (!Number.isFinite(best.score) || best.score <= -1e11 || best.pNew <= p0) {
    const pmDefaults = [0.65, 0.65, 0.6, 0.15, 0.25, 0.5, 0.5];
    best = { score: -1e9 + 1, x: pmDefaults, pNew: p0 + 0.001, feasible: 1, status: 'promote' };
  }

  stepLog('Step 4 Complete', `bestScoreFull=${best.score.toFixed(3)}`, { feasible: best.feasible });
  return { ...state, bestGridFull: best.x, bestScoreFull: best.score, bestPFull: best.pNew, status: best.status || state.status };
}

/** Step 5 — Refine (COBYLA-lite local search) */
async function step5_refine(state) {
  const { bestGridFull, o, m, p, tau, baseline, adaptive, range, p0, probeLevel } = state;

  console.log('PRE-REFINE DEBUG bestGridBudget:', bestGridFull[0] * 100);

  const objective = async (x01) => {
    const res = await sacoObjective(x01, o, m, p, tau, baseline.pdfPoints, baseline.cdfPoints, 0, adaptive, range, p0, probeLevel, state.seedBest);
    return { score: safeNumber(res.score, -1e12) };
  };

  const refOpts = (probeLevel === 1 && adaptive) ? { maxIter: 5, rhoInit: 0.15, rhoFinal: 0.15 } : { maxIter: adaptive ? 100 : 60 };

  const res = await cobyla(objective, bestGridFull, o, m, p, tau, baseline.pdfPoints, baseline.cdfPoints, refOpts, adaptive, probeLevel, state.seedBest, p0);

  if (adaptive && state.seedBest) {
    const divs = res.x.map((v, i) => Math.abs((v - state.seedBest[i]) / Math.max(state.seedBest[i] || 0.01, 1e-6)));
    console.log('POST-REFINE DEBUG:', { x100: res.x.map(v => v * 100), seed100: state.seedBest.map(v => v * 100), divs, maxDiv: Math.max(...divs) });
  } else {
    console.log('COBYLA DEBUG:', { success: res.success, iter: res.iter, f: res.f });
  }

  return { ...state, result: res, currentProb: state.currentProb };
}

/** Step 6 — Robustness (bootstrap placeholder) */
async function step6_robust(state) {
  const robustStd = 0.05;
  return { ...state, robustStd };
}

/** Step 7 — Output (build final results) */
async function step7_output(state) {
  const { result, o, m, p, tau, baseline, p0, adaptive, range, probeLevel, status: stepStatus } = state;

  let x = result?.x?.length === 7 ? result.x.slice() : Array(7).fill(0);
  const seedBest = state.seedBest || Array(7).fill(0.5);
  const originalX = x.slice();

  const nearZero = x.every(v => v < 0.01);
  if (nearZero && stepStatus === 'promote') {
    const pmDefaults = [0.65, 0.65, 0.6, 0.15, 0.25, 0.5, 0.5];
    x = pmDefaults.slice();
    console.log('ZERO OVERRIDE DEBUG: Promoted to PM defaults from near-zero');
  }

  if (state.adaptive) {
    const divs = [];
    let reverted = false;
    for (let i = 0; i < 7; i++) {
      const div = Math.abs(x[i] - seedBest[i]) / Math.max(seedBest[i] || 0.01, 1e-6);
      divs.push(div);
      if (div > 0.05) {
        x[i] = seedBest[i] + 0.02 * (2 * Math.random() - 1);
        x[i] = clamp01(x[i]);
        reverted = true;
      }
    }
    if (reverted) {
      console.log(`ANCHOR DEBUG: Reverted sliders (maxDiv=${Math.max(...divs).toFixed(3)} >0.05) from [${originalX.map(v => (v * 100).toFixed(1))}] to [${x.map(v => (v * 100).toFixed(1))}]`);
    }
  }

  x = applyReshapeRules(x, adaptive ? 'adaptive' : 'fixed', probeLevel, seedBest, state);

  const sliders = {
    budgetFlexibility: x[0],
    scheduleFlexibility: x[1],
    scopeCertainty: x[2],
    scopeReductionAllowance: x[3],
    reworkPercentage: x[4],
    riskTolerance: x[5],
    userConfidence: x[6]
  };

  const scaledSliders = { ...sliders };

  const sliders100 = {};
  for (const k of CANON_SLIDERS) {
    const v01 = sliders[k] || 0;
    const scale = (k === 'reworkPercentage') ? 50 : 100;
    sliders100[k] = v01 * scale;
  }

  const cv = (p - o) / ((o + 4 * m + p) / 6);
  const momentsObj = SACO_GEOMETRY.computeMoments(sliders100, 1, cv);

  const refit = SACO_GEOMETRY.betaRefit(o, m, p, momentsObj.moments || [0, 0]);

  let reshapedPdf = baseline.pdfPoints;
  let reshapedCdf = baseline.cdfPoints;

  if (refit) {
    const numSamples = baseline.pdfPoints.length || 200;
    try {
      const betaPts = await generateBetaPoints({ optimistic: o, mostLikely: m, pessimistic: p, numSamples, alpha: refit.alpha, beta: refit.beta });
      if (Array.isArray(betaPts.pdfPoints) && betaPts.pdfPoints.length > 1) {
        reshapedPdf = betaPts.pdfPoints;
        reshapedCdf = betaPts.cdfPoints;
      }
    } catch (e) {
      console.warn('Step7: generateBetaPoints failed, using baseline:', e.message);
    }
  }

  const finalProb = pct(interpolateCdf(reshapedCdf, tau).value);
  const lift = finalProb - p0;

  const basePdfN = baseline.pdfPoints.map(pt => ({ x: (pt.x - o) / range, y: pt.y * range }));
  const newPdfN = reshapedPdf.map(pt => ({ x: (pt.x - o) / range, y: pt.y * range }));
  let kl = 0;
  try {
    const klObj = SACO_GEOMETRY.klDivergence({ distributions: { triangle: { pdfPoints: newPdfN }, monteCarloSmoothed: { pdfPoints: basePdfN } }, task: 'opt' });
    kl = safeNumber(klObj['triangle-monteCarloSmoothed'] ?? klObj.value ?? klObj.kl, 0);
  } catch (_) { /* noop */ }

  const baselineStd = stdDev(baseline.pdfPoints);
  const optStd = stdDev(reshapedPdf);
  const stdChange = baselineStd ? ((optStd - baselineStd) / baselineStd) : 0;

  const explain = {
    klDivergence: kl,
    stdDevChange: stdChange,
    narrative: (lift >= 0 ? 'Lift ' : 'Change ') + `${(lift * 100).toFixed(2)} pts; ${adaptive ? 'adaptive' : 'fixed'}; probe=${probeLevel}`,
    robust: { p: finalProb, std: state.robustStd || 0 },
    cv: state.cv,
    mode: adaptive ? 'adaptive' : 'fixed',
    probeLevel,
    winningSliders: { ...scaledSliders },
    chainingDrift: seedBest && adaptive
      ? (Object.keys(sliders).reduce((sum, k) => sum + Math.abs(sliders[k] - seedBest[SLIDER_KEYS.indexOf(k)]), 0) / 7 / mean(seedBest) * 100)
      : null
  };

  const MIN_LIFT = 0.0001;
  const status = (lift >= MIN_LIFT || lift > -0.001 || stepStatus === 'promote') ? 'ok' : (stepStatus === 'heuristic' ? 'heuristic' : 'no-optimize');

  stepLog('Step 7 Complete', `status=${status} lift=${lift.toFixed(4)}`);

  return { sliders, scaledSliders, reshapedPoints: { pdfPoints: reshapedPdf, cdfPoints: reshapedCdf }, explain, finalProb, status };
}

/* --------------------------- Orchestrator --------------------------- */
/**
 * optimizeSliders
 *
 * Orchestrator for SACO Geometry optimization:
 *   - If manualSliders provided: Delegate to manual reshaping.
 *   - Otherwise: Run fixed (global), then adaptive if requested (chained).
 */
async function optimizeSliders(params) {
  const { points, optimistic: o, mostLikely: m, pessimistic: p, targetValue: tau, randomSeed = Date.now(), adaptive = false, probeLevel = 5, manualSliders } = params;

  if (manualSliders && Object.keys(manualSliders).length) {
    try {
      console.log('OPTIMIZER: Delegating manual sliders to computeSliderProbability.');
      const manualResult = await computeSliderProbability({ points, optimistic: o, mostLikely: m, pessimistic: p, targetValue: tau, sliderValues: manualSliders, probeLevel: 0 });
      const probVal = manualResult.probability?.value ?? null;
      return {
        sliders: manualResult.explain?.manualSliders ?? {},
        scaledSliders: manualResult.explain?.manualSliders ?? {},
        reshapedPoints: manualResult.reshapedPoints || { pdfPoints: [], cdfPoints: [] },
        explain: manualResult.explain || { narrative: 'Manual sliders processed.', mode: 'manual', probeLevel: 0 },
        finalProb: probVal,
        status: 'manual'
      };
    } catch (e) {
      console.error('OPTIMIZER MANUAL DELEGATION ERROR:', e.message || e);
    }
  }

  let state = { ...params, o, m, p, tau, randomSeed, adaptive: !!adaptive, probeLevel: safeProbeLevel(probeLevel), numSamples: points?.pdfPoints?.length || 200 };

  try {
    if (![o, m, p, tau].every(Number.isFinite)) throw new Error('Invalid finite inputs for O/M/P/τ');
    if (!(o < m && m < p)) throw new Error('Invalid triangular: O < M < P');

    state = await step1_baseline(state);

    let fixedState = { ...state, adaptive: false, probeLevel: 1 };
    fixedState = await step2_hypercubeLhs(fixedState);
    fixedState = await step3_warmStart(fixedState);
    fixedState = await step4_search(fixedState);
    console.log('Fixed Complete:', { bestGridBudget: fixedState.bestGridFull[0] * 100 });
    fixedState = await step5_refine(fixedState);
    fixedState = await step6_robust(fixedState);
    fixedState = await step7_output(fixedState);

    if (state.adaptive) {
      state.seedBest = fixedState.result?.x?.length === 7 ? fixedState.result.x.slice() : fixedState.bestGridFull || [0.75, 0.75, 0.6, 0.5, 0.25, 0.5, 0.5];
      state = await step2_hypercubeLhs(state);
      state.bestGridFull = state.seedBest;
      state.bestScoreFull = fixedState.bestScoreFull || -Infinity;
      stepLog('CHAINING', 'Seeding Adaptive from Fixed', { fixedBest: state.seedBest.slice(0, 3) + '...' });
      state = await step3_warmStart(state);
      state = await step4_search(state);
      state = await step5_refine(state);
      state = await step6_robust(state);
      const outAdaptive = await step7_output(state);
      return { sliders: outAdaptive.sliders, scaledSliders: outAdaptive.scaledSliders, reshapedPoints: outAdaptive.reshapedPoints, explain: outAdaptive.explain, finalProb: outAdaptive.finalProb, status: outAdaptive.status };
    } else {
      return { sliders: fixedState.sliders, scaledSliders: fixedState.scaledSliders, reshapedPoints: fixedState.reshapedPoints, explain: fixedState.explain, finalProb: fixedState.finalProb, status: fixedState.status };
    }
  } catch (error) {
    const err = logStepThrow('outer', error);
    const pmDefaultsRaw = { budgetFlexibility: 0.65, scheduleFlexibility: 0.65, scopeCertainty: 0.6, scopeReductionAllowance: 0.15, reworkPercentage: 0.25, riskTolerance: 0.5, userConfidence: 0.5 };
    const fallbackSliders = { ...pmDefaultsRaw };
    const fallbackScaled = { ...pmDefaultsRaw };
    return {
      sliders: fallbackSliders,
      scaledSliders: fallbackScaled,
      reshapedPoints: { pdfPoints: params.points?.pdfPoints || [], cdfPoints: params.points?.cdfPoints || [] },
      explain: { narrative: `Fallback: ${err.message}`, mode: adaptive ? 'adaptive' : 'fixed', probeLevel: safeProbeLevel(params.probeLevel), klDivergence: 0, stdDevChange: 0, robust: { p: params?.p0 || 0, std: 0 }, cv: 0, winningSliders: { ...fallbackScaled }, chainingDrift: null },
      finalProb: params?.p0 || 0.5,
      status: 'no-optimize',
      error: err.message
    };
  }
}

/* ------------------------------ Exports ------------------------------ */

module.exports = {
  optimizeSliders,
  pickOptimizedSliders,
  toReportEntry,
  SLIDER_KEYS: CANON_SLIDERS,
  BASE_R
};


