'use strict';

const path = require('path');
const CORE_DIR = path.resolve(__dirname, '..');

const { generateBaseline } = require(path.join(CORE_DIR, 'baseline', 'coordinator'));
const { computeSliderProbability, reshapeDistribution } = require(path.join(CORE_DIR, 'reshaping', 'slider-adjustments'));
const { optimizeSliders, pickOptimizedSliders, toReportEntry } = require(path.join(CORE_DIR, 'optimization', 'optimizer'));
const { validateEstimates, validateSliders, isValidPdfArray, isValidCdfArray } = require(path.join(CORE_DIR, 'helpers', 'validation'));
const { interpolateCdf, calculateMetrics } = require(path.join(CORE_DIR, 'helpers', 'metrics'));
const { computeKLDivergence } = require(path.join(CORE_DIR, 'optimization', 'kl-divergence'));

// CSV + summaries builder (also returns an optional reports[] now)
const { buildReports } = require(path.join(CORE_DIR, 'report', 'reshaping_report'));

/**
 * NOTE: Preflight in deploy_pmc_api.js expects this exact string:
 *   SCHEMA_VERSION = '2025-10-16.api-envelope.v1'
 * Do not change unless you also update the deploy script.
 */
const SCHEMA_VERSION = '2025-10-16.api-envelope.v1';
const MAX_POINTS = 200;

const BUILD_INFO = {
  name: 'core-main-2025-10-16.api-envelope.v1',
  tag: 'saco-v1.9.27',  // SACO chaining + manual SACO reshape + 0–1 slider normalization at adapter layer
  commit: process.env.GIT_COMMIT || null,
  builtAt: new Date().toISOString(),
  randomSeed: process.env.PMC_RANDOM_SEED || null
};

/* ------------------------------------------------------------------ *
 * SACO THESIS SUMMARY (Shape-Adaptive Copula Optimization)
 * ------------------------------------------------------------------ *
 * Core idea:
 *   - Start from a probabilistic baseline (Monte Carlo PERT) for (O, M, P).
 *   - Map sliders → shape parameters (mean shift, variance shrink) via a
 *     copula-informed moment mapping.
 *   - Refit a Beta distribution on [O, P] to match adjusted mean/variance.
 *   - Score candidates by p(target) · exp(−KL(refit || baseline)),
 *     preferring high target probability with controlled distortion.
 *
 * How this main module uses SACO:
 *   1. Baseline:
 *        - generateBaseline → MC-smoothed PDF/CDF, metrics, PERT mean.
 *        - This becomes the reference “geometry” for all reshapes.
 *
 *   2. Manual reshape (user sliders):
 *        - UI sliders are provided in UI units:
 *            • 0–100 for most sliders
 *            • 0–50 for reworkPercentage
 *        - reshapeDistribution(...) is called with these UI sliders.
 *          Internally, slider-adjustments normalizes to 0–1 and calls
 *          computeSliderProbability (copula + Beta refit).
 *        - Output (in this file): adjusted.reshapedPoints +
 *          adjusted.probabilityAtTarget, plus explain metadata.
 *        - Adapter (adapter.js) then exposes adjusted.manualSliders01 as
 *          a strict 0–1 block for the frontend, while the UI remains free
 *          to display % (e.g., 0.75 → 75%).
 *
 *   3. Optimization (optional SACO search):
 *        - Controlled by:
 *            • optimize (boolean) – run optimizer or not.
 *            • probeLevel (0–7)  – search “depth” / aggressiveness.
 *            • adaptive (boolean) – use SACO chaining from Fixed → Adaptive.
 *
 *        - Fixed mode (coarse scout):
 *            • Runs with adaptive=false, shallow probeLevel=1.
 *            • Produces a reasonable seed sliders01 for Adaptive.
 *
 *        - Adaptive mode (full SACO):
 *            • Uses Fixed’s best sliders01 as seed (if available).
 *            • Performs deeper SACO search with requested probeLevel.
 *            • Outputs optimized sliders, reshaped points and probability.
 *
 *        - The optimizer operates on internal 0–1 sliders; this file
 *          surfaces:
 *            • optimize.sliders / scaledSliders in UI units
 *              (for human readability / reporting).
 *            • optimize.sliders01 as the canonical 0–1 vector.
 *          The adapter (adapter.js) then normalizes optimize.sliders and
 *          optimize.scaledSliders back to 0–1 for the Plot.html slider grid
 *          and decision sliders comparison table.
 *
 *   4. Probe levels and “manual only” mode:
 *        - probeLevel = 0:
 *            • No SACO auto-optimization is run.
 *            • Manual SACO reshape still runs via reshapeDistribution, but
 *              we expose it in a dedicated “manual” optimize block so the UI
 *              can treat it as a distinct variant.
 *        - probeLevel > 0 and optimize=true:
 *            • Run Fixed (shallow) + Adaptive (deep, seeded) when adaptive=true.
 *            • Run Fixed-only when adaptive=false.
 *
 *   5. Envelope:
 *        - This file produces the “core” response consumed by adapter.js:
 *            • baseline (MC-smoothed + metrics + CI)
 *            • adjusted (manual SACO reshape)
 *            • optimize (fixed/adaptive/manual block)
 *            • targetProbability mirrors
 *            • CSV/report bundles and debugPresence flags.
 *
 * Design goals:
 *   - All slider-driven distributions (manual or optimized) pass through the
 *     same SACO geometry (copula → moments → Beta refit).
 *   - The 0–1 semantics are canonical and consistent across:
 *       • optimize.sliders01 (here)
 *       • optimize.sliders / scaledSliders after adapter normalization.
 *   - UI can safely present sliders as 0–100% / 0–50% without worrying
 *     about the internal SACO math.
 * ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ *
 *                              Utilities
 * ------------------------------------------------------------------ */
function raise(message, details = {}) {
  const err = new Error(message || 'Unknown error');
  err.details = details;
  throw err;
}

function extractError(e) {
  const message = (e && (e.message || e.error)) || (typeof e === 'string' ? e : 'Unknown error');
  const details = (e && (e.details || e)) || {};
  const stack = e && e.stack ? e.stack : undefined;
  return { message, details, stack };
}

function clipPoints(arr) {
  if (!Array.isArray(arr)) return [];
  return arr.slice(0, MAX_POINTS);
}

function coercePercent01(x) {
  return Math.max(0, Math.min(1, Number(x)));
}

function asPointsArray(maybe) {
  if (Array.isArray(maybe)) return maybe;
  if (maybe && Array.isArray(maybe.value)) return maybe.value;
  return [];
}

// Convert UI slider units → normalized 0..1 domain
//   - All sliders except rework: 0–100% → 0..1
//   - reworkPercentage: 0–50% → 0..0.5 (variance controls are intentionally bounded)
function to01FromUi(sliders) {
  const out = {};
  if (!sliders || typeof sliders !== 'object') return out;
  out.budgetFlexibility        = Math.max(0, Math.min(1, (Number(sliders.budgetFlexibility)        || 0) / 100));
  out.scheduleFlexibility      = Math.max(0, Math.min(1, (Number(sliders.scheduleFlexibility)      || 0) / 100));
  out.scopeCertainty           = Math.max(0, Math.min(1, (Number(sliders.scopeCertainty)           || 0) / 100));
  out.scopeReductionAllowance  = Math.max(0, Math.min(1, (Number(sliders.scopeReductionAllowance)  || 0) / 100));
  out.reworkPercentage         = Math.max(0, Math.min(0.5, (Number(sliders.reworkPercentage)       || 0) / 50));
  out.riskTolerance            = Math.max(0, Math.min(1, (Number(sliders.riskTolerance)            || 0) / 100));
  const uc = sliders.userConfidence == null ? 100 : Number(sliders.userConfidence);
  out.userConfidence           = Math.max(0, Math.min(1, (Number.isFinite(uc) ? uc : 100) / 100));
  return out;
}

/* ------------------------------------------------------------------ *
 *                           Task processing
 *           (Baseline → Manual SACO reshape → Optional Optimize)
 * ------------------------------------------------------------------ */
async function processTask(task) {
  try {
    const state = {
      sims: [],
      metrics: {},
      taskEcho: task?.task || 'Unnamed',
      pertMean: (task.optimistic + 4 * task.mostLikely + task.pessimistic) / 6
    };

    const {
      task: taskName,
      optimistic,
      mostLikely,
      pessimistic,
      targetValue,
      confidenceLevel = 0.95,
      optimize = true,
      optimizeFor = 'target',
      sliderValues: inputSliders = {},
      suppressOtherDistros = false,
      mode = (optimize ? 'opt' : 'view'),
      randomSeed = BUILD_INFO.randomSeed || Date.now().toString(),
      adaptive = true,
      // Caller’s “optimization depth” (1–7).
      //   probeLevel = 0 → manual-only: no SACO auto search, but manual SACO reshape still runs.
      probeLevel = 5
    } = task || {};

    const hasTarget = Number.isFinite(targetValue);

    // ----- Input validation -------------------------------------------------
    const estVal = validateEstimates(optimistic, mostLikely, pessimistic);
    if (!estVal.valid) raise(estVal.message || 'Invalid estimates', { optimistic, mostLikely, pessimistic });

    if (!(confidenceLevel > 0 && confidenceLevel < 1)) {
      raise('Invalid confidenceLevel', { confidenceLevel });
    }

    if (!['target', 'mean', 'risk'].includes(optimizeFor)) {
      raise('Invalid optimizeFor', { optimizeFor });
    }

    if (adaptive && (probeLevel < 0 || probeLevel > 7)) {
      raise('probeLevel must be 0–7', { probeLevel });
    }

    // ----- Sliders (UI units; shared by manual + optimize) ------------------
    //
    // These are the values the UI thinks in: 0–100 (or 0–50 for rework).
    // The SACO internals and adapter layer are responsible for normalizing
    // into 0–1 where needed.
    const slidersUi = {
      budgetFlexibility:        Number.isFinite(inputSliders.budgetFlexibility)       ? Math.max(0, Math.min(100, Number(inputSliders.budgetFlexibility)))       : 0,
      scheduleFlexibility:      Number.isFinite(inputSliders.scheduleFlexibility)     ? Math.max(0, Math.min(100, Number(inputSliders.scheduleFlexibility)))     : 0,
      scopeCertainty:           Number.isFinite(inputSliders.scopeCertainty)          ? Math.max(0, Math.min(100, Number(inputSliders.scopeCertainty)))          : 0,
      scopeReductionAllowance:  Number.isFinite(inputSliders.scopeReductionAllowance) ? Math.max(0, Math.min(100, Number(inputSliders.scopeReductionAllowance))) : 0,
      reworkPercentage:         Number.isFinite(inputSliders.reworkPercentage)        ? Math.max(0, Math.min(50,  Number(inputSliders.reworkPercentage)))        : 0,
      riskTolerance:            Number.isFinite(inputSliders.riskTolerance)           ? Math.max(0, Math.min(100, Number(inputSliders.riskTolerance)))           : 0,
      userConfidence:           Number.isFinite(inputSliders.userConfidence)          ? Math.max(0, Math.min(100, Number(inputSliders.userConfidence)))          : 100
    };
    const sliderVal = validateSliders(slidersUi);
    if (!sliderVal.valid) raise(sliderVal.message || 'Invalid sliders', { slidersUi });

    // ----- Baseline (Step 1: MC-smoothed reference geometry) ----------------
    const baselineRaw = await generateBaseline({
      optimistic,
      mostLikely,
      pessimistic,
      numSamples: MAX_POINTS,
      suppressOtherDistros,
      randomSeed
    });
    if (baselineRaw?.error) raise(`generateBaseline failed: ${baselineRaw.error}`, baselineRaw.details || {});

    const mcBlock =
      baselineRaw?.monteCarloSmoothedPoints ||
      baselineRaw?.monteCarloSmoothed ||
      baselineRaw?.monteCarlo ||
      baselineRaw?.distributions?.monteCarloSmoothed ||
      null;

    const pdf = asPointsArray(mcBlock?.pdfPoints) || asPointsArray(mcBlock?.pdf);
    const cdf = asPointsArray(mcBlock?.cdfPoints) || asPointsArray(mcBlock?.cdf);

    if (!isValidPdfArray(pdf) || !isValidCdfArray(cdf)) {
      raise('Invalid MC-smoothed points', {
        havePdf: Array.isArray(pdf) ? pdf.length : 0,
        haveCdf: Array.isArray(cdf) ? cdf.length : 0,
        availableKeys: Object.keys(baselineRaw || {})
      });
    }

    const triangleBlock = baselineRaw.trianglePoints || baselineRaw.triangle || baselineRaw?.distributions?.triangle;
    const betaPertBlock = baselineRaw.pertPoints     || baselineRaw.betaPert || baselineRaw?.distributions?.betaPert;

    const trianglePdfPoints = asPointsArray(triangleBlock?.pdfPoints) || asPointsArray(triangleBlock?.pdf);
    const triangleCdfPoints = asPointsArray(triangleBlock?.cdfPoints) || asPointsArray(triangleBlock?.cdf);
    const betaPertPdfPoints = asPointsArray(betaPertBlock?.pdfPoints) || asPointsArray(betaPertBlock?.pdf);
    const betaPertCdfPoints = asPointsArray(betaPertBlock?.cdfPoints) || asPointsArray(betaPertBlock?.cdf);

    // Metrics (PERT, CI, CV, etc.)
    const metrics = calculateMetrics({
      optimistic,
      mostLikely,
      pessimistic,
      triangle: trianglePdfPoints.length
        ? { pdfPoints: trianglePdfPoints, cdfPoints: triangleCdfPoints }
        : undefined,
      monteCarloSmoothed: { pdfPoints: pdf, cdfPoints: cdf },
      confidenceLevel,
      robustStd: adaptive ? (state?.robustStd || 0) : 0
    });
    if (metrics?.error) raise(`calculateMetrics failed: ${metrics.error}`, metrics.details || {});
    const pertMean = Number(metrics?.pert?.mean);
    const ciLower  = Number(metrics?.monteCarloSmoothed?.ci?.lower);
    const ciUpper  = Number(metrics?.monteCarloSmoothed?.ci?.upper);

    // Baseline probabilities at τ and at μ_PERT
    const baseProb = hasTarget ? coercePercent01(interpolateCdf(cdf, targetValue).value) : null;
    const baselineProbAtPert = Number.isFinite(pertMean)
      ? coercePercent01(interpolateCdf(cdf, pertMean).value)
      : undefined;

    // KL divergence vs triangle (diagnostic only)
    let klToTriangle;
    try {
      if (trianglePdfPoints.length && pdf.length) {
        const klObj = computeKLDivergence({
          distributions: {
            triangle: { pdfPoints: trianglePdfPoints },
            monteCarloSmoothed: { pdfPoints: pdf }
          },
          task: taskName || ''
        });
        if (klObj && typeof klObj === 'object') {
          klToTriangle = Number(
            klObj['triangle-monteCarloSmoothed'] ??
            klObj.value ??
            klObj.kl ??
            klObj.klDivergence
          );
        }
      }
    } catch (_) {
      // KL is best-effort only; safe to ignore failures here.
    }

    // -----------------------------------------------------------------------
    // Adjusted (manual sliders) — SACO reshape via slider-adjustments
    // -----------------------------------------------------------------------
    //
    // Design:
    //   - Manual sliders always flow through reshapeDistribution, which
    //     internally uses computeSliderProbability and the same SACO
    //     geometry as the optimizer (copula + Beta refit).
    //
    //   - We pass the UI sliders (0–100 / 0–50) in here; the reshaping
    //     layer normalizes as needed. The adapter later exposes a clean
    //     0–1 block (adjusted.manualSliders01) for the frontend.
    //
    //   - This block is independent of probeLevel for optimization:
    //       • Even when probeLevel=0 (manual-only), we still compute this
    //         SACO-adjusted distribution for the current sliders.
    let adjRes = null;
    try {
      adjRes = await reshapeDistribution({
        points: { pdfPoints: pdf, cdfPoints: cdf },
        optimistic,
        mostLikely,
        pessimistic,
        targetValue,
        sliderValues: slidersUi,
        // Manual path uses a lightweight SACO probe; optimization depth
        // is controlled separately by probeLevel for optimize().
        probeLevel: 1
      });
    } catch (err) {
      adjRes = {
        error: err.message,
        explain: {
          narrative: `Manual SACO reshape error: ${err.message}. Falling back to baseline.`
        }
      };
    }

    const adjustedBlock = (!adjRes || adjRes.error)
      ? {
          status: 'error',
          reasonCode: 'adjusted_error',
          message: adjRes?.error || 'Unknown adjusted error',
          explain: adjRes?.explain || null
        }
      : {
          status: 'ok',
          probabilityAtTarget: {
            value: hasTarget
              ? coercePercent01(adjRes.probability?.value)
              : undefined
          },
          reshapedPoints: {
            pdfPoints: clipPoints(adjRes.reshapedPoints?.pdfPoints || pdf),
            cdfPoints: clipPoints(adjRes.reshapedPoints?.cdfPoints || cdf)
          },
          explain: adjRes.explain || null
        };

    const allZeroPassThrough =
      !!(adjustedBlock.explain &&
         String(adjustedBlock.explain.allZeroSlidersPassThrough || '')
           .toLowerCase() === 'yes');

    // -----------------------------------------------------------------------
    // Optimization (SACO fixed/adaptive) — optional
    // -----------------------------------------------------------------------
    //
    // Behaviour:
    //   - If optimize === false → skip completely.
    //   - If probeLevel === 0 → “manual-only” mode:
    //       • Skip auto optimization, even if optimize=true.
    //       • Manual SACO reshape (adjustedBlock) still runs.
    //       • We expose a separate manual optimize block later on.
    //   - If optimize === true and probeLevel > 0:
    //       • If adaptive === true:
    //            - Run Fixed (coarse scout, shallow probeLevel=1).
    //            - Seed Adaptive from Fixed’s best sliders01.
    //       • If adaptive === false:
    //            - Run Fixed only.
    //
    // Slider semantics here:
    //   - Internally, optimizeSliders works in 0–1 space.
    //   - optRes.sliders01 is the canonical 0–1 output (if present).
    //   - We derive a UI-facing sliders object (0–100 / 0–50) for
    //     human readability and CSV/reporting.
    //   - The adapter later normalizes optimize.sliders / scaledSliders
    //     into 0–1 so the frontend sees a consistent domain.
    let optimizeBlock = {
      status: 'skipped',
      reasonCode: !optimize ? 'optimize_false' : (probeLevel === 0 ? 'probe_zero_manual_only' : 'not_requested')
    };

    let __tp_adjustedOptimized;
    let __tp_adaptiveOptimized;
    let __manualOptimizeBlock;

    if (optimize && probeLevel > 0) {
      let fixedRes = null;
      let adaptiveRes = null;
      let seedBest = null;

      if (adaptive) {
        // Fixed: coarse global scout (no chaining, shallow probe) to find a
        // sensible starting point for Adaptive.
        fixedRes = await optimizeSliders({
          points: { pdfPoints: pdf, cdfPoints: cdf },
          optimistic,
          mostLikely,
          pessimistic,
          targetValue: Number.isFinite(targetValue) ? targetValue : pertMean,
          optimizeFor,
          distributionType: 'monte-carlo-smoothed',
          randomSeed,
          adaptive: false,
          probeLevel: 1
        });

        if (fixedRes && !fixedRes.error) {
          seedBest = {
            sliders01: fixedRes.sliders01 || pickOptimizedSliders(fixedRes),
            finalProb: fixedRes.finalProb ||
                       fixedRes.optimizedResult?.probability?.value ||
                       baseProb
          };
        }
      }

      // Adaptive or standalone optimization (SACO with chaining if seedBest)
      const optInput = {
        points: { pdfPoints: pdf, cdfPoints: cdf },
        optimistic,
        mostLikely,
        pessimistic,
        targetValue: Number.isFinite(targetValue) ? targetValue : pertMean,
        optimizeFor,
        distributionType: 'monte-carlo-smoothed',
        randomSeed,
        adaptive: true,
        probeLevel,
        seedSliders: seedBest ? seedBest.sliders01 : null
      };

      adaptiveRes = await optimizeSliders(optInput);
      const optRes = adaptive ? adaptiveRes : (fixedRes || adaptiveRes);

      if (!optRes || optRes.error) {
        console.warn('OPT ERROR: Optimizer failed', optRes?.error);
        optimizeBlock = {
          status: 'error',
          reasonCode: 'optimize_failed',
          message: optRes?.error || 'Unknown optimizer error'
        };
      } else {
        // --- Sliders: UI vs 0–1 domains ------------------------------------
        const slidersUiOpt = (optRes && optRes.scaledSliders) || null;
        const sliders01Opt = (optRes && (optRes.sliders01 || optRes.sliders)) || null;

        let slidersUiSafe = slidersUiOpt;
        let sliders01Safe = sliders01Opt;

        // If UI sliders missing, derive from 0–1 normalized
        if (!slidersUiSafe) {
          const picked01 = pickOptimizedSliders(optRes);
          if (picked01 && Object.keys(picked01).length) {
            slidersUiSafe = {
              budgetFlexibility:        (picked01.budgetFlexibility        || 0) * 100,
              scheduleFlexibility:      (picked01.scheduleFlexibility      || 0) * 100,
              scopeCertainty:           (picked01.scopeCertainty           || 0) * 100,
              scopeReductionAllowance:  (picked01.scopeReductionAllowance  || 0) * 100,
              reworkPercentage:         (picked01.reworkPercentage         || 0) * 50,
              riskTolerance:            (picked01.riskTolerance            || 0) * 100,
              userConfidence:           (picked01.userConfidence           || 0) * 100
            };
          } else {
            slidersUiSafe = {
              budgetFlexibility: 0,
              scheduleFlexibility: 0,
              scopeCertainty: 0,
              scopeReductionAllowance: 0,
              reworkPercentage: 0,
              riskTolerance: 0,
              userConfidence: 0
            };
          }
        }
        // If 0–1 sliders missing, derive from UI
        if (!sliders01Safe) {
          sliders01Safe = to01FromUi(slidersUiSafe);
        }

        // --- Reshaped points -----------------------------------------------
        const reshaped = optRes?.reshapedPoints ||
                         optRes?.optimizedResult?.reshapedPoints ||
                         null;

        let optPdf = asPointsArray(reshaped?.monteCarloSmoothed?.pdfPoints) ||
                     asPointsArray(reshaped?.pdfPoints);
        let optCdf = asPointsArray(reshaped?.monteCarloSmoothed?.cdfPoints) ||
                     asPointsArray(reshaped?.cdfPoints);

        // --- Probability at target -----------------------------------------
        let adjProb = Number(optRes?.finalProb);
        if (!Number.isFinite(adjProb)) {
          adjProb = Number(optRes?.optimizedResult?.probability?.value);
        }

        // Fallback: interpolate from whatever optimized CDF we have
        if (!Number.isFinite(adjProb)) {
          const tgt = Number.isFinite(targetValue) ? targetValue : pertMean;
          const optCdfRaw = asPointsArray(
            optRes?.optimizedResult?.reshapedPoints?.cdfPoints ||
            optRes?.reshapedPoints?.cdfPoints ||
            optCdf
          );
          if (Array.isArray(optCdfRaw) && optCdfRaw.length >= 2 && Number.isFinite(tgt)) {
            const interpCdf = optCdfRaw.slice().sort((a, b) => a.x - b.x);
            const interpRes = interpolateCdf(interpCdf, tgt);
            adjProb = Number.isFinite(interpRes.value) ? coercePercent01(interpRes.value) : undefined;
          }
        }

        // If points missing, recompute via reshapeDistribution with SACO
        if ((!Array.isArray(optPdf) || !optPdf.length ||
             !Array.isArray(optCdf) || !optCdf.length) && slidersUiSafe) {
          const mat = await reshapeDistribution({
            points: { pdfPoints: pdf, cdfPoints: cdf },
            optimistic,
            mostLikely,
            pessimistic,
            targetValue: Number.isFinite(targetValue) ? targetValue : pertMean,
            sliderValues: slidersUiSafe,
            probeLevel: probeLevel || 1
          });
          if (!mat?.error) {
            optPdf = asPointsArray(mat?.reshapedPoints?.pdfPoints);
            optCdf = asPointsArray(mat?.reshapedPoints?.cdfPoints);
            if (!Number.isFinite(adjProb)) adjProb = Number(mat?.probability?.value);
            if (mat?.explain && !optRes.explain) optRes.explain = mat.explain;
          } else {
            optPdf = pdf.slice();
            optCdf = cdf.slice();
          }
        }

        const tgt = Number.isFinite(targetValue) ? targetValue : pertMean;
        const baseAtSameTarget = Number.isFinite(tgt)
          ? coercePercent01(interpolateCdf(cdf, tgt).value)
          : 0.5;

        if (!Number.isFinite(adjProb)) {
          optimizeBlock = {
            status: 'error',
            reasonCode: 'probability_missing',
            message: 'Optimizer did not return a valid probability and interpolation failed.',
            reshapedPoints: {
              pdfPoints: clipPoints(optPdf || pdf),
              cdfPoints: clipPoints(optCdf || cdf)
            },
            sliders: slidersUiSafe || {},
            scaledSliders: slidersUiSafe || {},
            sliders01: sliders01Safe || {}
          };
        } else {
          const sensChange = adjProb - baseAtSameTarget;

          let explain = optRes.explain;
          if (explain) {
            if (!Number.isFinite(explain.baselineProb)) explain.baselineProb = baseAtSameTarget;
            if (!Number.isFinite(explain.finalProb))    explain.finalProb    = adjProb;
            if (!explain.mode) explain.mode = adaptive ? 'saco-adaptive' : 'saco-fixed';
            if (typeof explain.probeLevel === 'undefined') explain.probeLevel = probeLevel;

            // Attach seedBest / chaining drift if adaptive (for UI audit)
            if (adaptive && seedBest) {
              explain.seedBest = seedBest;
              if (Number.isFinite(seedBest.finalProb) && Number.isFinite(adjProb)) {
                explain.chainingDrift =
                  Math.abs((adjProb - seedBest.finalProb) / seedBest.finalProb) * 100;
              }
            }

            // For human-readable tables, winningSliders expressed in UI units;
            // sliders01 retains raw 0–1 for programmatic use.
            if (explain.winningSliders && Object.keys(explain.winningSliders).length) {
              explain.winningSliders = { ...slidersUiSafe };
            }
          } else {
            explain = {
              baselineProb: baseAtSameTarget,
              finalProb: adjProb,
              narrative: 'Optimization completed.',
              mode: adaptive ? 'saco-adaptive' : 'saco-fixed',
              probeLevel,
              sliders: [],
              winningSliders: slidersUiSafe || {}
            };
            if (adaptive && seedBest &&
                Number.isFinite(seedBest.finalProb) && Number.isFinite(adjProb)) {
              explain.seedBest = seedBest;
              explain.chainingDrift =
                Math.abs((adjProb - seedBest.finalProb) / seedBest.finalProb) * 100;
            }
            optRes.explain = explain;
          }

          optimizeBlock = {
            status: optRes.status || 'ok',
            // Back-compat: `sliders` / `scaledSliders` stay in UI units here.
            // The adapter normalizes them into 0–1 for the frontend.
            sliders: slidersUiSafe || {},
            scaledSliders: slidersUiSafe || {},
            // Canonical 0–1 vector for programmatic consumers:
            sliders01: sliders01Safe || {},
            probabilityAtTarget: { value: adjProb },
            reshapedPoints: {
              pdfPoints: clipPoints(optPdf || pdf),
              cdfPoints: clipPoints(optCdf || cdf)
            },
            metrics: { sensitivityChange: sensChange },
            explain,
            certificate: (typeof optRes.certificate === 'string'
              ? optRes.certificate
              : (optRes.certificate ? JSON.stringify(optRes.certificate) : undefined))
          };

          __tp_adjustedOptimized = adjProb;
          __tp_adaptiveOptimized = adaptive ? adjProb : undefined;
        }
      }
    }

    // -----------------------------------------------------------------------
    // Manual-only mode (probeLevel = 0)
    // -----------------------------------------------------------------------
    //
    // When probeLevel === 0, we do NOT run the auto optimizer even if
    // optimize=true. Instead, we expose a “manual” block that surfaces
    // the SACO-adjusted distribution and sliders as a first-class variant.
    if (probeLevel === 0) {
      const manualPdf = adjustedBlock.reshapedPoints?.pdfPoints || pdf;
      const manualCdf = adjustedBlock.reshapedPoints?.cdfPoints || cdf;
      const manual01  = to01FromUi(slidersUi);

      const manualBlock = {
        status: 'manual',
        sliders: { ...slidersUi },        // UI units for display / CSV
        sliders01: manual01,              // normalized 0–1 for code / adapter
        scaledSliders: { ...slidersUi },  // alias in UI units (for back-compat)
        reshapedPoints: {
          pdfPoints: clipPoints(manualPdf),
          cdfPoints: clipPoints(manualCdf)
        },
        explain: {
          ...(adjustedBlock.explain || {}),
          narrative: (adjustedBlock.explain?.narrative ||
                      'Manual mode: User sliders applied via SACO reshape.'),
          probeLevel: 0
        }
      };
      __manualOptimizeBlock = manualBlock;

      if (hasTarget) {
        const pManual = adjustedBlock.probabilityAtTarget?.value ?? baseProb;
        __tp_adjustedOptimized = pManual;
        __tp_adaptiveOptimized = adaptive ? pManual : undefined;
      }
    }

    // -----------------------------------------------------------------------
    // Response envelope
    // -----------------------------------------------------------------------
    const response = {
      schemaVersion: SCHEMA_VERSION,
      buildInfo: BUILD_INFO,
      taskEcho: {
        task: taskName,
        optimistic,
        mostLikely,
        pessimistic,
        targetValue,
        confidenceLevel,
        randomSeed,
        adaptive,
        probeLevel
      },

      flags: {
        allZeroPassThrough,
        hasTarget: hasTarget
      },

      baseline: {
        status: 'ok',
        pert: { value: Number.isFinite(pertMean) ? pertMean : undefined },
        probabilityAtTarget: { value: hasTarget ? baseProb : undefined },
        probabilityAtPert: { value: baselineProbAtPert },
        monteCarloSmoothed: {
          pdfPoints: clipPoints(pdf),
          cdfPoints: clipPoints(cdf)
        },
        metrics: {
          monteCarloSmoothed: {
            ci: { lower: ciLower, upper: ciUpper }
          },
          klDivergenceToTriangle: Number.isFinite(klToTriangle) ? klToTriangle : undefined
        }
      },

      trianglePdf: { value: clipPoints(trianglePdfPoints) },
      triangleCdf: { value: clipPoints(triangleCdfPoints) },
      betaPertPdf: { value: clipPoints(betaPertPdfPoints) },
      betaPertCdf: { value: clipPoints(betaPertCdfPoints) },

      adjusted: adjustedBlock,
      optimize: __manualOptimizeBlock || optimizeBlock,

      // Always expose the final slider vector (manual or optimized) to the UI
      optimalSliderSettings: (
        (__manualOptimizeBlock || optimizeBlock).sliders
          ? { value: (__manualOptimizeBlock || optimizeBlock).sliders }
          : { value: {} }
      ),

      debugPresence: {
        baseline: {
          pdf: Array.isArray(pdf) && pdf.length > 0,
          cdf: Array.isArray(cdf) && cdf.length > 0
        },
        optimized: {
          sliders:
            !!((__manualOptimizeBlock || optimizeBlock).sliders &&
               Object.keys((__manualOptimizeBlock || optimizeBlock).sliders).length > 0),
          pdf:
            Array.isArray((__manualOptimizeBlock || optimizeBlock)?.reshapedPoints?.pdfPoints) &&
            (__manualOptimizeBlock || optimizeBlock).reshapedPoints.pdfPoints.length > 0,
          cdf:
            Array.isArray((__manualOptimizeBlock || optimizeBlock)?.reshapedPoints?.cdfPoints) &&
            (__manualOptimizeBlock || optimizeBlock).reshapedPoints.cdfPoints.length > 0
        }
      }
    };

    // Back-compat: aggregates and probability mirrors
    response.allDistributions = {
      value: {
        monteCarloSmoothed: response.baseline.monteCarloSmoothed,
        triangle: trianglePdfPoints.length
          ? {
              pdfPoints: clipPoints(trianglePdfPoints),
              cdfPoints: clipPoints(triangleCdfPoints)
            }
          : undefined,
        betaPert: betaPertPdfPoints.length
          ? {
              pdfPoints: clipPoints(betaPertPdfPoints),
              cdfPoints: clipPoints(betaPertCdfPoints)
            }
          : undefined
      }
    };
    response.monteCarloSmoothed = response.baseline.monteCarloSmoothed;
    response.monteCarloSmoothedPoints = response.baseline.monteCarloSmoothed;

    response.pertMean = { value: response.baseline.pert.value };
    if (!response.targetProbability) response.targetProbability = { value: {} };

    if (baseProb !== undefined && baseProb !== null) {
      response.targetProbability.value.original = baseProb;
    }

    response.targetProbability.value.adjusted = hasTarget
      ? (response.adjusted?.probabilityAtTarget?.value ??
         response.baseline.probabilityAtTarget.value)
      : undefined;

    if (__tp_adjustedOptimized != null) {
      response.targetProbability.value.adjustedOptimized = __tp_adjustedOptimized;
    } else if (hasTarget) {
      response.targetProbability.value.adjustedOptimized =
        response.optimize?.probabilityAtTarget?.value ??
        response.baseline.probabilityAtTarget.value;
    }

    if (__tp_adaptiveOptimized != null) {
      response.targetProbability.value.adaptiveOptimized = __tp_adaptiveOptimized;
    } else if (adaptive && hasTarget) {
      response.targetProbability.value.adaptiveOptimized =
        response.optimize?.probabilityAtTarget?.value ??
        response.baseline.probabilityAtTarget.value;
    }

    response.targetProbabilityOriginalPdf = {
      value: response.baseline.monteCarloSmoothed.pdfPoints
    };
    response.targetProbabilityOriginalCdf = {
      value: response.baseline.monteCarloSmoothed.cdfPoints
    };
    response.targetProbabilityAdjustedPdf = {
      value: response.adjusted?.reshapedPoints?.pdfPoints ||
             response.baseline.monteCarloSmoothed.pdfPoints
    };
    response.targetProbabilityAdjustedCdf = {
      value: response.adjusted?.reshapedPoints?.cdfPoints ||
             response.baseline.monteCarloSmoothed.cdfPoints
    };

    response.optimizedReshapedPoints = response.optimize?.reshapedPoints || null;

    response.explain = {
      adjusted: response.adjusted?.explain || null,
      optimized: response.optimize?.explain || null
    };
    if (adaptive) {
      if (response.explain && response.explain.adaptive == null) {
        response.explain.adaptive = response.explain.optimized ?? null;
      }
    }

    if (optimize && (response.optimize.status === 'ok' || response.optimize.status === 'manual')) {
      if (adaptive) {
        response.adaptiveReshapedPoints = response.optimize.reshapedPoints;
        response.explain.adaptive = response.optimize.explain;
        response.adaptiveOptimalSliderSettings = {
          value: response.optimize.sliders || {}
        };
      } else {
        response.optimizedReshapedPoints = response.optimize.reshapedPoints;
        response.explain.optimized = response.optimize.explain;
        response.optimalSliderSettings = {
          value: response.optimize.sliders || {}
        };
      }
      response.optimizedReshapedPoints =
        response.optimizedReshapedPoints ||
        response.adaptiveReshapedPoints ||
        null;
      response.optimalSliderSettings =
        response.optimalSliderSettings ||
        response.adaptiveOptimalSliderSettings ||
        { value: {} };
    }

    // ---------------- CSV + summaries + reports[] --------------------------
    const taskMeta = {
      task: taskName,
      optimistic,
      mostLikely,
      pessimistic,
      targetValue,
      confidenceLevel
    };
    const reportsBundle = buildReports({
      taskMeta,
      baseline: response.baseline,
      adjusted: response.adjusted,
      optimized: response.optimize,
      mode: mode === 'opt' ? 'opt' : 'view'
    });

    response.decisionReportsBundle = {
      baselineCsv: reportsBundle.baselineCsv,
      decisionCsv: reportsBundle.decisionCsv,
      summaries: reportsBundle.summaries,
      meta: reportsBundle.meta
    };

    response.decisionCsv = reportsBundle.decisionCsv;
    response.summaries = reportsBundle.summaries;

    const reportsArray = [];
    if (response.adjusted?.explain) {
      reportsArray.push(
        toReportEntry(
          'Adjusted',
          Number.isFinite(targetValue) ? targetValue : mostLikely,
          response.adjusted.explain.baselineProb,
          response.adjusted.explain.finalProb,
          response.adjusted.explain,
          null
        )
      );
    }
    if (response.optimize?.explain) {
      reportsArray.push(
        toReportEntry(
          response.optimize?.status === 'manual' ? 'Manual' : 'Optimize',
          Number.isFinite(targetValue) ? targetValue : mostLikely,
          response.optimize.explain.baselineProb,
          response.optimize.explain.finalProb,
          response.optimize.explain,
          response.optimize.certificate
        )
      );
    }
    response.decisionReports = reportsArray.filter(Boolean);

    return response;
  } catch (e) {
    const { message, details, stack } = extractError(e);
    return {
      schemaVersion: SCHEMA_VERSION,
      buildInfo: BUILD_INFO,
      error: message,
      details,
      stack
    };
  }
}

/* ------------------------------------------------------------------ *
 *                              API entry
 * ------------------------------------------------------------------ */
async function pmcEstimatorAPI(tasks) {
  try {
    if (!Array.isArray(tasks) || tasks.length === 0) {
      raise('Tasks must be a non-empty array', { tasks });
    }
    const results = [];
    const feedbackMessages = [];
    for (const t of tasks) {
      const r = await processTask(t);
      results.push(r);
      if (r?.error) feedbackMessages.push(`Failed to process task ${t?.task}: ${r.error}`);
    }
    return { results, error: null, details: {}, feedbackMessages };
  } catch (e) {
    const { message, details } = extractError(e);
    return { results: [], error: message, details, feedbackMessages: [message] };
  }
}

module.exports = { pmcEstimatorAPI, processTask, SCHEMA_VERSION, BUILD_INFO };


// FRESH_DEPLOY_MARKER_1765398882770_y5g61png

// FRESH_DEPLOY_MARKER_1765399144723_r6a5rrp4

// FORCE_FRESH_DEPLOY_1765399399392_3rzqvdul

// FRESH_DEPLOY_1765399736961_mgyakx3t

// FRESH_DEPLOY_1765400203542_k1dspt5c

// FRESH_DEPLOY_1765400492579_9aqlul05

// FRESH_DEPLOY_1765400932196_b39fd3d7
