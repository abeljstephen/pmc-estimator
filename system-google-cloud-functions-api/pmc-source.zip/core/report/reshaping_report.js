/*
 * core/report/reshaping_report.js v1.9.24
 * ---------------------------------------------------------------------------
 * WHAT
 *   Build a compact textual + structured summary for reshaping outcomes.
 *
 * HOW
 *   - Reuse the canonical normalizeSliders() from slider-normalization.js.
 *   - Emit human text and machine fields (probabilities, delta, sliders, etc).
 *
 * WHY
 *   - Keep UI concise while preserving programmatic detail for logging/Sheets.
 * ---------------------------------------------------------------------------
 * SACO ENHANCEMENT (NEW, v1.9.24):
 * - Append SACO details to narratives (e.g., " (SACO: KL=0.02, std=0.01, drift=4%)").
 * - CSV: Add cols for m0/m1 (moments), KL, robust_std, chainingDrift (% from seed).
 * - Mode labels: Extend for 'saco-fixed'/'saco-adaptive' w/ chaining notes.
 * - Why: Exposes fidelity metrics for transparency; drift<5% PMBOK Ch.11 guard.
 * =============================================================================
 * SACO THESIS SUMMARY (Shape-Adaptive Copula Optimization) v1.9.24
 * =============================================================================
 * 
 * Justification (from conversation analysis): [RETAINED; see copula-utils.js for full]
 * ...
 * 
 * SACO Steps (Sequential, chaining notes): [RETAINED; see copula-utils.js for full]
 * ...
 * 
 * Implementation Notes:
 * - Preserve original summaries/CSV; SACO as append/cols.
 * - Date: Oct 10, 2025 – SACO v1.0. Updated: Nov 12, 2025 – v1.9.24 (chaining patch: drift col, adaptive badges).
 * =============================================================================
 */

const path = require('path');
const CORE_DIR = path.resolve(__dirname, '..');
const { createErrorResponse } = require(path.join(CORE_DIR, 'helpers/validation'));

// Reuse the single source of truth for normalization:
const { normalizeSliders } = require(path.join(__dirname, '..', 'reshaping', 'slider-normalization'));

// DUAL-MODE: Human-readable labels for explain.mode (enhance badges/rows) [Step 7: Mode + chaining explain]
const MODE_LABELS = {
  fixed: 'Fixed Grid',          // Original 3-level exhaustive (fast, repeatable [1])
  'adaptive-tilt': 'Adaptive Tilt',  // Var-biased midpoints for risky tasks (nuanced, <10s [2])
  'adaptive-fixed': 'Adaptive Fixed', // Adaptive but no tilt (mid for balanced/low-var [3])
  manual: 'Manual Adjust',       // Fallback for adjusted/manual mode
  // SACO: New modes w/ chaining
  'saco-fixed': 'SACO Fixed (coarse, maxIter=60)',
  'saco-adaptive': 'SACO Adaptive (seed ±20%, probe=1-7, drift<5%)'
  // Refs: As above; extend if new modes added (e.g., 'stochastic' → 'Stochastic Search')
};

/**
 * Map explain.mode to badge label (e.g., 'fixed' → 'Fixed Grid'). v1.9.24: SACO prefixes + chaining suffix.
 * @param {string} mode - Raw mode from explain.
 * @returns {string} Human label or 'Unknown Mode'.
 * FAILSAFE: Defaults to 'Unknown Mode' on invalid; trims for CSV safety.
 * SACO: Handles 'saco-*' prefixes; appends "(chained)" if adaptive w/ seedBest.
 */
function getModeBadge(mode, hasSeed = false) {
  if (!mode || typeof mode !== 'string') return 'Unknown Mode';
  const cleanMode = mode.toLowerCase().trim().replace('saco-', ''); // SACO: Strip prefix for lookup
  const label = MODE_LABELS[cleanMode] || 'Unknown Mode';
  const sacoPrefix = mode.startsWith('saco-') ? 'SACO ' : '';
  const chainSuffix = hasSeed && cleanMode.includes('adaptive') ? ' (chained)' : '';
  return sacoPrefix + label.replace(/,/g, ';') + chainSuffix; // CSV-safe (no commas)
}

const NO_IMPROVEMENT_EPS = 1e-4;

function pct(v) { return Number.isFinite(v) ? (v * 100).toFixed(2) + '%' : 'N/A'; }
function num(v, d = 2) { return Number.isFinite(v) ? Number(v).toFixed(d) : 'N/A'; }

function generateReshapingSummary(input = {}) {
  try {
    const {
      bf, sf, sc, sra, rp, rt, uc,
      originalProb, adjustedProb,
      targetValue, triangleMean, triangleStdDev,
    } = input;

    const hasBoth = Number.isFinite(originalProb) && Number.isFinite(adjustedProb);
    const deltaPts = hasBoth ? (adjustedProb - originalProb) * 100 : null;
    const noImprovement = !hasBoth || (adjustedProb <= originalProb + NO_IMPROVEMENT_EPS);

    const preface = noImprovement
      ? 'No improvement found — keeping baseline/last sliders. '
      : '';

    const text =
      `${preface}Target ${num(targetValue, 0)} — baseline ${pct(originalProb)}, ` +
      `reshaped ${pct(adjustedProb)}` +
      (deltaPts !== null ? ` (Δ ${deltaPts.toFixed(2)} pts)` : '') +
      `. Sliders bf:${bf}, sf:${sf}, sc:${sc}, sra:${sra}, rp:${rp}, rt:${rt}, uc:${uc}. ` +
      `Triangle μ=${num(triangleMean)}, σ=${num(triangleStdDev)}.`;

    // Build a canonical object with all aliases, including flattened fields commonly
    // consumed by Sheets/readers that expect "Optimal …" (Title-Cased with spaces).
    const sliders = {
      budgetFlexibility: bf,
      scheduleFlexibility: sf,
      scopeCertainty: sc,
      scopeReductionAllowance: sra,
      reworkPercentage: rp,
      riskTolerance: rt,
      userConfidence: uc,
    };

    const out = {
      value: text,
      baselineProbability: originalProb,
      adjustedProbability: adjustedProb,
      deltaPoints: deltaPts,
      sliders,
      // Mirror aliases at this level for convenience:
      sliderValues: { ...sliders },
      optimizedSliders: { ...sliders },
      optimizedResult: {
        sliders: { ...sliders },
        sliderValues: { ...sliders },
        sliders01: {
          budgetFlexibility: (Number.isFinite(bf) ? bf : 0) / 100,
          scheduleFlexibility: (Number.isFinite(sf) ? sf : 0) / 100,
          scopeCertainty: (Number.isFinite(sc) ? sc : 0) / 100,
          scopeReductionAllowance: (Number.isFinite(sra) ? sra : 0) / 100,
          reworkPercentage: (Number.isFinite(rp) ? rp : 0) / 50, // domain-aware
          riskTolerance: (Number.isFinite(rt) ? rt : 0) / 100,
          userConfidence: (Number.isFinite(uc) ? uc : 0) / 100,
        }
      },
      // CamelCase flattened:
      optimalBudgetFlexibility: bf,
      optimalScheduleFlexibility: sf,
      optimalScopeCertainty: sc,
      optimalScopeReductionAllowance: sra,
      optimalReworkPercentage: rp,
      optimalRiskTolerance: rt,
      optimalUserConfidence: uc,
      // Title-Cased, space-separated flattened (for Sheets):
      'Optimal Budget Flexibility': bf,
      'Optimal Schedule Flexibility': sf,
      'Optimal Scope Certainty': sc,
      'Optimal Scope Reduction Allowance': sra,
      'Optimal Rework Percentage': rp,
      'Optimal Risk Tolerance': rt,
      'Optimal User Confidence': uc,
      triangle: { mean: triangleMean, stdDev: triangleStdDev },
      status: noImprovement ? 'no-change' : 'ok',
      error: null,
      details: {},
    };

    return out;
  } catch (e) {
    return {
      value: '',
      error: e && (e.message || e.error) ? (e.message || e.error) : 'Failed to build summary',
      details: e && e.details ? e.details : {},
    };
  }
}

function fmt(v, digits = 6) {
  /**
   * Format number to fixed digits or empty.
   * @param {*} v - Input value.
   * @param {number} [digits=6] - Decimal places.
   * @returns {string} Formatted string or ''.
   * FAILSAFE: Handles non-finite as empty string.
   */
  const n = Number(v);
  if (!Number.isFinite(n)) return '';
  return String(Number(n.toFixed(digits)));
}
function pct(v, digits = 2) {
  /**
   * Format as percentage.
   * @param {*} v - Input [0,1].
   * @param {number} [digits=2] - Decimal places.
   * @returns {string} '%'-suffixed or 'N/A'.
   * FAILSAFE: Non-finite → 'N/A'.
   */
  const n = Number(v);
  if (!Number.isFinite(n)) return 'N/A';
  return String((n * 100).toFixed(digits)) + '%';
}
function safe(v) {
  /**
   * CSV-safe stringify.
   * @param {*} v - Input.
   * @returns {string} Escaped string.
   * FAILSAFE: Handles null/undefined; escapes quotes/newlines.
   */
  if (v === null || v === undefined) return '';
  if (typeof v === 'string') return v.replace(/\r?\n/g, ' ').trim();
  if (typeof v === 'number') return fmt(v);
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  return JSON.stringify(v);
}
function csvRow(arr) {
  /**
   * Join array to CSV row.
   * @param {Array} arr - Fields.
   * @returns {string} CSV line.
   * FAILSAFE: Quotes fields with commas/quotes/newlines.
   */
  return arr.map(x => {
    const s = String(x ?? '');
    return (s.includes(',') || s.includes('"') || s.includes('\n'))
      ? `"${s.replace(/"/g, '""')}"`
      : s;
  }).join(',');
}

function summarizeBaseline(taskMeta, baseline) {
  /**
   * Human summary for baseline. [Step 1: Baseline p0/CV/skew]
   * @param {Object} taskMeta - Task metadata.
   * @param {Object} baseline - Baseline block.
   * @returns {string} Narrative text.
   * FAILSAFE: Handles missing fields gracefully.
   */
  const name = taskMeta?.task || '';
  const O = taskMeta?.optimistic;
  const M = taskMeta?.mostLikely;
  const P = taskMeta?.pessimistic;
  const tau = taskMeta?.targetValue ?? M;

  const pert = baseline?.pert?.value;
  const baseProbAtTau = baseline?.probabilityAtTarget?.value;
  const baseProbAtPert = baseline?.probabilityAtPert?.value;
  const ciL = baseline?.metrics?.monteCarloSmoothed?.ci?.lower;
  const ciU = baseline?.metrics?.monteCarloSmoothed?.ci?.upper;
  const kld = baseline?.metrics?.klDivergenceToTriangle;

  const bits = [];
  bits.push(`Task "${name}" baseline set by O=${O}, M=${M}, P=${P}.`);
  if (Number.isFinite(pert)) bits.push(`PERT≈${fmt(pert, 4)}.`);
  if (Number.isFinite(tau)) bits.push(`Target τ=${fmt(tau, 4)}.`);
  if (Number.isFinite(baseProbAtTau)) bits.push(`F₀(τ)=${pct(baseProbAtTau)}.`);
  if (Number.isFinite(baseProbAtPert)) bits.push(`F₀(PERT)=${pct(baseProbAtPert)}.`);
  if (Number.isFinite(ciL) && Number.isFinite(ciU)) bits.push(`MC-smoothed 95% CI=[${fmt(ciL,4)}, ${fmt(ciU,4)}].`);
  if (Number.isFinite(kld)) bits.push(`KL divergence vs Triangle=${fmt(kld,6)}.`);
  return bits.join(' ');
}

function summarizeExplain(label, explain) {
  /**
   * Human summary for adjusted/optimized explain block. [Steps 3-7: Warm-start → output]
   * @param {string} label - 'Adjusted' | 'Optimized'.
   * @param {Object} explain - Explain object.
   * @returns {string|null} Narrative or null.
   * DUAL-MODE: Append mode badge (e.g., "Optimized (Fixed Grid)") for explainability [4].
   * SACO: + KL, std, moments, chainingDrift if present (e.g., "KL=0.02, std=0.01, drift=4%").
   * FAILSAFE: Null on missing explain; handles non-finite probs.
   */
  if (!explain) return null;
  const base = explain?.baselineProb;
  const fin = explain?.finalProb;
  const usedProj = !!explain?.projection?.used;
  const lam = explain?.projection?.lambda;
  const fmin = explain?.projection?.Fmin;

  // DUAL-MODE: Get badge for narrative (enhance badges) [Chaining: hasSeed=!!explain.seedBest]
  const modeBadge = getModeBadge(explain.mode || (label.toLowerCase() === 'adjusted' ? 'manual' : 'fixed'), !!explain.seedBest);

  // SACO: Append metrics [Math: exp(-KL) score; PMBOK Ch.6 KL<0.05]
  let sacoSuffix = '';
  if (explain.klDivergence != null || explain.robustStd != null || explain.moments || explain.chainingDrift != null) {
    sacoSuffix = ` (SACO: KL=${fmt(explain.klDivergence || 0,3)}, std=${fmt(explain.robustStd || 0,3)}${explain.moments ? ', moments used' : ''}${explain.chainingDrift != null ? `, drift=${fmt(explain.chainingDrift,1)}%` : ''})`;
  }

  const parts = [];
  parts.push(`${label} ${modeBadge}: F(τ) ${Number.isFinite(base) ? pct(base) : '–'} → ${Number.isFinite(fin) ? pct(fin) : '–'}${sacoSuffix}.`);
  parts.push(usedProj ? `Projection guard active (λ=${fmt(lam,3)}, Fmin=${pct(fmin)}).` : `Convex blend; no projection guard.`);
  const sCount = Array.isArray(explain?.sliders) ? explain.sliders.length : 0;
  parts.push(`Contributors=${sCount} sliders.`);
  return parts.join(' ');
}

function buildBaselineCsv(taskMeta, baseline) {
  /**
   * Build baseline CSV section. [Step 1: Baseline metrics]
   * @param {Object} taskMeta - Task metadata.
   * @param {Object} baseline - Baseline block.
   * @returns {string} CSV lines.
   * FAILSAFE: Empty strings on missing; fixed precision.
   */
  const rows = [];
  rows.push(csvRow(['Section','Metric','Value']));
  rows.push(csvRow(['Task','Name', safe(taskMeta?.task)]));
  rows.push(csvRow(['Inputs','Optimistic (O)', fmt(taskMeta?.optimistic)]));
  rows.push(csvRow(['Inputs','Most Likely (M)', fmt(taskMeta?.mostLikely)]));
  rows.push(csvRow(['Inputs','Pessimistic (P)', fmt(taskMeta?.pessimistic)]));
  rows.push(csvRow(['Target','τ (Target Value)', fmt(taskMeta?.targetValue ?? taskMeta?.mostLikely)]));
  rows.push(csvRow(['Parameters','Confidence Level', fmt(taskMeta?.confidenceLevel)]));
  rows.push(csvRow(['Baseline','PERT Mean', fmt(baseline?.pert?.value)]));
  rows.push(csvRow(['Baseline','F₀(τ)', pct(baseline?.probabilityAtTarget?.value)]));
  rows.push(csvRow(['Baseline','F₀(PERT)', pct(baseline?.probabilityAtPert?.value)]));
  rows.push(csvRow(['Baseline','MC-smoothed 95% CI Lower', fmt(baseline?.metrics?.monteCarloSmoothed?.ci?.lower)]));
  rows.push(csvRow(['Baseline','MC-smoothed 95% CI Upper', fmt(baseline?.metrics?.monteCarloSmoothed?.ci?.upper)]));
  rows.push(csvRow(['Baseline','KL Divergence (Triangle→MC)', fmt(baseline?.metrics?.klDivergenceToTriangle, 8)]));
  return rows.join('\n');
}

function buildDecisionCsv(taskMeta, baseline, adjusted, optimized, mode) {
  /**
   * Build decision ledger CSV (sliders + contributions). [Steps 4-7: BFS → rules; SACO cols]
   * @param {Object} taskMeta - Task metadata.
   * @param {Object} baseline - Baseline block.
   * @param {Object} adjusted - Adjusted block.
   * @param {Object} optimized - Optimized block.
   * @param {string} mode - 'view' | 'opt'.
   * @returns {string} CSV lines.
   * DUAL-MODE: Append mode badge to Optimized block label (e.g., "Optimized (Adaptive Tilt)")
   *   for row-level explainability in Sheets/export [4]. Adjusted uses 'Manual Adjust'.
   * SACO: Add cols: Moments m0, m1, KL, robust_std, chainingDrift. [v1.9.24: drift % from seedBest.finalProb]
   * FAILSAFE: Placeholder row if no sliders; clamps non-finite.
   */
  const rows = [];
  // DUAL-MODE: Add 'Mode' column for badges (enhance CSV rows)
  // SACO: Extended cols + chainingDrift
  // SACO TEST PATCH: Extend header for new testing vars (CV, Raw Value, per-slider m0/m1, bootstrap per-mode, partial impact, chainingDrift)
  // Why: Enables robust table parsing in deployment scripts; additive, no existing cols altered. [Math: drift = |P'-P_seed|/P_seed *100 <5%]
  rows.push(csvRow(['Block','Mode','Slider','Category','Band','Value (0..1)','λ_i (blend part)','α (left shift)','β (tail shave)','ΔProb raw','Projection share','ΔProb total','m0 (moments)','m1 (moments)','KL Divergence','Robust Std','CV Proxy','Raw Value','m0 per Slider','m1 per Slider','Bootstrap AvgP','Bootstrap StdP','Partial Impact','Chaining Drift %']));

  const bandOf = (v01) => {
    /**
     * Band for value [0,1] → '0–25' etc.
     * @param {number} v01 - Normalized value.
     * @returns {string} Band label.
     * FAILSAFE: Empty on non-finite.
     */
    const v = Number(v01);
    if (!Number.isFinite(v)) return '';
    const pct100 = v * 100;
    if (pct100 <= 25) return '0–25';
    if (pct100 <= 50) return '26–50';
    if (pct100 <= 75) return '51–75';
    return '76–100';
  };

  const pushBlock = (label, blockExplain, blockMode = 'manual') => {
    /**
     * Push slider rows for a block.
     * @param {string} label - Block label (e.g., 'Adjusted').
     * @param {Object} blockExplain - Explain object.
     * @param {string} blockMode - Mode for badge (e.g., 'fixed').
     * FAILSAFE: Skips on missing explain; defaults mode to 'manual'.
     */
    if (!blockExplain) return;
    const sliders = Array.isArray(blockExplain.sliders) ? blockExplain.sliders : [];
    const badge = getModeBadge(blockMode, !!blockExplain.seedBest); // DUAL-MODE: Badge + chaining suffix
    for (const s of sliders) {
      const v = Number(s.value ?? 0);
      const cat = s.category || 'other';
      const lamPart = Number(s?.weights?.blend ?? 0) * v; // w_i * s_i (approx for ledger visibility)
      const a = Number(s?.weights?.leftShift ?? s?.modeledEffect?.alpha ?? 0);
      const b = Number(s?.weights?.tailShave ?? s?.modeledEffect?.beta ?? 0);
      const dRaw = Number(s?.contribution?.deltaTargetProbFromRaw ?? 0);
      const dProj = Number(s?.contribution?.shareOfProjectionLift ?? 0);
      const dTot = (Number.isFinite(dRaw) ? dRaw : 0) + (Number.isFinite(dProj) ? dProj : 0);
      // SACO: Moments/KL/std per block (from explain; NaN as '')
      const m0 = fmt(s.moments?.m0 || blockExplain.moments?.m0 || NaN, 3);
      const m1 = fmt(s.moments?.m1 || blockExplain.moments?.m1 || NaN, 3);
      const kl = fmt(blockExplain.klDivergence || NaN, 3);
      const std = fmt(blockExplain.robustStd || NaN, 3);

      // SACO TEST PATCH: Add new cols for testing vars (CV from explain.cv, raw from explain.rawSliders, etc.)
      // Why: Robust visibility in CSV for deployment script parsing; fallback to '' on missing.
      const cv = fmt(blockExplain.cv || NaN, 3);
      const rawVal = fmt(blockExplain.rawSliders?.[s.slider] || NaN, 2);
      const m0Per = fmt(blockExplain.momentsBreakdown?.[s.slider]?.m0 || NaN, 3);
      const m1Per = fmt(blockExplain.momentsBreakdown?.[s.slider]?.m1 || NaN, 3);
      const bootAvg = fmt(blockExplain.bootstrapPerMode?.[blockMode]?.avgP || NaN, 3);
      const bootStd = fmt(blockExplain.bootstrapPerMode?.[blockMode]?.stdP || NaN, 3);
      const partial = fmt(blockExplain.partialImpact || 0, 3);
      // NEW v1.9.24: Chaining drift % [PMBOK Ch.11: <5% anchor/leash]
      const drift = fmt(blockExplain.chainingDrift || NaN, 1);

      // DUAL-MODE: Include badge in row (CSV column)
      rows.push(csvRow([
        label,
        badge,
        safe(s.slider),
        safe(cat),
        bandOf(v),
        fmt(v, 4),
        fmt(lamPart, 4),
        fmt(a, 4),
        fmt(b, 4),
        pct(dRaw),
        pct(dProj),
        pct(dTot),
        m0, // SACO
        m1, // SACO
        kl, // SACO
        std,  // SACO
        cv,  // NEW
        rawVal,  // NEW
        m0Per,  // NEW
        m1Per,  // NEW
        bootAvg,  // NEW
        bootStd,  // NEW
        partial,  // NEW
        drift   // NEW v1.9.24
      ]));
    }
    // Sigma row with mode badge + SACO cols
    rows.push(csvRow([
      label,
      badge,
      'Σ','','','','','','','','','', '', '', '', '', '', '', '', '', '', '', '', ''
    ]));
    rows.push(csvRow([
      '', // Empty block
      '', // Empty mode
      '', // Empty slider
      pct(Number(blockExplain.finalProb ?? 0) - Number(blockExplain.baselineProb ?? 0)), // Delta total
      '', // Pad
      fmt(blockExplain.klDivergence || '', 3), // SACO KL
      fmt(blockExplain.robustStd || '', 3), // SACO std
      fmt(blockExplain.chainingDrift || '', 1) // SACO drift
    ]));
  };

  // DUAL-MODE: Adjusted as 'manual'; Optimized pulls from explain.mode or fallback
  if (adjusted?.explain) pushBlock('Adjusted', adjusted.explain, 'manual');
  if (optimized?.explain) {
    const optMode = optimized.explain.mode || 'fixed'; // From optimizer explain
    pushBlock('Optimized', optimized.explain, optMode);
  }

  if (!adjusted?.explain && !optimized?.explain) {
    // Placeholder with default mode
    const placeholderMode = getModeBadge('manual');
    rows.push(csvRow(['Baseline', placeholderMode, '(no sliders moved)','-','-','0','0','0','0',pct(0),pct(0),pct(0), '', '', '', '', '', '', '', '', '', '', '', '']));
  }

  return rows.join('\n');
}

/* ---- OPTIONAL helper: also produce a reports[] array for UI pane ---- */
function buildReportsArray(taskMeta, adjusted, optimized) {
  /**
   * Build array of report entries for UI decision pane. [Step 7: Output reports w/ chaining]
   * @param {Object} taskMeta - Task metadata.
   * @param {Object} adjusted - Adjusted block.
   * @param {Object} optimized - Optimized block.
   * @returns {Array} Report entries.
   * DUAL-MODE: Append mode badge to narrative (e.g., " w/ Adaptive Tilt") [4].
   * SACO: Include KL/std/moments/drift in entries. [v1.9.24: chainingDrift exposed]
   * FAILSAFE: Filters null entries; handles missing explain.
   */
  const out = [];

  const toEntry = (modeLabel, block) => {
    if (!block || !block.explain) return null;
    const ex = block.explain;
    const baselineProb = Number.isFinite(ex.baselineProb) ? ex.baselineProb : null;
    const finalProb = Number.isFinite(ex.finalProb) ? ex.finalProb : null;
    const lift = (baselineProb != null && finalProb != null) ? (finalProb - baselineProb) : null;
    const cert = (typeof block.certificate === 'string')
      ? block.certificate
      : (block.certificate ? JSON.stringify(block.certificate) : '—');

    // DUAL-MODE: Mode badge for narrative (enhance badges)
    const modeBadge = getModeBadge(ex.mode || (modeLabel.toLowerCase() === 'adjusted' ? 'manual' : 'fixed'), !!ex.seedBest);
    const modeSuffix = ` (${modeBadge})`;

    // SACO: Append to narrative if fields
    let sacoSuffix = '';
    if (ex.klDivergence != null || ex.robustStd != null || ex.moments || ex.chainingDrift != null) {
      sacoSuffix = ` (KL=${fmt(ex.klDivergence,3)}, std=${fmt(ex.robustStd,3)}${ex.moments ? ', moments' : ''}${ex.chainingDrift != null ? `, drift=${fmt(ex.chainingDrift,1)}%` : ''})`;
    }

    // SACO TEST PATCH: Add new fields to entry for testing (CV, rawSliders, etc.)
    // Why: Enables script validation of robust vars in reports[]; fallback null.
    return {
      mode: modeLabel,
      narrative: ((ex.narrative || '') + modeSuffix + sacoSuffix),
      target: Number.isFinite(taskMeta?.targetValue) ? taskMeta.targetValue : taskMeta?.mostLikely ?? null,
      baselineProbability: baselineProb,
      finalProbability: finalProb,
      liftPoints: lift,
      lambda: (ex.projection && Number.isFinite(ex.projection.lambda)) ? ex.projection.lambda : null,
      certificate: cert,
      diagnostics: {
        monotonicityAtTarget: ex.monotonicityAtTarget || 'N/A',
        allZeroSlidersPassThrough: ex.allZeroSlidersPassThrough || 'N/A',
        winnerHasSliders: (ex.winningSliders && Object.keys(ex.winningSliders).length > 0) ? true : false,
        chainingDrift: ex.chainingDrift || 'N/A'  // NEW
      },
      counterIntuition: Array.isArray(ex.counterIntuition) ? ex.counterIntuition : [],
      recommendations: Array.isArray(ex.recommendations) ? ex.recommendations : [],
      bands: ex.bands || {},
      winningSliders: ex.winningSliders || {},
      sliderCategories: ex.sliderCategories || {},
      // SACO: Expose in array
      klDivergence: ex.klDivergence || null,
      robustStd: ex.robustStd || null,
      moments: ex.moments || null,
      chainingDrift: ex.chainingDrift || null,  // NEW v1.9.24
      // DUAL SLIDERS: Expose both in entry
      scaledSliders: ex.slidersScaled || null,
      normalizedSliders: ex.slidersNormalized || null,
      // NEW: Testing vars
      cv: ex.cv || null,
      rawSliders: ex.rawSliders || null,
      momentsBreakdown: ex.momentsBreakdown || null,
      bootstrapPerMode: ex.bootstrapPerMode || null,
      partialImpact: ex.partialImpact || null
    };
  };

  const adj = toEntry('Adjusted', adjusted);
  const opt = toEntry('Optimize', optimized);
  if (adj) out.push(adj);
  if (opt) out.push(opt);

  return out;
}

function buildReports({ taskMeta, baseline, adjusted, optimized, mode }) {
  /**
   * Main entry: Build full reports bundle (CSV + summaries + reports[]). [Step 7: Full output]
   * @param {Object} args - Inputs.
   * @returns {Object} { baselineCsv, decisionCsv, summaries, meta, reports }.
   * FAILSAFE: Handles partial inputs; empty CSVs on errors.
   */
  const baselineCsv = buildBaselineCsv(taskMeta, baseline);
  const decisionCsv = buildDecisionCsv(taskMeta, baseline, adjusted, optimized, mode);

  const summaries = {
    baseline: summarizeBaseline(taskMeta, baseline),
    adjusted: adjusted?.explain ? summarizeExplain('Adjusted', adjusted.explain) : null,
    optimized: optimized?.explain ? summarizeExplain('Optimized', optimized.explain) : null
  };

  // Optional: provide a ready-to-render array for the UI pane (mirrors main.js builder)
  const reports = buildReportsArray(taskMeta, adjusted, optimized);

  return {
    baselineCsv,
    decisionCsv,
    summaries,
    meta: {
      builtAt: new Date().toISOString(),
      task: taskMeta?.task || '',
      targetValue: taskMeta?.targetValue ?? taskMeta?.mostLikely ?? null,
      confidenceLevel: taskMeta?.confidenceLevel ?? null
    },
    reports
  };
}

module.exports = { normalizeSliders, generateReshapingSummary, buildReports };

