'use strict';

const path = require('path');
const CORE_DIR = path.resolve(__dirname, '..');

const { generateTrianglePoints } = require('./triangle-points');
const { generatePertPoints } = require('./pert-points');
const { generateBetaPoints, computeBetaMoments } = require('./beta-points');
const { generateMonteCarloRawPoints } = require('./monte-carlo-raw');
const { generateMonteCarloSmoothedPoints } = require('./monte-carlo-smoothed');

const { createErrorResponse, isValidPdfArray, isValidCdfArray } =
  require(path.join(CORE_DIR, 'helpers/validation'));

const { calculateMetrics, ensureSortedMonotoneCdf } =
  require(path.join(CORE_DIR, 'helpers/metrics'));
const { computeKLDivergence } =
  require(path.join(CORE_DIR, 'optimization', 'kl-divergence'));

console.log('coordinator.js: Starting module initialization');

/**
 * Generates baseline distributions and metrics. v1.9.24
 *
 * Policy:
 *  - ALWAYS generate Triangle (needed for KL).
 *  - Monte Carlo *smoothed* (active baseline) is always generated.
 *  - If `suppressOtherDistros` is true: skip PERT/Beta/MC-raw (perf).
 *  - All returned CDFs are hygiene-checked (sorted/monotone/clamped).
 * SACO Step 1: Baseline (p0, cv, skew). [MC-smoothed → μ_0, σ_0^2, P_0(τ); CV=(P-O)/μ_0 for Step 2 bias=0.15 if v>0.5/p0<0.3]
 * Math: KL(Triangle||MC)<0.05 tie for robustStd (Step 6 bootstrap); PMBOK Ch.6: Quant baseline for erf-slack feas in rules.
 */
async function generateBaseline(params) {
  console.log('generateBaseline: Starting', { params });
  try {
    const {
      optimistic, mostLikely, pessimistic,
      numSamples = 200,
      suppressOtherDistros = false
    } = params;

    // validation
    if (![optimistic, mostLikely, pessimistic].every(Number.isFinite)) {
      throw new Error('Invalid estimates: must be finite numbers');
    }
    if (!(optimistic <= mostLikely && mostLikely <= pessimistic)) {
      throw new Error('Estimates must satisfy optimistic <= mostLikely <= pessimistic');
    }
    if (!Number.isFinite(numSamples) || numSamples < 100) {
      throw new Error('Invalid numSamples: must be a number >= 100');
    }

    // Beta params (shared) [Step 1: α_0/β_0 for μ_0=(O+4M+P)/6, σ_0^2=((P-O)/6)^2]
    const { alpha, beta } = await computeBetaMoments({ optimistic, mostLikely, pessimistic });
    if (!(alpha > 0 && beta > 0 && Number.isFinite(alpha) && Number.isFinite(beta))) {
      throw new Error('Invalid beta parameters');
    }

    // Triangle (always) [Math: Linear pdf for KL baseline; Ch.11: ROM rough scout]
    const trianglePoints = await generateTrianglePoints({ optimistic, mostLikely, pessimistic, numSamples });
    if (trianglePoints.error ||
        !isValidPdfArray(trianglePoints.pdfPoints) ||
        !isValidCdfArray(trianglePoints.cdfPoints)) {
      throw new Error('Invalid triangle points');
    }
    // Hygiene on triangle CDF [Step 7: Monotone for chaining interp fidelity]
    trianglePoints.cdfPoints = ensureSortedMonotoneCdf(trianglePoints.cdfPoints);

    // Optionals
    let pertPoints, betaPoints, monteCarloRawPoints;
    if (!suppressOtherDistros) {
      pertPoints = await generatePertPoints({ optimistic, mostLikely, pessimistic, numSamples });
      if (pertPoints.error ||
          !isValidPdfArray(pertPoints.pdfPoints) ||
          !isValidCdfArray(pertPoints.cdfPoints)) {
        throw new Error('Invalid PERT points');
      }
      pertPoints.cdfPoints = ensureSortedMonotoneCdf(pertPoints.cdfPoints);

      betaPoints = await generateBetaPoints({ optimistic, mostLikely, pessimistic, numSamples, alpha, beta });
      if (betaPoints.error ||
          !isValidPdfArray(betaPoints.pdfPoints) ||
          !isValidCdfArray(betaPoints.cdfPoints)) {
        throw new Error('Invalid beta points');
      }
      betaPoints.cdfPoints = ensureSortedMonotoneCdf(betaPoints.cdfPoints);

      monteCarloRawPoints = await generateMonteCarloRawPoints({ optimistic, mostLikely, pessimistic, numSamples, alpha, beta });
      if (monteCarloRawPoints.error ||
          !isValidPdfArray(monteCarloRawPoints.pdfPoints) ||
          !isValidCdfArray(monteCarloRawPoints.cdfPoints)) {
        throw new Error('Invalid Monte Carlo raw points');
      }
      monteCarloRawPoints.cdfPoints = ensureSortedMonotoneCdf(monteCarloRawPoints.cdfPoints);
    } else {
      console.log('generateBaseline: suppressOtherDistros=true (PERT/Beta/MC-raw skipped; Triangle kept)');
    }

    // Monte Carlo smoothed (active baseline) [Step 1: Smoothed pdf/cdf for p0(τ); cv/skew for bias/amp]
    const smoothedParams = { optimistic, mostLikely, pessimistic, numSamples };
    if (monteCarloRawPoints?.samples?.length) smoothedParams.samples = monteCarloRawPoints.samples;

    const monteCarloSmoothedPoints = await generateMonteCarloSmoothedPoints(smoothedParams);
    if (monteCarloSmoothedPoints.error ||
        !isValidPdfArray(monteCarloSmoothedPoints.pdfPoints) ||
        !isValidCdfArray(monteCarloSmoothedPoints.cdfPoints)) {
      throw new Error('Invalid Monte Carlo smoothed points');
    }
    // Hygiene on MC-smoothed CDF [Math: Ensures monotone for Step 5 P'(τ) interp; Ch.6 KL<0.05]
    monteCarloSmoothedPoints.cdfPoints = ensureSortedMonotoneCdf(monteCarloSmoothedPoints.cdfPoints);

    // Metrics [Step 1: CI from quantiles; pert mean for cv=(P-O)/μ_0]
    const metrics = calculateMetrics({
      optimistic, mostLikely, pessimistic,
      triangle: trianglePoints,
      monteCarloSmoothed: {
        pdfPoints: monteCarloSmoothedPoints.pdfPoints,
        cdfPoints: monteCarloSmoothedPoints.cdfPoints
      }
    });

    const ciLower = metrics?.monteCarloSmoothed?.ci?.lower;
    const ciUpper = metrics?.monteCarloSmoothed?.ci?.upper;

    // KL(Triangle || MC-smoothed) [Step 6: KL<0.05 tie for robustStd; Ch.6 quant baseline fidelity]
    const klObj = computeKLDivergence({
      distributions: {
        triangle: trianglePoints,
        monteCarloSmoothed: monteCarloSmoothedPoints
      },
      task: 'baseline'
    });
    const kld = klObj && klObj['triangle-monteCarloSmoothed'];

    console.log('generateBaseline: Completed', {
      ciLower, ciUpper, kld,
      mcPdf: monteCarloSmoothedPoints.pdfPoints.length,
      mcCdf: monteCarloSmoothedPoints.cdfPoints.length
    });

    return {
      trianglePoints,                 // ALWAYS present
      pertPoints,                     // unless suppressed
      betaPoints,                     // unless suppressed
      monteCarloRawPoints,            // unless suppressed
      monteCarloSmoothedPoints,       // active baseline

      metrics: {
        monteCarloSmoothed: { ci: { lower: ciLower, upper: ciUpper } },
        klDivergenceToTriangle: kld
      },

      // Back-compat mirrors:
      ci: { monteCarloSmoothed: { lower: ciLower, upper: ciUpper } },
      confidenceInterval: { lower: ciLower, upper: ciUpper },
      pert: { mean: (optimistic + 4 * mostLikely + pessimistic) / 6 },
      monteCarloSmoothed: {
        pdfPoints: monteCarloSmoothedPoints.pdfPoints,
        cdfPoints: monteCarloSmoothedPoints.cdfPoints
      },

      alpha, beta,
      error: null
    };
  } catch (error) {
    console.error('generateBaseline: Error', { message: error.message, stack: error.stack });
    return { error: `Failed to generate baseline: ${error.message || 'Unknown error'}` };
  }
}

module.exports = { generateBaseline };
