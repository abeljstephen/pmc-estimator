'use strict';

const path = require('path');
const CORE_DIR = path.resolve(__dirname, '..');

/* ------------------------------------------------------------------ *
 *  Log-Gamma (Lanczos), Gamma sampler (Marsaglia–Tsang), Beta utils v1.9.24
 * ------------------------------------------------------------------ */

// Lanczos coefficients for log-gamma; good double-precision accuracy [Step 5: Stable logBetaFN for α'/β' solve]
const LANCZOS_COEFFS = [
  676.5203681218851,   -1259.1392167224028,
  771.32342877765313,  -176.61502916214059,
  12.507343278686905,  -0.13857109526572012,
  9.9843695780195716e-6, 1.5056327351493116e-7
];

function logGamma(z) {
  if (z < 0.5) {
    // Reflection
    return Math.log(Math.PI) - Math.log(Math.sin(Math.PI * z)) - logGamma(1 - z);
  }
  z -= 1;
  let x = 0.99999999999980993;
  for (let i = 0; i < LANCZOS_COEFFS.length; i++) {
    x += LANCZOS_COEFFS[i] / (z + i + 1);
  }
  const t = z + LANCZOS_COEFFS.length - 0.5;
  return 0.5 * Math.log(2 * Math.PI) + (z + 0.5) * Math.log(t) - t + Math.log(x);
}

function gammaSample(shape) {
  // Scale is 1 (θ=1)
  if (shape <= 0) return NaN;

  // Marsaglia & Tsang (2000) method for k > 1
  if (shape > 1) {
    const d = shape - 1 / 3;
    const c = 1 / Math.sqrt(9 * d);
    // rejection loop
    // eslint-disable-next-line no-constant-condition
    while (true) {
      // Standard normal using Box-Muller
      let x, y, r2;
      do {
        x = 2 * Math.random() - 1;
        y = 2 * Math.random() - 1;
        r2 = x * x + y * y;
      } while (r2 === 0 || r2 >= 1);
      const n = x * Math.sqrt(-2 * Math.log(r2) / r2);

      const v = Math.pow(1 + c * n, 3);
      if (v <= 0) continue;
      const u = Math.random();
      const lhs = Math.log(u);
      const rhs = 0.5 * n * n + d - d * v + d * Math.log(v);
      if (lhs <= rhs) return d * v;
    }
  }

  // For 0 < k <= 1, boost to k+1 then thin
  // (Ahrens–Dieter: draw gamma(k+1) and multiply by U^{1/k})
  const u = Math.random();
  return gammaSample(shape + 1) * Math.pow(u, 1 / shape);
}

function betaSample(alpha, beta) {
  const ga = gammaSample(alpha);
  const gb = gammaSample(beta);
  const s = ga + gb;
  return (ga > 0 && s > 0) ? (ga / s) : NaN;
}

// log Beta function via logGamma [Math: logB(α',β') for refit denom stability; PMBOK Ch.6: Quant erf-slack]
function logBetaFN(a, b) {
  return logGamma(a) + logGamma(b) - logGamma(a + b);
}

function betaPdfUnit(u, alpha, beta) {
  if (u <= 0 || u >= 1 || alpha <= 0 || beta <= 0) return 0;
  // Work in log space for stability
  const logNum = (alpha - 1) * Math.log(u) + (beta - 1) * Math.log(1 - u);
  const logDen = logBetaFN(alpha, beta);
  return Math.exp(logNum - logDen);
}

/* ------------------------------------------------------------------ *
 *  Canonical PERT (λ=4) mapping: (O, M, P) → (α, β) [Step 1: Baseline α_0/β_0 for μ_0/σ_0^2]
 * ------------------------------------------------------------------ */

async function computeBetaMoments(params) {
  console.log('computeBetaMoments: Starting', { params });
  try {
    const { optimistic: O, mostLikely: M, pessimistic: P } = params || {};
    if (![O, M, P].every(Number.isFinite)) {
      throw new Error('Invalid estimates: must be finite numbers');
    }
    if (O > M || M > P) {
      throw new Error('Estimates must satisfy optimistic <= mostLikely <= pessimistic');
    }
    const r = P - O;
    if (!(r > 0)) throw new Error('Degenerate case: zero range');

    // Canonical PERT with lambda=4 (classic) [Math: α_0=1+4(M-O)/r; preserves skew for Step 1 cv=(P-O)/μ_0]
    const lambda = 4;
    let alpha = 1 + lambda * (M - O) / r;
    let beta  = 1 + lambda * (P - M) / r;

    // Floor slightly above 1 for numerical stability in sampling / KDE [Step 5: Refit denom>0; Ch.11: No inf in elaboration]
    const EPS = 1e-6;
    if (!(alpha > 0) || !(beta > 0) || !Number.isFinite(alpha) || !Number.isFinite(beta)) {
      throw new Error('Invalid alpha/beta from PERT mapping');
    }
    if (alpha < 1) alpha = 1 + EPS;
    if (beta  < 1) beta  = 1 + EPS;

    console.log('computeBetaMoments: Completed', { alpha, beta, lambda });
    return { alpha, beta };
  } catch (error) {
    console.error('computeBetaMoments: Error', { message: error.message, stack: error.stack });
    return { alpha: null, beta: null, error: error.message };
  }
}

/* ------------------------------------------------------------------ *
 *  Generate (scaled) Beta PDF/CDF over [O,P] [Step 5: New points gen post-refit α'/β'; chaining: μ'=μ_0(1-m0·0.2), σ'^2=σ_0^2(1-m1·0.5)]
 * ------------------------------------------------------------------ */

async function generateBetaPoints(params) {
  console.log('generateBetaPoints: Starting', { params });
  try {
    const { optimistic: O, mostLikely: M, pessimistic: P, numSamples = 200, alpha, beta } = params || {};

    if (![O, M, P].every(Number.isFinite)) {
      throw new Error('Invalid estimates: must be finite numbers');
    }
    if (O > M || M > P) throw new Error('Estimates must satisfy optimistic <= mostLikely <= pessimistic');
    const r = P - O;
    if (!(r > 0)) throw new Error('Degenerate case: zero range');
    if (!Number.isFinite(numSamples) || numSamples < 2) {
      throw new Error('Invalid numSamples: must be >= 2');
    }
    if (!Number.isFinite(alpha) || !Number.isFinite(beta) || alpha <= 0 || beta <= 0) {
      throw new Error('Invalid alpha or beta values');
    }

    const step = r / (numSamples - 1);
    const pdfPoints = [];
    for (let i = 0; i < numSamples; i++) {
      const x = O + i * step;
      const u = (x - O) / r; // map to [0,1]
      const y = (u >= 0 && u <= 1) ? betaPdfUnit(u, alpha, beta) / r : 0;
      if (!Number.isFinite(y) || y < 0) {
        throw new Error(`Invalid PDF value at x=${x}, u=${u}, y=${y}`);
      }
      pdfPoints.push({ x, y });
    }

    // Normalize PDF by trapezoid (guarding numeric drift) [Math: ∫pdf=1 for KL<0.05; Step 6 bootstrap tie]
    let area = 0;
    for (let i = 1; i < pdfPoints.length; i++) {
      const dx = pdfPoints[i].x - pdfPoints[i - 1].x;
      if (!(dx > 0)) throw new Error(`Invalid dx in normalization at i=${i}: dx=${dx}`);
      area += 0.5 * (pdfPoints[i].y + pdfPoints[i - 1].y) * dx;
    }
    if (!(area > 0) || !Number.isFinite(area)) throw new Error('Invalid PDF area before normalization');
    const normalizedPdfPoints = pdfPoints.map(p => ({ x: p.x, y: p.y / area }));

    // CDF via cumulative trapezoid on the same grid [PMBOK Ch.6: Monotone cdf for erf-slack feas in Step 7 rules]
    const cdfPoints = [];
    let cum = 0;
    cdfPoints.push({ x: normalizedPdfPoints[0].x, y: 0 });
    for (let i = 1; i < normalizedPdfPoints.length; i++) {
      const dx = normalizedPdfPoints[i].x - normalizedPdfPoints[i - 1].x;
      cum += 0.5 * (normalizedPdfPoints[i].y + normalizedPdfPoints[i - 1].y) * dx;
      cdfPoints.push({ x: normalizedPdfPoints[i].x, y: Math.max(0, Math.min(1, cum)) });
    }

    console.log('generateBetaPoints: Completed', {
      pdfPointsLength: normalizedPdfPoints.length,
      cdfPointsLength: cdfPoints.length
    });
    return { pdfPoints: normalizedPdfPoints, cdfPoints };
  } catch (error) {
    console.error('generateBetaPoints: Error', { message: error.message, stack: error.stack });
    return { pdfPoints: [], cdfPoints: [], error: error.message };
  }
}

module.exports = {
  computeBetaMoments,
  generateBetaPoints,
  betaPdf: betaPdfUnit, // keep name for compatibility
  betaSample
};
