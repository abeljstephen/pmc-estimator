const numeric = require('numeric');
console.log(numeric.uncmin(x => x[0] * x[0], [1], 1e-6, {}));
